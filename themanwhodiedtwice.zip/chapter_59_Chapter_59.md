## 59

‘Ready for the show?’ asks Ibrahim.

‘Best seat in the house,’ says Donna, and puts her arm around the old man’s shoulders.

The recording starts a few minutes before the time the locker was opened. They can see the back of the young receptionist’s head, and a few people hurrying through the frame in front of her. A balding man in a Costa Coffee uniform saunters over wearing sunglasses. A few words are spoken, mainly by the receptionist, and he walks away again, a little less jauntily. Another twenty seconds or so, and then the biker walks into view. Same leathers, same helmet, same person who came looking for the diamonds.

There is no sound, but the sequence of events is clear. The figure walks out of shot, towards the lockers, and is summoned back by the receptionist. The figure then fishes around in a pocket and shows the receptionist something, and is then asked to take the helmet off. The face is as clear as a bell, and neither of them has the slightest doubt.

They have no ready explanation, either, but they have no doubt.

It is Siobhan.

It is Poppy’s mum, opening a locker, looking for diamonds, the day before her daughter is shot dead.

They even see Joyce’s friendship bracelet as Siobhan puts the helmet back on and walks towards the lockers.

‘I think perhaps we need to call Elizabeth,’ says Ibrahim.

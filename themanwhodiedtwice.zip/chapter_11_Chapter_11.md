## 11

The woman from the _Sunday Telegraph_ is very friendly, but Martin Lomax supposes that’s all part of her job. She is cooing over his Japanese anemones and stroking one of his ornamental box hedges as they wander.

‘I mean, I’ve seen some beautiful private gardens, Mr Lomax, but really this tops them all. It tops them all. Where has this been hiding?’

Martin Lomax nods, and they keep walking. She seems quite happy talking. It is a beautiful garden, he knows that. It really should be for the money. But the best? The very best? Come now. But that’s her job, of course.

‘The use of symmetry is fascinating. It unfurls, doesn’t it? It reveals itself. Do you know the famous William Blake poem, Mr Lomax?’

Martin Lomax shakes his head. He once killed a poet, but that’s as far as he and poetry go.

‘Tyger tyger in the night, burning very very bright. What immortal symmetry. Have thee.’

Martin Lomax nods again and thinks he should probably say something like ‘beautiful’. In case she starts to think he might be a sociopath. He has read _The Psychopath Test_.

‘Beautiful.’

He has wanted to be in the _Sunday Telegraph_’s ‘Britain’s Best Gardens’ supplement for a long time. In the distance he sees the photographer under a hedge, shooting upwards into the cloudless sky. That will be a beautiful photograph. There is a box containing half a million emergency dollars buried under that hedge, because you should never keep all your money in one place.

‘And you’re having your first ever Open Garden event this week?’ asks the journalist.

Martin Lomax nods. He was looking forward to it. To showing off what he had created. He could watch from an upstairs window as people enjoyed themselves. If anyone decided to take a liberty, he would have them killed. But everybody else would be very welcome.

‘For the piece, we were going to describe you as a “businessman”. Does that suit? I read all about you – private insurance services, was that it? I wonder if that would just confuse people. “Businessman” usually does the trick, or if it’s a woman, “mum and entrepreneur”. Sometimes we’ll say “heir to the something fortune”. But you’re happy with “businessman”?’

Martin Lomax nods. He had a Ukrainian coming to the house this afternoon. The Ukrainian has just agreed to buy some decommissioned Saudi anti-aircraft missiles for twelve million dollars and is planning to kidnap a racehorse as down payment.

‘The chrysanthemums are beautiful,’ says the woman. ‘Exquisite.’

A kidnapped racehorse was not ideal, as far as Martin Lomax was concerned, but if both sides were happy with the arrangement he has ample stabling by the paddock. He has done business with the Ukrainians before and found them violent but trustworthy. Martin Lomax will get the local Scout troop to run a refreshment stall on one of the Open Garden days. Water and so on. People need water, he has noticed. They go crazy for the stuff.

‘Dawn,’ calls the journalist to the photographer. ‘Can you get some shots of this mulch? It’s imported from Crete.’

No plastic water bottles, though; people would complain, and he wouldn’t want anything to spoil the experience. Thinking it through now, he realizes he will have to keep people away from the stables, just in case. And, of course, away from the house, that goes without saying. And away from the bodies in the cesspit, though who would go near that, anyway? And no digging. There are grenades somewhere. For the life of him he can’t remember where they are buried, but he knows they are in a safe location, and he has written it down somewhere. Under the Venetian gazebo? On reflection, he can’t even remember whose grenades they were, or why he had agreed to bury them, but that comes with age.

‘We don’t need any biographical detail, Mr Lomax, but people like it sometimes. Can I mention a wife? Children?’

Martin Lomax shakes his head. ‘One-man band.’

‘That’s absolutely fine. It’s all about the gardens, really.’

Martin Lomax nods. After the Ukrainian, he would have to deal with that other matter. The break-in. He had handled it very nicely so far. You shouldn’t really mess with MI5, he knows that, and he would far rather be friend than foe. But twenty million is twenty million when all’s said and done. He is certain that somebody will end up dead, and he just needs to make sure it’s not him.

‘Do you think, I wonder, that I might use your bathroom?’ asks the journalist. ‘Long trip here, long trip back.’

‘Of course,’ says Martin Lomax. ‘There’s one in the equipment shed. You see it? Behind the fountain? I don’t think there’s paper, so use whatever’s at hand.’

‘Oh, yes, certainly, certainly,’ says the journalist. ‘Don’t suppose I could be cheeky and go in the house?’

Martin Lomax shakes his head again. ‘The equipment shed is nearer.’

No one ever comes in the house unless it’s business. No one. First it’s toilets, and then you never know what. MI5 think they can just break in? We’ll see about that. Martin Lomax has many friends. Saudi princes, a one-eyed Kazakh with a one-eyed Rottweiler. Both the Kazakh and the Rottweiler would rip you apart without hesitation. No one comes into the house without his invitation.

Martin Lomax looks around the gardens once more. How lucky he is to live among such beauty. It was a wonderful world when you thought about it. But enough reflection for the moment, he had anti-aircraft missiles to worry about. And maybe he should bake some biscuits for the Open Garden too? Perhaps some brownies?

He hears an ancient toilet flush and, in the distance, the first vibrations of an approaching helicopter.

White chocolate and raspberry? People would like them, he’s sure of it.

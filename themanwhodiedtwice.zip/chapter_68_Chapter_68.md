## 68

Donna is drinking whisky on Chris’s sofa. They have just been watching _Succession_, her favourite show. Billions of pounds, family rows, people in and out of helicopters every five minutes. She could handle a bit of that. Chris has never seen it, because he is nearly fifty-two, and never watches anything new unless he is forced to. She knows he would happily watch repeats of _The Inbetweeners_ and _Ramsay’s Kitchen Nightmares_ until the day he dies.

Chris is currently on FaceTime with her mum.

‘Wish you were here, Patsy,’ he is saying.

Patsy? Christ! Also, ‘Wish you were here’? My company not up to scratch?

Patrice replies, ‘I’m coming down on Sunday, Big Bear.’

Donna can’t help but smile. Let them enjoy themselves. The chat with Ibrahim has done her good. Life was not running away from her. Just the opposite, she was running away from life. So onwards and upwards. All that nonsense.

There is a ring on her mum’s doorbell and she says, ‘Hold on, gorgeous, let me get that.’

‘Leave it,’ says Chris quickly. Donna looks up. That doesn’t sound like him. But Patrice ignores him, of course; it runs in the family.

‘Leave it?’ asks Donna.

Chris dismisses her with his hand. ‘I was just enjoying chatting.’ His eyes flick back to the screen. Patrice is still not there.

Donna tilts her head. ‘Is something up?’

‘Stop being such a police officer, Donna,’ says Chris.

‘What a mentor you are,’ says Donna. ‘Every day I’m learning.’

Patrice is still not back. Chris starts to whistle. But his leg is jiggling up and down at speed. Something isn’t adding up here.

‘So did you enjoy _Succession_?’ Donna asks.

‘Yep, yep,’ says Chris, but his eyes don’t leave the empty screen. The top of a sofa, a dying pot plant and an old school photo of Donna with a missing front tooth.

‘You looking at an empty screen instead of me?’

‘Sorry,’ says Chris, and gives Donna the briefest of glances before looking back at his computer. What was going on here? Perhaps he’s in love? He’d better be.

‘You’re not hiding anyth–’

Donna is interrupted by the return of Patrice. ‘Sorry, dear, it was the Lib Dems at the door. I had to put them straight on tuition fees.’

Chris’s leg has stopped jiggling. And he has sucked his stomach in again.

Donna’s phone buzzes. A message from Elizabeth.

_You are cordially invited to a meeting of the Thursday Murder Club, tomorrow at eleven in the Jigsaw Room. I recommend attendance._

## 83

Lance James had kept the leaflet that Joyce had sent him. It was too expensive, but a man could dream, couldn’t he? He was very glad he kept it, and he had booked the appointment as soon as the money from the diamonds had come through.

He looks around the room, bigger than his whole flat. Oak-panelled. Carpet, actual carpet. Two huge windows overlooking Dublin Bay.

It had been chaos at the end of the pier. The report had taken him a long time to write. Who shot who and why. Leave a few things out, invent a couple of things that perhaps hadn’t happened. The footage from the monitors had disappeared, so all that was left was the word of Lance, Bogdan and Connie. Lance and Bogdan had met for a pint, got their stories straight, and that was that. The report was all true enough in the end. He’d written worse.

The main thing he had left out, of course, was the two diamonds. They were just sitting there on the desk, for heaven’s sake, twinkling like pennies in a fountain. He had slipped them into his pocket, because what was the alternative? Where would they go otherwise?

It was the first time Lance had done something illegal, and it would be the last. Well, he had once driven a hire car on holiday with Ruth when, technically, he had been uninsured. But that was about it.

If you are going to commit one major crime in your life, Lance reasons, make it stealing diamonds from the mafia.

They had given him a few days’ leave after the shootout on the pier, told him to take some time to relax. Relax? In the tiny flat he didn’t own? With the kitchen wall still half demolished? The builder had, unsurprisingly, not returned to finish the job.

So Lance had taken the ferry to Zeebrugge, then the train to Antwerp, then a cab to the jewellery district, and the address he had been given by an arms dealer who owed him a favour.

The diamonds as a whole had been worth twenty million, that much he knew. So what were the two he had slipped into his pocket worth? A million? Dare he dream two or three million? He had been looking through the Rightmove app all the way there.

Sue Reardon had told him about Elizabeth Best when this all began. Her reputation, her bravery, her cunning. A legend of the Service. He had expected – and, in retrospect, Sue must have expected too – that her powers would have deserted her. Sue must have thought Elizabeth Best was an easy touch.

But Sue would have a long time to regret her misjudgement of Elizabeth.

So Lance should have known really, when he was on the train, looking at all the expensive houses.

The jeweller had examined the stones, nodding and smiling. ‘These are nice, these are very nice,’ he’d been saying. Where had Lance got them?

Lance told him that a relative had died.

‘You have papers?’

‘Afraid not.’

The jeweller had shrugged. No matter. Then he had put down his eyeglass.

‘Very nice indeed. I can offer you thirty thousand.’

Lance must have looked shocked, because the jeweller had immediately said, ‘OK, OK, thirty-five.’

Yes, of course, Lance should have known. He should have known Elizabeth wouldn’t have left a million, or two or three, in the hands of Connie Johnson, or whoever else might have ended up with the diamonds in the chaos. She had given Connie the runts of the litter. Thirty thousand pounds, out of twenty million. Lance had started to laugh. He wouldn’t have been able to spend a million anyway. The Service does yearly audits, unusual spending, extravagances. Checking the Russians or the Saudis weren’t paying you. Or that you hadn’t just stolen some diamonds from the mafia. Spending three million would have been virtually impossible.

But spending thirty-five thousand? That had been a breeze. He had bought Ruth out of the flat. Of course, she hadn’t asked him where he had got the money, because, to Ruth, twenty-five thousand pounds was insignificant.

And the other ten thousand? Well, that’s why he was here, in this grand room in Dublin, with its oak panels, and beautiful windows. With the coffee table, stacked with magazines not to read, while he waits.

He likes to think about what happened to the rest of the twenty million. What has Elizabeth done with it? Maybe she has kept it? Perhaps Sue could have bought her off after all? Lance doubts it very much though. He wonders if, one day, he might be allowed to ask her. He hopes so, he would certainly like to meet her again.

Lance picks up the _Sunday Telegraph_ magazine. The cover image is familiar. ‘Hidden Treasure – Is This the Most Beautiful Garden in England?’ Hidden treasure indeed, he thinks, and wonders what the eventual new owners of Martin Lomax’s house might dig up around the place.

As he flicks to the article, the nicely groomed man behind the desk in the corner says, ‘Doctor Morris will see you now.’

Lance gets to his feet and, for once, runs his fingers through his hair. It’ll be good to remember what it feels like before the transplant.

‘Thank you,’ says Lance.

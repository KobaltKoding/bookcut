## 27

Elizabeth walks out of the kitchen. If someone has been in the house, Elizabeth is sure they have gone. That’s her instinct, but she still puts a finger to her lips and motions for Joyce to stay exactly where she is. She nudges open the living-room door with her foot. Nothing. Two armchairs, two side tables, a sideboard with a radio and a vase of flowers on it. No body, no blood – that was something. That gave Elizabeth some hope. She knows she will have to climb the stairs. If anyone is here then she knows how vulnerable she will be. No weapon. She turns back into the hallway and sees that Joyce is no longer there. There is a momentary panic until she sees Joyce emerge silently from the kitchen, a knife in either hand. Elizabeth nods.

Joyce hands over the bigger knife to Elizabeth. As she is handing it over she whispers, ‘Careful, handle first.’

Elizabeth feels her heart thumping against her ribcage. Fast, but strong. How lucky she is.

Is there someone in the house? Has she walked into a trap? Worse than that, has she brought Joyce into the trap with her?

She motions for Joyce to stay downstairs and she begins to climb.

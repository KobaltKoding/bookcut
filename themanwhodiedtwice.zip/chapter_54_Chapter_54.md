## 54

## Joyce

You will never guess what?

Kendrick had been looking at the security footage from the Left Luggage Office. This is Ron and Ibrahim’s idea of an appropriate project for an eight-year-old. Anyway, he spotted that the figure in the motorcycle helmet was wearing one of my friendship bracelets!

You really could tell it was one of mine. I don’t think anybody else makes them quite like me.

You can imagine the fun we had next.

Who was our biker? Ibrahim made a list on his computer of all the people I had given friendship bracelets to. No one from the mafia, for starters, so that was Ron out of the water. He came up with an elaborate scenario in which I had been seduced by an elderly Italian-American on the minibus and we all had a good giggle. Chance would be a fine thing. You can see he’s disappointed though.

The four of us were on the list, of course, and Kendrick. Imagine if it was Kendrick? In a book it would be. Wouldn’t it be fun to be in a book? I bet my hip wouldn’t hurt so much in a book.

Then a few more interesting names. Sue Reardon has a bracelet. Could it have been her? Might Douglas have told her where he had left the diamonds? Elizabeth says she would have taken the crisp packet though.

Lance? Less likely that Douglas might have told him, but more likely he’d have missed the crisp packet.

Siobhan, Poppy’s mum, has one. Had Douglas told Poppy, and Poppy told her mum? Siobhan seems very quiet and unassuming, but don’t we all?

Martin Lomax? But I didn’t give him a bracelet until after the CCTV was taken. Also, I know I’m not one to blow my own trumpet, but I am fairly sure his went in the bin the moment we left. I did pay in his five-pound cheque to Living With Dementia by the way. Even the woman at the bank looked like she hadn’t seen a cheque for years.

So, who else? A few people from around the village, Colin Clemence, Gordon Playfair, Jane from Larkin who is having an affair with Geoff Weekes, and don’t we all know it? In fact, she gave hers to Geoff Weekes, so I suppose we have to count him too.

And then Bogdan, of course. I nearly forgot him.

We talked for an hour or so. Who, why, when, what? Then Mark arrived in his taxi, time for Kendrick to go home. We had a big cuddle.

Ibrahim fell asleep – he’s still not at his best – so Elizabeth and I left. Ron said he’d be back to watch his film once he’d dropped Kendrick off.

Now, here’s the thing, just between you and me.

The moment I said goodbye to Elizabeth, I had a thought. About how to identify the biker for certain. I was going to call after her, but I thought, no, Joyce, for once in your life why not fly solo? You don’t always need Elizabeth.

And so this morning I took the minibus down to Fairhaven. I did the same walk, along the same streets, to Fairhaven station. A bit slower than last time, because Elizabeth is a strider. I know she doesn’t mean to be, but she is.

I made straight for the Left-Luggage Office and, as I’d hoped, the nice girl with the hair and the headphones was on duty. She even recognized me, which made my day. No one ever recognizes me.

She took off her pretend headphones, and I asked her how she was, and she said she was fine, thank you. And I asked her if she was still having trouble with the manager of Costa, and she said that, if anything, it was getting worse, and he had even offered her a lift home on his motorbike. I told her that, for what it was worth, my experience of men with motorbikes was really very poor, and we laughed like the women of the world neither of us really is. She asked if I needed something from my locker, and I told her I needed something from her, and that it was funny we were talking about motorcycles, and that got her attention.

You see, the thought I’d had, when I left Elizabeth last night, was that the girl at the Left Luggage desk took her job seriously, and did it properly. I thought there was no way she’d let someone walk into the locker area willy-nilly wearing a motorcycle helmet. And it turns out I was right.

She apologized that she didn’t remember the day in question – her job is quite boring, the way she was telling it – but confirmed that she would never let anyone into the lockers without seeing a key, and without seeing a face. So anyone wearing a helmet would have to take it off. I asked if there was CCTV in the desk area, and she said there was because her predecessor had been fired for watching pornography on his laptop while he was working. She said she didn’t blame him, as the days can start to drag.

I thanked her, and she asked what it was all about, and I said I couldn’t tell her, because it was government business. Well, the look on her face. Imagine me saying that if Elizabeth was there, though? I don’t think so. I should do more things by myself.

Then I made the same trip we did last time, through the streets to Fairhaven Police Station to tell Donna about the CCTV. Of course, I forget that Elizabeth always seems to know when Donna is on duty, and Donna wasn’t there. So perhaps I shouldn’t do more things by myself? It is a tightrope.

When I got home, I told Elizabeth what I had done, and she was delighted by my ingenuity, but also annoyed that she hadn’t thought of it. ‘Why didn’t you tell me, Joyce?’ she said, and I said that I’d only thought of it on the minibus. Then she told me I was a terrible liar, which, of course, I am. I promised her I wouldn’t do things by myself in future, but she told me never to make a promise I couldn’t keep.

Elizabeth has sent Donna a message about the CCTV, so perhaps we shall soon find out who opened the locker. And, presumably, that might tell us who killed Douglas and Poppy?

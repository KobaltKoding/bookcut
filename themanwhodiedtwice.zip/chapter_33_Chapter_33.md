## 33

They had told her to pack a small suitcase, that she needed to come with them. It was already packed.

The officers would be expecting tears, but she couldn’t make the tears come. Would they judge her? Would they think she didn’t love Poppy? That she was a bad mother? Siobhan supposed that they had seen every sort of reaction possible in their time. She should just be herself. Whoever that was now.

The journey seemed long, but Siobhan couldn’t sleep. The two officers talked a little in the car. Was she OK? No, not really. Did she need anything? If they meant a drink or a snack, then no, she didn’t. Was she up to doing the identification tonight? Well, she honestly had no idea. They repeated their condolences a number of times, and she thanked them each time.

They reached Godalming just after midnight. Despite the lateness of the hour they passed a van on the long driveway. Travelling in the opposite direction, away from the house.

Sue Reardon and Lance James had introduced themselves. They were both polite, but then what alternative did they have? Sue was exactly as she had expected. Exactly the type she had pictured.

And now they are walking down a long corridor in a building that must once have been stables. Lance is leading the way. You can see he doesn’t know what to say. She would be the same.

Sue Reardon has slipped her arm through Siobhan’s, which can’t be standard procedure, but there was a time for standard procedure, and this was not it. Siobhan is grateful for the gesture. She knows what lies ahead. What must be done.

Lance takes out a key card and opens a large metal door, knocking on it as it opens. A blast of chill air bends around the door and into the corridor. Sue Reardon stops for a moment and looks Siobhan in the eyes.

‘Are you ready?’

Siobhan nods.

‘I’m here if you need me.’

Sue lets Siobhan walk into the room first, and she shivers as the cold air envelops her.

The room is small and functional. There are two long tables, and a shrouded figure lies on each. The figure on the left must be Poppy, because there is a doctor standing beside it. At least Siobhan assumes it’s a doctor. She is wearing a white coat, and surgical gloves and a mask. She has kind eyes, and that almost makes Siobhan cry for the first time. She doesn’t need kindness at the moment.

Lance rests against the far wall, a man in a room in which he does not want to be. Siobhan sees that he reflexively starts to rub his hands together for warmth, but thinks better of it, and plants them behind his back instead. Sue’s hand is at her elbow.

‘This is Doctor Carter, Siobhan.’

Doctor Carter nods at Siobhan, and Siobhan has to look away from the kind eyes.

‘I’m afraid your daughter has traumatic injuries. I would ask you to prepare yourself.’

Siobhan nods. Here goes.

Doctor Carter pulls back the pale green sheet covering the body and, as the unruly blonde hair begins to spill out, Siobhan knows she has to shut a part of herself down. A part she may never get back.

There was little of the face left, but enough. Enough for a mother to tell her own daughter. Siobhan turns back to Sue and nods.

‘It’s Poppy.’

Siobhan starts to cry now. She knew it would come. Nobody should have to do this. Sue places a hand on her shoulder.

‘Siobhan, I just need to ask you a couple of other questions. Because of the injuries. Any other distinguishing features you could tell us?’

Siobhan gulps in air. ‘She has a long scar on the back of her left calf, barbed wire on the Isle of Wight. And her left wrist has a lump, she broke it playing hockey. And the stupid tattoo.’

Sue looks over to Doctor Carter, who nods.

‘Thank you, Siobhan,’ says Sue. ‘Would you like to spend a bit more time here? No one is in a rush.’

Siobhan doesn’t want to turn back to see the body lying there. She has seen enough. Has an image to last her until her dying day.

‘Or we can go somewhere warm? Have a cup of tea?’

Siobhan nods through her tears. She turns back to the body. Doctor Carter has pulled the sheet back over Poppy’s face. The blonde hair still peeks out. Siobhan gently reaches out her hand and strokes a loose strand.

Lance, Sue and Doctor Carter all stay quiet as Siobhan strokes the blonde hair and weeps.

Traumatic injuries, thinks Siobhan. Well, that’s the truth.

Siobhan takes her hand away and Sue puts an arm around her.

‘Let’s get you out of here,’ says Sue.

Siobhan looks over to the figure on the other table. ‘And that’s the other one? That’s Douglas?’

‘Yes,’ says Sue. ‘That’s Douglas.’

‘And some poor soul has to come in and identify him too?’

Sue shakes her head. ‘Fortunately not. No next of kin. So fingerprints, dental records, whatever we have on file.’

‘Well, God bless him, I suppose,’ says Siobhan, and Sue leads her out of the room.

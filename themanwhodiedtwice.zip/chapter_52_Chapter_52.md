## 52

Lance James settles into a huge white sofa next to Sue Reardon. The whole house smells of white fig and pomegranate. He knows that smell well. Or used to before Ruth moved out, taking her candles with her. He will sometimes light a match after he has been to the bathroom, but that’s as new-age as Lance gets.

‘Do you have a cleaner, Mr Lomax?’ Sue Reardon asks. ‘A white sofa is a very bold choice.’

‘A woman from the village has done it for years,’ says Martin Lomax. ‘Margery, or Maggie, something like that. Thank you so much for popping in, I don’t like to travel. I get car sick.’

‘It’s no problem at all, Lance was only at the bottom of your drive taking photos,’ says Sue. ‘And I’m not busy, just investigating the deaths of a couple of colleagues.’

‘Investigating?’ says Martin Lomax. ‘I assumed you killed them? Did you not?’

‘Believe it or not, no, we didn’t. We assumed that you killed them,’ says Lance.

Martin Lomax juts out a lip and nods. ‘Well, we can’t both be right. They’re dead, though, that’s the main thing.’

‘Yes, that’s some common ground,’ agrees Sue. ‘How does it work with you having a cleaner? Aren’t you worried she’ll stumble across something?’

‘I always tidy up before she comes round. Don’t you?’

‘Well, I’ll tidy away some magazines and do the washing-up,’ says Sue.

‘I’m like that, too. Always hurrying around half an hour before she arrives, I’ve always left something out, a brick of cocaine or some such. I’ve got so lazy with tidying up my things over the years.’

‘Hence leaving the diamonds lying about, of course,’ chides Sue.

‘Well, quite,’ agrees Lomax. ‘Anyway, then I put Radio 4 on for her, and away she goes. How many people have you killed, do you think?’

‘Eight or nine,’ says Sue. ‘You?’

‘Same, pretty much,’ says Martin Lomax.

Lance looks around. They are in a conservatory with beautiful views of the gardens. There is some stray bunting hanging from a eucalyptus tree. They must have had an event. Martin Lomax has yet to offer them a coffee, or even a glass of water. It doesn’t seem to be a power play, it just seems not to have occurred to him.

‘I know this is boring,’ says Lomax, ‘and I know I bang on about it, but I really do need to find those diamonds.’

‘Likewise,’ says Sue.

‘Well, you don’t really _need_ to find them, do you?’

‘I’m afraid we do,’ says Lance.

‘Not really, though. Obviously, you’d look good if you found them. Obviously, people would be pleased with you. But they’re not your diamonds, Sue, are they?’

‘Well, they’re not yours either, are they?’ says Sue.

‘I read a book once where the mafia had somebody ripped apart by tigers,’ says Lomax. ‘At a private zoo. Can you imagine?’

‘Well, I’m afraid we don’t have the diamonds,’ says Sue. ‘And we have no idea where they are.’

‘Rats,’ says Martin Lomax. ‘In my head you killed them, some big cover-up. You hear about it with your gang, don’t you? Tortured the information out of them?’

‘We didn’t,’ says Lance.

‘Can you not just give Frank Andrade his twenty million pounds?’ says Sue. ‘Just give him cash and call it quits?’

‘My assets tend to be illiquid. And they also tend to belong to someone else. I could steal from the Mexicans to pay the mafia, then steal from the Serbians to pay the Mexicans. I’d be the old lady who swallowed the fly, and where would that leave me?’

‘Dead, of course,’ says Sue Reardon.

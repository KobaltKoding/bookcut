## 24

Selling cocaine is less glamorous than people imagine, and Connie Johnson is thinking that it is nice to have the opportunity to dress up for once.

It’s not every day that Bogdan Jankowski wants to buy ten grand’s worth of prime Colombian blow and Connie has been excited all day. The lock-up next door sells fake perfume, and she had dabbed some on earlier, only to have to wash it off immediately as the smell overpowered her. She has even had to reapply her mascara after the tears streamed down her face. She thinks she has got rid of the worst of it.

Why did Bogdan want coke all of a sudden? He wasn’t the type at all. Perhaps he had developed a drug problem, and needed to fund his habit? Connie hopes so; it would certainly mean she would see more of him.

What was it about him? The sense of extreme danger and absolute safety in the same man? Or just the looks?

There is a rattling knock on the metal lock-up door. Connie adjusts her hair, spits her gum into an old filing cabinet and lights a menthol cigarette. Here we go.

She opens the door, sunshine floods into her dark world and there he is. Bogdan. Shaven-headed, tattoos snaking up both arms, deep blue eyes and an expression of total indifference. The full package. He shuts the door behind him and it is just the two of them. How should she play this? Nice and cool? She had tried flirting with Bogdan before and it had got her nowhere. But she suspects he had just been playing hard to get. Is he undressing her with his eyes? Connie thinks so. He’s certainly doing something with his eyes. She nods down at his sports bag.

‘That the money?’

Bogdan nods. ‘Yes.’

Connie takes a long drag on her menthol cigarette, savouring the fresh minty taste.

‘Ten grand?’

‘Yes,’ says Bogdan.

‘Do I need to count it?’

‘No,’ says Bogdan, and puts the bag down on Connie’s large, wooden desk.

When Connie’s old secondary school closed they auctioned off the contents, and Connie bid on, and bought, the desk of her old headmistress. The desk she had stood across from so many times, being reprimanded for this, that and the other. For a while she delighted in using it to weigh out cocaine and to have sex. What would Mrs Gilbert have to say about that? Now business has expanded, however, she uses it mainly for admin. She has to admit, it is a good desk.

‘So you’ll be wanting your coke, then?’ asks Connie.

‘Yes,’ says Bogdan, before adding, ‘please.’

Connie senses this is going well. Is there a connection here? Electricity? My God, just look at him.

‘It’s out the back, Bogdan. Give me a minute, make yourself at home, there’s magazines. Mainly _Ultimate Fighting_.’

Connie opens a padlocked door and walks into a small storage room. There is no mirror here, so she checks herself in the reflection of an old CD-ROM. She is glad she does, as she has a little lipstick on her teeth. Had Bogdan noticed? She kneels in front of a safe and keys in the combination with one hand while rubbing her front teeth with the other. What if he had noticed the lipstick, and now notices she’s rubbed it away? She takes out a kilo of cocaine from the safe, wrapped in brown paper and stamped ‘Fragile – This Way Up’. If he notices then he’ll know she’s checked herself out in the mirror. Will that look too needy? She locks the safe again and heads back out. Too late now, if he notices, he notices. Best foot forward.

Connie padlocks the storage door once again and puts the package on her headmistress’s desk next to the money. Bogdan is looking straight at her. At her teeth?

‘You need to check it?’ asks Connie.

‘No,’ says Bogdan. He takes the money from the sports holdall, and replaces it with the package.

‘This going to be a regular thing, is it?’ asks Connie. ‘There’s special treatment for regulars.’

‘No, just this once,’ says Bogdan.

‘Special treatment’ was too far, thinks Connie. Too flirty. Idiot. She decides to shrug.

‘Well, you know your own business.’

Bogdan nods. ‘Yes.’

‘Let me get the door for you.’ Connie walks over and opens the door. That sunshine again. Bogdan walks through, ducking his head slightly as he does.

‘Thank you, Connie.’

Connie shrugs again – perfect – and shuts the door behind him. She falls back against the closed door and lets out a huge breath.

Christ, that was intense. She’s going to have to take the rest of the day off.

Bogdan doesn’t have far to walk. He is meeting Ron by the pier. It had gone OK with Connie, there didn’t seem to be any hard feelings. He had felt for her because she had lipstick on her teeth. He was going to mention it, because it looked like she was going on a date later. But she had obviously noticed herself as it was gone when she came back with the cocaine. He was relieved he didn’t have to mention it, as she didn’t seem in a very good mood with him.

He is glad to be outside, not least because there was an awful smell.

Bogdan spots Ron and walks up to him. Ron is dressed as a plumber.

‘All right, Bogdan,’ says Ron.

‘Hello, Ron,’ says Bogdan.

‘That it, then?’ says Ron, indicating the bag.

‘Yep, that’s it,’ says Bogdan.

‘Good lad. I bet you’re wondering why I’m dressed like a plumber?’

Bogdan shakes his head. ‘Not really. Nothing with you lot surprises me. I’d be more surprised if you weren’t dressed like a plumber.’

Ron nods, agreeing that’s a fair point.

‘How is Ibrahim?’ asks Bogdan. ‘When is he back?’

‘He’s all right, old son. Knocked about a bit, you know? Nasty.’

Bogdan nods. ‘You need help with the guy who did it?’

Ron takes the bag. ‘You’re already helping.’

‘I thought so,’ says Bogdan. ‘Good, I am pleased. You know you just ask, and I do whatever.’

‘You’re a good lad.’ Ron sniffs. ‘Jesus, Bogdan, what’s that smell?’

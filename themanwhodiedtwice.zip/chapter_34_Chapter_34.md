## 34

Elizabeth is rearranging some of the ornaments the MI5 team had misplaced during their search of the flat. She prefers everything in its place. The Delft fisherman Stephen had bought from a Bruges flea market, sitting next to Penny’s police badge, sitting next to the shattered Soviet shell casing Elizabeth had dug from the radiator of her Triumph Herald after a misunderstanding in Prague in 1973\. So many memories.

Her latest memento, Douglas’s locket, is in her bag, and will be staying there.

Elizabeth was surprised that Sue had let her take it away. Surely it was evidence?

Though once they’d checked it for a hidden message, she supposes Sue thought it was harmless enough. It was kind of her to let Elizabeth keep it.

She hadn’t seen it for thirty-odd years. Could barely remember it if she was honest. When Sue had taken it out, she had tried to remember what was inside it. A lock of hair? A picture of Douglas, smoking rakishly? But no, the mirror, of course.

When had he given it to her? Back in London, she thinks. An anniversary? Or had she caught Douglas cheating? Either way, he had bought her the locket. ‘Not inexpensive,’ he had revealed. And the mirror was purest flummery. ‘It feels unfair,’ he had said, ‘that I have the benefit of looking at your beautiful face any time I wish. So I wanted you to see what I see.’ Elizabeth had scoffed, she was sure of that, but nonetheless was touched.

She had left the locket behind when she had left Douglas behind, and had not thought of it since. Why on earth had he kept it? And why on earth had it been in his jacket when he died? Was this really what he wanted to show her? He was always one for a romantic gesture. Was this a final act of love?

The first thing she had done when she arrived home was, of course, to prise the mirror out with a screwdriver. There would be a hidden message behind it, she was sure of that. The location of the diamonds? Well, that really would be a final act of love, thank you, Douglas.

But there was nothing behind the mirror. No treasure map, no hidden code. So the locket was just a locket after all, and the act of love was just that, an act of love. Douglas never failed to surprise her.

Before she was loaded into the back of the van in Hove, Elizabeth had used Joyce’s phone to message Bogdan. Without hesitation, Bogdan had come and looked after Stephen for the night. Had he cancelled something important? Elizabeth has no idea what Bogdan does when he is not at work. Clearly, he spends some time at the gym and at the tattooist but, other than that, he is a mystery.

Elizabeth is thinking about Martin Lomax. It is obvious that he killed Douglas and Poppy, surely? Too obvious? Perhaps they should just pop up to see him? If the secret wasn’t in the locket, they were going to have to start their search somewhere.

Stephen is asleep and Bogdan is sitting patiently by the chess board.

‘At first he was asleep, you know Stephen,’ says Bogdan. ‘But then they needed to search your room, so I woke him up.’

‘And he was fine about it?’ asks Elizabeth. She weighs up Penny’s badge in her hand. Her most recent memento.

‘Oh, he loved it,’ says Bogdan. ‘Asking what they are looking for, helping them to look, telling stories.’

‘They tidied up very nicely,’ says Elizabeth.

‘Well, I had to help a bit,’ says Bogdan. ‘So, what were they looking for? Can you tell me?’

‘They were looking for my phone. They wanted to see the message Douglas had sent me. But I’d taken some pictures of the corpses and I didn’t want to lose them.’ Elizabeth had filled Bogdan in on the deaths of Douglas and Poppy. Bogdan had nodded at length and said ‘I see’.

‘Yes, you never know when you might need pictures of corpses,’ agrees Bogdan. ‘But your phone isn’t here? They looked in a lot of places.’

‘No, it’s behind a loose brick in a low wall outside 41 St Albans Avenue in Hove,’ says Elizabeth. ‘You wouldn’t be a dear and go and fetch it for me later, would you?’

‘Of course,’ says Bogdan.

‘And you’ll remember the address?’

‘Of course,’ says Bogdan. ‘I remember everything.’

‘Thank you,’ says Elizabeth.

‘And I gave Ron the cocaine by the pier like you asked.’

‘You really are a good sort, Bogdan,’ says Elizabeth.

‘He’s a terrific sort,’ says Stephen, waking, looking at the board and moving his bishop. ‘Giving Ron cocaine by the pier. Quite right, too.’

Bogdan looks down at the board.

‘Forgive me, boys,’ says Elizabeth. ‘I have a call to make. Bogdan, I’ll also need you to drive me to meet an international money launderer today, if you’re free?’

‘I can be free for that,’ says Bogdan.

She walks through to the bedroom. The bed is perfectly made. Given that Stephen had gone back to sleep after MI5 had been by, it could only have been made by Bogdan. She picks up the landline and dials Chris Hudson’s number. He picks up on the fifth ring. Slow for him.

‘DCI Chris Hudson.’

‘Chris, it’s Elizabeth. Just checking in on Ryan Baird? I wondered if there had been any developments in the case?’

‘You wondered if perhaps we’d found cocaine and a bank card in his toilet?’

‘That sort of thing.’

‘He’s been charged with possession with intent to supply, and robbery.’

‘Well, isn’t that opportune? You and Donna can tell us all about it tomorrow. There’s wine at Joyce’s.’

‘Ah, I can’t tomorrow, I’m working.’

‘No, you’re not, Chris, I checked.’

‘How did you che– no, don’t answer. OK, sorry, I’m busy tomorrow.’

Elizabeth hears a woman’s voice in the background saying, ‘Is that Elizabeth?’ Well, well, well, this must be the mystery girlfriend. None of them liked to pry, of course, but it had been a month or so now, and they had yet to be introduced. Elizabeth thinks quickly. How to play this? Joyce will be furious if she doesn’t get as much information as possible.

‘Oh, that’s fine, what are you up to, anything nice? Drinks with friends?’

‘Just a quiet night … wait a moment.’ Chris puts his hand over the mouthpiece and she hears him ask a muffled question. It sounds like, ‘Are you sure?’

‘Hello,’ a female voice comes on the line. ‘Is this Elizabeth?’

‘This is Elizabeth, yes,’ says Elizabeth. ‘To whom am I speaking?’

‘I’m Patrice, Chris’s girlfriend. More lady friend, if I’m honest. What age does that change? I’m afraid Chris and I have plans for tomorrow. But another time, perhaps?’

‘Well, another time would be lovely, Patrice, how nice to finally speak to you.’

‘And you, Elizabeth, I have heard a lot about you.’

‘Well, I wish I could say the same. But mystery is very important, isn’t it?’ Elizabeth is trying to place the accent. South London? It’s a little like Donna’s.

‘Isn’t it?’ says Patrice. ‘We might keep our mystery for a bit longer, if that’s OK. Lovely to chat to you though.’

‘And to you, dear. Say goodbye to Chris for me.’

‘I will do. See you soon, I’m sure.’

Patrice puts the phone down and Elizabeth looks at the handset for a moment. She has been put in her place, and she approves. This is exactly the sort of woman Chris needs in his life. And if she likes Chris, and if Chris likes her, then Elizabeth would like to meet her. Could Donna help, maybe? Persuade them both to come to Joyce’s? Give Patrice a couple of glasses of wine, really get to know her?

Vetting, they used to call it in the Service.

Stephen pops his head round the door. ‘A gang of your lot here last night, I meant to say. Spooks all over the place, after this, that or the other.’

‘I know, sorry about that, dear.’

‘Oh, not a bit of it. It was wonderful. Whatever they wanted, they didn’t find it. I told them, “If Elizabeth doesn’t want you to find something, you won’t find it. Simple as that, don’t waste your time, she could hide Christmas presents in a rowing boat.” I didn’t know where you’d gone, I thought the shops, but it was very late.’

‘Joyce and I were up chatting.’

‘I told them any time. Open door to spooks round here. What was it? Somebody murdered?’

‘Two people murdered.’

‘Spies?’

‘Yes.’

‘Wonderful. Now what was I doing, dear?’

‘Playing chess with Bogdan.’

‘Oh, good. He made me scrambled eggs. And he gave Ron cocaine. What a champ. I’ll get back to him. I’ll leave you to your murdered spies.’

Two murdered spies. Two murdered spies. Elizabeth picks up the phone and rings Chris Hudson again. This time it takes him even longer to answer. Seven rings. Just long enough for a whispered argument about whether to answer it. He obviously recognizes her landline now.

‘Yes, Elizabeth,’ says Chris.

‘Oh, hello Chris,’ says Elizabeth. ‘I’m sorry, could you put Patrice on?’

‘Patrice?’

‘Yes, please, dear, no offence.’

There is a pause, a hand over the mouthpiece once again, and another muffled chat.

‘Hello, Elizabeth,’ says Patrice.

‘Hello, dear, I’m sorry to bother you again. I don’t know what you’re doing tomorrow?’

‘Agreed,’ says Patrice.

‘And I don’t want to know, of course, your business. But I’m about to tell you something I haven’t told Chris yet.’

‘I’ll give you thirty seconds, Elizabeth. I was being massaged.’

‘Oh, good for Chris,’ says Elizabeth. ‘Here’s my pitch, dear. Yesterday afternoon two spies were shot dead in a house in Hove. I was there. It won’t be a police matter, it has gone straight to MI5, but I would love to talk to Chris about it and get his take. And I just thought that, if you wanted to come over with him – perhaps tomorrow evening? – you sound the sort of person who might be interested in the details of two spies being murdered. I have pictures and everything, and there will be wine, and I know everyone would be thrilled to meet you. As I say, I don’t know your plans.’

‘Well, we were going to Zizzi’s.’

Nearly got her, thinks Elizabeth. How to close the deal though?

‘And one of the spies who was murdered just happened to be my ex-husband.’

‘OK,’ says Patrice. ‘We’ll bring a bottle.’

Elizabeth hears Patrice call away from the phone, ‘We’re seeing Elizabeth tomorrow, babes,’ and hears Chris reply, ‘Well, of course we are.’

‘Shall we say six thirty?’ says Elizabeth. ‘And could you ask Chris to invite Donna, too?’

‘Donna?’ asks Patrice.

‘Yes, wouldn’t be the same without her. I’m assuming you’ve met Donna?’

‘Oh yes, I’ve met Donna,’ says Patrice. ‘Once or twice.’

‘See you tomorrow, dear,’ says Elizabeth, and puts down the phone. So Patrice has already met Donna? Must be serious.

Right, on to Martin Lomax.

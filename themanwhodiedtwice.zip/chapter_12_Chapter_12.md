## 12

‘And that’s it in a nutshell. No need for drama, and no need to look at me, jaws agape.’

Elizabeth finishes her story and sits back in the low chair. For a moment the only sound is Ibrahim’s heart monitor.

‘But diamonds?’ says Ibrahim, pushing himself up in his hospital bed.

‘Yes,’ says Elizabeth.

‘Twenty million quid’s worth of diamonds?’ says Ron, who had stood still throughout the story, but is now pacing. Joyce had brought him fresh underwear from home, and he had dutifully changed in the disabled toilet, even though his present underwear easily had another day in it.

‘Yes,’ says Elizabeth, rolling her eyes. ‘Any more obvious questions?’

Ibrahim, Joyce and Ron look at each other.

‘He’s your ex-husband?’ says Ibrahim.

‘He is, yes,’ says Elizabeth. ‘With respect to the three of you, this is tiresome. Any questions about anything I haven’t covered?’

‘And we’ll get to meet him?’ asks Ron. ‘In the flesh?’

‘Unfortunately, yes,’ says Elizabeth.

Ron and Ibrahim are shaking their heads in wonder. Elizabeth turns to Joyce.

‘Joyce, you’re very quiet. Nothing to ask about the diamonds or the ex-husband? Or the mafia? Or the Colombians?’

Joyce shifts forward in her seat. ‘Well, I have plenty to say about it all, and I’m excited to meet Douglas. I bet he’s handsome. Is he handsome?’

‘A bit too obviously handsome,’ says Elizabeth. ‘If you know the sort of thing.’

‘Ooh, I do know that sort of thing,’ says Joyce. ‘You can’t be obvious enough for me.’

‘Not as handsome as Stephen, though,’ says Elizabeth.

‘Oh, no one’s as handsome as Stephen,’ says Joyce. ‘But, honestly, all I was really thinking, all the way through, was that it explains Poppy’s nails.’

‘Yes, I could see the penny drop,’ says Elizabeth.

A nurse walks into the room to fill Ibrahim’s water jug and the friends fall silent and nod their thanks. She leaves.

‘I am conventionally handsome,’ says Ibrahim.

‘Not at the moment you’re not,’ says Ron.

‘So you need us to look out for him?’ asks Joyce. ‘Like bodyguards?’

‘Hardly bodyguards, Joyce,’ says Elizabeth.

‘We’re guarding his body,’ says Ron.

‘All right, bodyguards then, Ron, as you wish.’

Ron nods. ‘Yep, I do wish.’

‘Well, the invitation is there,’ says Elizabeth. ‘If you’re too busy, then don’t.’

‘I can fit it in,’ says Ron. ‘We getting paid?’

‘After a fashion, yes,’ says Elizabeth. ‘Douglas and Poppy have agreed to give us information on Ryan Baird.’

‘Ryan Baird?’ asks Ron.

‘That’s the name of the boy who stole Ibrahim’s phone,’ says Joyce.

‘Oh,’ says Ibrahim.

‘Ryan Baird,’ says Ron. ‘Ryan Baird.’

‘I didn’t … I don’t think I like him having a surname,’ says Ibrahim. ‘I think it’s harder to pretend it never happened when he has a surname. I don’t … sorry, I’m not sure about this at all.’

‘I know,’ says Elizabeth. ‘I understand. We’re taking care of it.’

‘Revenge is what you need,’ says Ron. ‘Beaten up, locked up, whatever Elizabeth’s got in store.’

‘I don’t really believe in revenge,’ says Ibrahim.

‘I knew it,’ says Joyce quietly.

‘Well, I do,’ says Ron.

‘As do I,’ says Elizabeth. ‘So the matter is decided, I’m afraid. Now, let’s agree to speak his name no more.’

The room falls quiet. Ibrahim tilts his head back. He grimaces slightly.

‘What do you think Douglas has done with the diamonds?’ asks Ibrahim.

‘I don’t know,’ says Elizabeth. ‘But it feels like it might be fun to find out.’

‘Let’s find them and sell ’em,’ says Ron.

‘Ooh yes!’ says Joyce. ‘Twenty million between the four of us!’

‘What do we know about Martin Lomax?’ asks Ibrahim.

‘Very little,’ says Elizabeth. ‘But if we’re protecting Douglas then I think we should find out a bit more.’

‘Ron and I can use the iPad this evening,’ says Ibrahim. ‘Do a little research.’

‘You’re staying again, Ron?’ asks Joyce.

‘Well, just another night, you know. I can flirt with the nurses, and they make a nice cup of tea.’

‘I’ll bring you more pants,’ says Joyce.

‘Honestly, no need,’ says Ron.

## 21

Douglas Middlemiss now has a view of the sea, which is some consolation at least.

The house is in Hove. Officially an ‘executive let’ but used exclusively by MI5\. Douglas was in the big bedroom at the front, with the diagonal view of the sea. They had told him to stay away from the windows but, really, give a man a sea view and what do you expect? He is currently sitting in an armchair angled to catch the sun coming up behind the spidery ruins of Brighton’s West Pier in the distance. If somebody shoots him through the window then there are worse ways to go.

Poppy is in a bedroom at the back of the house, with a view of a council car park and some bins. To get to his door, someone would have to go past Poppy’s. And she had proved surprisingly effective last time. Shooting Andrew Hastings. One of Martin Lomax’s close-protection officers, sent to kill him, but, instead, killed himself by a small woman with a nose ring and an Ottolenghi cookbook.

Moving to Coopers Chase had seemed like such a terrific idea at the time, the perfect hiding place. Also a chance to see Elizabeth again. To impose himself on her. But Martin Lomax had breached security somehow. Which meant somebody had told him where he was hiding. But who?

Douglas has his suspicions. He had messed up, that was for sure, showing his face on the security cameras. He had put the Service in a very bad position. Perhaps someone felt a debt needed to be repaid? Would they really sacrifice one of their own? He’d seen it done. Rarely, but he’d seen it. Could he trust Sue and Lance? Sue he was sure of. But Lance? The man he broke into Lomax’s house with? What did he really know about him?

Poppy knocks on the door and asks Douglas if he would like a cup of tea. He tells her that would be lovely and he’ll be down in a moment. What on earth does someone like Poppy make of someone like him, he wonders.

Douglas was no longer a popular man. He knew that, and he could see why. My God, he used to be popular. But now? Now he was the type of man to take his mask off during a robbery, and the type of man to make a joke about a gay colleague in a briefing. He meant no harm by either, but he saw he was out of step, and he knew, deep down, that a man less self-regarding than himself would have the ability to act more professionally and kindly. He had hoped to reach the end of his service without having to change one bit. Afraid not, old boy.

The diamonds were his way out. A lucky break, at a good time. Sitting there on Lomax’s dining-room table. But had his luck run out? How to get out of this one?

What has changed, he wonders. Twenty years ago and you could make jokes about whoever you liked, couldn’t you? Never to be mean, a joke was a joke was a joke. At school there had been a boy, Peter something, who they teased because he had ginger hair. Nothing mean, just jokes. He left after a few terms, too sensitive, and that was still the problem, wasn’t it? If people took offence then weren’t they just being like Peter, who had wasted a perfectly good education because he couldn’t take a bit of teasing?

Douglas had mentioned this when he was sent on a Gender and Sexuality Awareness course a few years ago. They had asked him to leave, and he was given one-on-one coaching instead. He passed with flying colours as it was run by an old friend who told him exactly what he needed to say if he wanted his certificate signed.

So perhaps the Service has finally had enough of him? Perhaps Sue thinks he is no longer useful? That life would be better with him out of the way? Perhaps she has persuaded everyone it would be a small price to pay for peace with Martin Lomax. Had Sue done a deal with Lomax, and disclosed his location?

How many other people had known that Douglas was at Coopers Chase? Five or six? Including Poppy, of course. Was she more than she appeared, with her podcasts and her poetry and her Gregorian chant music? Was that an act? He’d seen it all, to be honest, so perhaps there was more to her, perhaps she was in league with the others against him? But then why shoot the intruder?

Elizabeth? That was a bigger question. Would Elizabeth have disclosed where he was? Surely not. He had told her about Martin Lomax, though, hadn’t he? Had she tracked him down? Elizabeth could track anyone down. Douglas had had four affairs during their marriage, and Elizabeth had discovered all of them. The final one, a junior analyst named Sally Montague, had ended the marriage for ever. He had gone on to marry Sally Montague at least. Though she was twenty years his junior and that marriage only lasted until his next affair. They fired her, very discreetly, after the divorce. Where was Sally now? He knows he should probably care, but sometimes it is all too much for him.

Heaven knows how many affairs Elizabeth had had. Plenty. But Douglas had never caught her once.

You only marry one Elizabeth in your life. If Douglas was any sort of a man he could have kept hold of her. But Douglas was just a boy, he knows that. He was charming and funny, and life came easily to him. Whatever Douglas wanted, he got; everybody fell for him, everybody fell for the act. Although he supposes that people who didn’t fall for his act had probably just given him a wide berth over the years.

He had once asked Elizabeth when she had seen through him. She had said she’d known from the moment she’d met him. And she’d wondered what small, frightened boy must be hiding behind such an obvious act. She had fallen in love with that frightened boy, but was yet to meet him. Douglas could have taken that moment to turn his life round, to become real and live in honesty. But instead he threw a whisky glass against a wall and stormed out, staying the night with Sally Montague in West Kensington. The next day, when he returned, Elizabeth had said nothing, but that was the day she gave up trying.

So he has lived on his charm ever since. There were worse lives. But he has lost touch with what charming is. He sees new generations of men, who know what to say and how to say it, and he is left with the tools of a different age. Jokes he can’t tell, passes he can’t make. And without them, what has he got?

The diamonds. That’s what Douglas has got. His great escape.

Douglas gets up from his chair and pulls a comb through his hair. Some careful combing and it still stood up to cursory scrutiny, which is all that matters for most people. Cursory scrutiny had got him through most of his career. But a new generation saw right through him. Which was very annoying.

The silly thing is, Douglas knows they are right. He knows he is only being asked to be respectful, and he knows people just want to turn up to work and do their job and not be reminded every five minutes of what they look like, or who they slept with. Douglas knows they are right and he is wrong. He doesn’t miss the good old days, he misses _his_ good old days. He doesn’t suppose they were good for most people.

But to really admit that to himself would be to admit to a lifetime of wearing his comfortable blinkers. It would be admitting that he still wonders what happened to Peter. To Peter Whittock. Of course Douglas remembers his name. Bullied out of school by children who were also young and scared.

How many other Peter Whittocks had he left in his trail? How many more Elizabeths? Sally Montagues?

Twenty years ago you could leave your mask off and the whole thing would have been one big laugh, a bit of ribbing, a message to Martin Lomax to go and boil his head, and Douglas would have to buy the drinks that evening. But that had been the big mistake.

One way or another, things catch up with you.

There is no point moping, however – you get the life you deserve. Douglas resolves to think his way out of this particular spot of bother. Time to deal with the task at hand. Time to deal with the threat of Martin Lomax, and possibly a threat from inside the Service itself. Then disappear with the diamonds. New identity, maybe a farm in New Zealand, or Canada. Somewhere they spoke English.

He has to assume now that he is compromised. He has to assume that he is on his own. He can trust no one. He steps out onto the landing, hearing the kettle whistle from the kitchen.

Not true. He can trust Elizabeth. Of that he is sure.

This thought brings him some cheer. He has made it to another sunrise, and, descending the stairs, he decides he will have some marmalade on toast while he still can.

## 63

All eyes are on Joyce. She is staying silent for a moment, like a presenter waiting to announce the results on _X Factor_. The silence is filled with the hum of insects strafing the reed beds. Donna can tell she’s enjoying the attention. Good for her.

‘Oh, stop milking it, Joyce,’ says Elizabeth. ‘For goodness’ sake.’

‘I was just giving you a few more seconds to try and work it out,’ says Joyce, and takes a sip of tea from her flask.

‘I’m loving this,’ says Ron.

‘What have you worked out, Joyce?’ asks Donna.

‘Only this,’ says Joyce. ‘Elizabeth, that walk you went on with Douglas, through the woods? The same walk we did the other night?’

‘Go on,’ says Elizabeth.

‘When Douglas told you he’d stolen the diamonds, and made a point of talking about the tree? The dead-letter drop?’

‘I feel like this is going to be Elizabeth’s fault,’ says Ron approvingly.

‘Well, Poppy was with you, wasn’t she?’

‘But with headphones on, Joyce.’

‘Well, who else have we met recently wearing headphones? The lovely girl at the station. And what was she listening to?’

‘Nothing,’ says Elizabeth.

‘Nothing. So who’s to say Poppy was listening to anything on her headphones? Who’s to say she couldn’t hear every word?’

‘Beautiful,’ says Ron.

‘So she heard Douglas confess, and she heard about the old dead-letter drop,’ says Ibrahim.

‘And then she put two and two together, just like you did,’ says Joyce.

‘Then came back up the hill, found the note, read it, and put it back,’ says Sue.

‘Then told her mum where to find the diamonds,’ says Ron.

Everyone is looking at Elizabeth now. Donna sees she is thinking hard. Eventually she looks up, and straight at Joyce.

‘Oh, Joyce. You really are annoyingly clever sometimes.’

Joyce beams.

‘It seems,’ says Elizabeth, ‘that Poppy might have been cleverer than she was letting on. A poet, my foot.’

‘So where does this leave us?’ asks Sue. ‘Poppy finds the letter and contacts her mother. Siobhan travels down and finds no diamonds.’

‘And the next day Poppy is shot dead,’ says Chris.

‘I’m sorry, I don’t actually know who you are?’ says Sue. Then looks at Donna. ‘Or you.’

‘DCI Chris Hudson, Kent Police,’ says Chris. ‘And this is PC Donna De Freitas.’

Sue nods, then looks at Elizabeth. ‘Do these two know how to keep their mouths shut?’

Elizabeth nods. ‘They do, to be fair.’

‘Flattered, I’m sure,’ says Chris.

‘I think I’ve got it,’ says Joyce. ‘I think I know what happened.’

‘You’re on a roll, Joyce,’ says Ibrahim.

‘It’s simple. Siobhan doesn’t find the diamonds, and tells Poppy so. Poppy is frustrated, of course, and so spills all to Douglas. “Where are the diamonds, I know you have them?” Douglas is enraged. Poppy has found his letter, she’s told her mum, who else might she tell? So he has to get rid of her. He shoots Poppy, he fakes his death, we wander in and see them both, and Douglas is in a taxi over to wherever the diamonds really are.’

‘Oh, Joyce,’ says Elizabeth.

‘What?’ asks Joyce.

‘This really is an object lesson in quitting while you’re ahead.’

‘Oh,’ says Joyce.

Elizabeth takes out her phone and opens the photos of the house in Hove. ‘I knew something didn’t look right about the crime scene.’

‘I see you found your phone, then?’ says Sue.

Elizabeth gives a happy shrug. ‘Back of the sofa. The whole thing looked too staged. Too perfect. Which is why I thought Douglas had set the whole thing up. Shot Poppy, but faked his own death, and substituted another corpse for his own.’

‘But now?’ asks Donna.

‘Well, now I wonder if it wasn’t the other way around. What if Poppy faked her own death?’

‘Not Poppy,’ says Joyce.

‘Who told us that the body in the morgue was Poppy’s?’ asks Elizabeth.

They all know the answer, but Sue is the first to say it out loud.

‘Siobhan.’

And it all falls into place. For the spies, for the police officers, for the psychiatrist and the nurse. Even for Ron. The mother and the daughter and the diamonds. What did they really know about Poppy? What did they really know about Siobhan? Nothing. They knew nothing at all.

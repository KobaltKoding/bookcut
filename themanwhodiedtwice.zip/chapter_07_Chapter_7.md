## 7

In a way, you had to admire Connie Johnson’s confidence. She did things with a bit of style. But the stakeout had been a colossal waste of time, and if they were going to catch Connie, they were going to have to think of something a great deal cleverer. Though quite what that clever thing might be is eluding DCI Chris Hudson for the moment. And, to add insult to injury, he is now on an exercise bike.

Of all the machines at the gym, the bike suits him best. For a start you’re sitting down, and you can look at your phone while you’re using it. You can take things at your own pace – sedate in Chris’s case – but you can also speed up to look more impressive any time a muscled man in a singlet or a muscled woman in Lycra walks by. A lot of Chris’s colleagues from Fairhaven Police Station use this same gym. He sees them sometimes, and his rank doesn’t seem to count for anything here. The other day a PC slapped him on the back and said, ‘Keep going, mate, you’ll get there.’ Mate? Next time Chris needs someone to sit through three days’ worth of CCTV from a twenty-four-hour garage, that young constable will see just who his mate is.

Right now Chris can see his DI, Terry Hallet, doing pull-ups with his top off. For the love of God.

But still Chris pedals in his loose-fitting T-shirt and baggy shorts. Shorts? That is what it has come to. And, of course, he pedals because of Patrice. Because for the first time in nearly two years a woman is regularly seeing him naked. Admittedly usually in as low a light as he can get away with, but still. And so far, so good, Chris is happy, Patrice _seems_ happy, although what would she say if she wasn’t? Well, Chris supposes that she wouldn’t keep sleeping with him, but, even so, there is no harm in trying to eat better, trying to lose some weight and trying to echo-locate some muscles under his spongy surface.

It was still early days for Chris and Patrice, the days of lust and art galleries. Perhaps in six months they would be in love and he could safely put the weight back on. But for now here he was.

The exercise bike is a work of art, full of dials and buttons to increase resistance, to replicate hilly ground, to measure heart rate, to measure distance travelled, time elapsed and calories burned. Chris has most of the displays switched off. The heart-rate monitor was terrifying; Chris had seen numbers that surely couldn’t be right. The calorie counter was worst of all. Six miles of cycling to burn off a hundred calories? Six miles? For half a Twix? It didn’t bear thinking about.

So instead, he’s watching an antiques programme on the TV screen and glancing up at the clock on the gym wall roughly every forty-five seconds, praying for the hour to be up.

As an elderly man on the TV hides a look of disappointment that his ship in a bottle is only worth sixty pounds, Chris’s phone rings. He generally tries not to answer his phone in the gym, but he sees that Donna is calling. Something about Connie Johnson? Fingers crossed.

Chris slows his already slow pace and picks up the call.

‘Donna, I’m on the bike. I’m like Lance Armstrong but without the –’

‘Sir, can you get to the hospital?’

Donna had called him ‘Sir’. So it was a case.

‘Of course, what’s up?’

‘A mugging. A nasty one.’

‘Gotcha. Why me though?’

‘Chris,’ says Donna. ‘It’s Ibrahim.’

Chris is running before he hangs up.

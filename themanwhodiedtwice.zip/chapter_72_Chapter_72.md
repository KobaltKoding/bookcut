## 72

Elizabeth had explained again and again to Joyce that Farnborough wasn’t an airport like Heathrow and Gatwick, and that there wouldn’t be shops. But her friend is crestfallen nonetheless.

‘But there’s not even a WHSmith’s,’ says Joyce, looking around the arrivals terminal.

‘What did you want to buy, for goodness’ sake?’ asks Elizabeth. It is eleven thirty in the morning, and Frank Andrade Jr should be walking through the arrivals doors very soon.

‘Well nothing, it’s just the principle,’ says Joyce. ‘Once you’ve used the toilet there’s nothing else to do.’

‘I’m so sorry if I’m boring you, Joyce, bringing you to meet a mafia boss so we can drive him to a diamond swap where we’re going to catch a murderer.’

‘I’m just saying,’ says Joyce, and settles into a chair.

Elizabeth hadn’t been able to persuade Ibrahim to drive them to Farnborough, so Ron’s friend Mark has driven them up in his taxi. It would have been more fun with Ibrahim but, for a friend of Ron’s, Mark was actually rather good company. She was worried about what radio station he would want to listen to, but it was Radio 2, so she had got off fairly lightly.

Joyce is sulking. Elizabeth knows what will cheer her up.

‘That really was a terrific idea. Ryan Baird as the driver. And to find him in the first place, well, that was first rate.’

‘Stop trying to cheer me up,’ says Joyce. ‘I should be looking at travel toiletries in Boots.’

‘Righto,’ says Elizabeth. Everything was in place. The pier would be closed for maintenance as soon as the meeting began. Chris and his team would be there. They had received a tip-off that Connie Johnson would be on the end of the pier at 3 p.m., with cocaine and a gun.

A group of Japanese businessmen walk past. A driver is pushing their luggage on a trolley. Elizabeth would love to open every single bit of luggage that came into this airport. Private jets flying in from all directions. She had briefly worked as a luggage handler at Heathrow, stitching tracking devices into the suitcases of trade delegations.

Sue would be there this afternoon, too. That had been a tricky conversation. Yes, Elizabeth had found the diamonds, no, she didn’t have them right now, yes, they were in the hands of a south coast drugs baron, yes, she understood this wasn’t best practice. Where had she found them? Well, that was a story for another day. On and on it had gone, threats and name-calling. ‘I thought we had an understanding?’ Why did people always get so angry? We’ll all be dead soon enough.

Sue had calmed down eventually, and she will be tucked away somewhere, watching and listening.

Lance will be there, too. He is staking out Martin Lomax’s house, so will be driving Lomax to the meeting. That had worked out very nicely.

‘Can I say something?’ asks Joyce.

‘Not if it’s about why there are no shops here, no,’ says Elizabeth.

‘I don’t want you to get annoyed with me,’ says Joyce. ‘I just … I’m just not sure that Poppy is behind all this. I know I’ve got a soft spot, I do know that. Ever since she trusted me with her mum’s phone number, I’ve felt very protective of her. More fool me, perhaps.’

‘I meant to ask. Did she make eye-contact when she put the number in your pocket?’ asks Elizabeth. ‘Flutter her eyelashes? Poor me?’

‘No, I just found it when I got back. But, also, I haven’t told you about the smiley face on the Post-it no–’

The arrivals doors swish open in front of them, and through them walks a man dressed for all the world as if he’s heading off for a game of golf. Polo shirt, beige slacks, sunglasses pushed up into his hairline. Mid-forties perhaps? All by himself, one small briefcase. He is looking around for the car-hire desk, as Elizabeth and Joyce step into stride on either side of him.

‘You must be Mr Andrade,’ says Elizabeth.

Andrade stops and looks at Elizabeth.

‘Nope,’ he says.

‘I’m Joyce,’ says Joyce. ‘And this is Elizabeth.’

‘I’m happy for you,’ says Frank Andrade. ‘Now if you’ll excuse me.’

Off he strides again, with Elizabeth keeping pace alongside and Joyce hurrying to catch up.

‘You won’t need a car, Mr Andrade,’ says Elizabeth.

‘I hate to disagree,’ says Frank Andrade.

‘Mark from Robertsbridge Taxis is driving us,’ says Joyce. ‘We worried the boot wouldn’t be big enough for your luggage, but look at you with only the one bag. It’s a Toyota Avensis.’

Andrade stops again. ‘Ladies, forgive me, I don’t know who you are. I don’t care who you are. I got somewhere to be, and someone to see.’

‘We know,’ says Elizabeth. ‘We’re here to help. You’re off to see Martin Lomax.’

Andrade gives Elizabeth a hard stare.

‘About your diamonds,’ says Joyce.

Andrade gives Joyce an even harder stare. Elizabeth sees Joyce blush. For goodness’ sake, is there no one Joyce doesn’t find attractive?

‘OK, ladies, I’ve had a long flight. I want to get in my car, I want to visit Martin Lomax, I want to get what I came for, and I want to come straight back here and fly home.’

‘Well, Martin Lomax doesn’t have your diamonds,’ says Elizabeth. ‘I do.’

‘You got my diamonds?’

‘I _have_ your diamonds, yes,’ says Elizabeth.

‘OK,’ says Frank Andrade. ‘And you think I won’t kill you because you’re an old woman?’

‘Oh, I’m sure you would, Frank,’ says Elizabeth. ‘I don’t doubt it for a moment. But, equally, I would kill you without hesitation. So shall we stop the grandstanding and get down to business?’

Frank Andrade laughs. ‘_You_ would kill _me_?’

‘She would,’ confirms Joyce. ‘I don’t think she will, but she would.’

‘OK,’ says Andrade. ‘So where are my diamonds?’

‘They’re in Fairhaven,’ says Elizabeth. ‘At the end of the pier.’

‘And where is Fairhaven?’ asks Andrade.

‘Well, you see how useful we can be to you already?’ says Elizabeth.

Elizabeth sees that Mark has driven around to the front of the terminal building. He gives her a quick honk on the horn. You shouldn’t really honk at the mafia, but she supposes Mark is not to know that.

‘You come with us, you make up with Martin Lomax, and my representative will give you the diamonds. We’ll have you back here by nine p.m. at the latest,’ says Elizabeth.

‘With my diamonds?’ asks Andrade.

‘With your diamonds,’ says Elizabeth. She points out Mark’s car. ‘So shall we?’

‘And why am I trusting you?’

‘Well, just use your judgement,’ says Elizabeth. ‘And look at Joyce’s face. Who wouldn’t trust that face?’

Joyce smiles. ‘If you want, you can sit in the front. I was in the front on the way up, but I don’t mind going in the back. I’ll probably sleep anyway.’

Mark is out of the car and has the boot open. He holds out his hand to Frank Andrade.

‘That all you’ve got then? I’m Mark, nice to meet you. Are you really from the mafia?’

Frank Andrade hands over his bag. ‘Uh, yeah.’ He looks at the car and he looks at his three companions.

‘Now,’ says Joyce. ‘It’s at least a two-hour drive, so do you need the toilet before we set off?’

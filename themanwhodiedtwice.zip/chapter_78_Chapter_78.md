## 78

‘You’ve never seen anything like it,’ says Stephen, sitting on Joyce’s sofa. ‘I was having forty winks in my chair, when I hear a noise. I open my eyes. Three fellas pointing guns at my head. “Hold your horses,” I say, “what’s this about? I’m imagining you’re looking for Elizabeth?” You know, all dressed in black, guns and what have you. “Not a bit of it,” says the fellow in the middle. “Tell us where the diamonds are.”’

He is interrupted by a low moan. Joyce is tending to Sue Reardon’s shoulder while she sits on a kitchen chair.

‘Stop moaning, you big baby,’ says Joyce, tightening a bandage.

‘So I play the innocent Frenchman as it were, “What diamonds?” all this caper, and they don’t like it one bit. Then madam here …’ Stephen nods to another kitchen chair, where Siobhan sits, hands tied behind her, ‘walks in, friendly as you like, “Just tell us, Stephen, tell us and we’ll be on our way.” Anyway, I stall for time, I couldn’t remember where you’d gone, Elizabeth, but perhaps you’d be getting back soon. So here’s me, “Oh, I don’t know about diamonds, I’m afraid, not my area, you need the boss, she’ll be back presently,” and this lady – I’m sorry, I’ve forgotten your name?’

‘Siobhan,’ says Siobhan.

‘Beautiful name. She’s saying, “Elizabeth won’t be back any time soon, and she won’t be back at all if we don’t get the diamonds.” Well, I think, then you don’t know Elizabeth like I know Elizabeth. One thing you can rely on with Elizabeth is she’ll be back. Never let me down yet.’

‘Never will, darling,’ says Elizabeth.

‘Tensions start to run high. “Where are the diamonds?” “What diamonds?” A couple of the fellows start ripping the place apart. Becoming a regular occurrence eh, dear?’

‘Not even worth tidying the drawers these days,’ agrees Elizabeth.

‘And then I hear a key in the lock and think, well, here she is, but the door opens and it’s the man himself.’ Stephen motions over to the figure in the corner of the room.

‘Ron had gone home to watch snooker and I thought Stephen would like to hear about the shootings,’ says Bogdan.

‘Before you know it, the three chaps all have their guns pointing at Bogdan, the poor bugger, and I’m thinking, get out of this one then.’

Bogdan takes up the story. ‘Stephen says these guys are looking for the diamonds, and I say, “Well, you came to the right guy, follow me, they’re at Joyce’s. If I show you, I get to keep one?” and they look at Siobhan, and she’s like, sure. “So come with me, but hide the guns when we get out the front door, I don’t want you scaring the old people.” So they’re grumble, grumble, but OK, and out we go.’

‘Immediately, I hear the most terrific noise,’ says Stephen. ‘Twenty seconds or so. Then in walks Bogdan and asks me to give him a hand clearing up.’

Elizabeth: ‘So, the ambulances?’

‘That was the three guys, yes,’ says Bogdan. ‘So I say to Siobhan, look, who’s behind all this, and she’s looking at the guys with the guns on the floor, and thinks maybe she should tell the truth. She says she works with Sue, OK, I get it. So I say send message to Sue, tell her you have the diamonds. “Where shall I say they are?” she says. And I don’t know, so I look at Stephen.’

‘And I say, “Tell her the truth,” no reason not to. “They’re in Joyce’s microwave.”’

Elizabeth looks over at Sue. ‘I hope that’s agony, dear.’

‘We had a good laugh about it, didn’t we, Elizabeth?’ Stephen continues. ‘She had to move them because she kept forgetting, and making cups of tea.’

‘Oh, I’m the figure of fun now?’ says Joyce. But she is smiling.

‘The ambulances came, they had a lot of questions, understandably.’

‘I told them to talk to Chris Hudson,’ says Bogdan. ‘He owes me a favour.’

‘Oh, does he?’ says Elizabeth.

‘And then we toddled over to Joyce’s to wait for you.’

‘I saw you through the curtains,’ says Bogdan. ‘Gave you a ring to let you know I was here. Then I shot Sue.’

‘And that’s us up to date,’ says Stephen.

Elizabeth walks over to Joyce’s microwave and pulls out a green felt bag. It was usually full of Scrabble tiles, but now is full of diamonds. She pours them onto the kitchen table in front of Sue Reardon.

‘Here you are, Sue. This is what it was all for. Poppy, Douglas, Andrew Hastings. Lomax, Frank Andrade. And this is the closest you’ll ever get.’

‘To be fair,’ calls Joyce from the sofa, ‘Martin Lomax and Frank Andrade weren’t really Sue’s fault. That was you.’

Elizabeth nods, conceding the point. She turns to Siobhan.

‘And how did you get roped in, Siobhan? What’s your connection here?’

‘I’m easily led,’ says Siobhan. ‘Always have been. And it’s not really Siobhan. It’s Sally, Sally Montague, if you remember that name?’

Douglas’s three exes. United.

Sue Reardon groans again, a guttural cry. ‘Please, I need to go to the hospital.’

‘I think Bogdan might have used up all the ambulances,’ says Elizabeth.

‘We’ll give it a couple of hours,’ says Joyce. ‘I’ll make sure you don’t die. It’ll be much more fun to see you in prison. Would you like some painkillers?’

‘Yes, please,’ says Sue, the anguish etched onto her face.

‘Shame,’ says Joyce. ‘I don’t have any.’

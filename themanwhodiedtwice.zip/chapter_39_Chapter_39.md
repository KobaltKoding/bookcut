## 39

## Joyce

It is tomorrow morning, if you know what I mean, and I have just got back from the shop. More of that in a moment. My bag and umbrella are ready, waiting, on the hallway table. More of that in a moment too.

Elizabeth thinks that Douglas faked his own death. It is, apparently, not uncommon in her line of work. Killed someone, had the body identified as his own and ran off with twenty million. Who’s to say, but certainly nice work if you can get it.

We were all round at Ibrahim’s last night, as Elizabeth wanted to run the theory past Sue Reardon. Ibrahim is moving better, by the way, but he looks sad, which is not like him at all. I mean, he has always looked melancholy, unless he’s writing a list, or explaining something, but you very rarely see him looking sad. I need to get him out of his flat somehow. Get him back behind the wheel of his car. Or Ron’s car, but you know what I mean.

We had a very nice evening. It was nothing special, but it doesn’t always have to be, does it? Having someone from MI5 there might have felt unusual a year ago, but I am growing to expect such things. Sue Reardon looked a bit sad too, I thought. I imagine she is in trouble at work after everything that happened.

I am learning that it is important to stop sometimes, and just have a drink and a gossip with friends, even as corpses start to pile up around you. Which they have been doing a lot recently.

It’s a balancing act, of course, but, by and large, the corpses will still be there in the morning, and you mustn’t let it spoil your Domino’s.

We didn’t really talk too much about the case until Elizabeth started going on about Douglas and the weather. That was Sue Reardon’s cue, and then Elizabeth let everything spill. Douglas faking his own death, the full works. It does sound a bit complicated to me. How would he have done it?

Though I suppose if you don’t put a bit of effort into stealing twenty million pounds then when will you put in some effort?

You could see that Sue didn’t dismiss it out of hand. She knows Elizabeth has her head screwed on, and, also, she probably wanted to believe it too. If you are investigating something, you want all sorts of things to be true if they help you out.

I was proud of Elizabeth for sharing, and after Sue left, I was going to tell Elizabeth that she was showing real maturity, not keeping everything to herself for once, but then she told us she had something to show us, and suggested a walk in the woods. Oh, Elizabeth!

Bear in mind, also, that this was gone ten and I had already said, ‘Well, this has been lovely,’ more than once.

We packed up our things, Ron went to his for a torch and Ibrahim wouldn’t come, but wished us luck. I gave him a kiss on the cheek and told him he looked well. He will know I meant the opposite, we are good friends like that.

As we were walking up the hill Elizabeth got into the details of how she’d worked it out.

She had been walking this way with Douglas when he was at Coopers Chase, Poppy trailing behind them with her headphones on. Poor Poppy, I don’t think I mind any of this, except for her. Andrew Hastings being murdered was fine by me. Easy come, easy go, that was his job. If you work in a fishmonger’s you’re going to smell of fish. And Douglas? Well, if he’s dead then he probably had it coming too. But Poppy should have been in a different story, and I’m sorry she ended up in this one.

Elizabeth and Douglas had stopped by a tree, and we stopped by the same tree last night. You could see a big hole in it when Ron shone his torch. He was in his element. Gerry was the same if you ever gave him a torch.

Have you ever heard of a ‘dead-letter drop’? It’s a thing for spies. A place, somewhere public and accessible, where you could hide something, and no one would ever stumble across it accidentally. Spy A would drop off something for Spy B, maybe a microfilm or something like that? Spy B would wander along the canal towpath, that’s just an example, lift up a loose fencepost, that’s just an example, too, and there you’d have it.

When Elizabeth and Douglas were standing by the tree, he had said to Elizabeth that it would make a good ‘dead-letter drop’, and it reminded him of one they had used before, and Elizabeth had agreed, and had thought nothing more of it.

Well, that’s not strictly true, Elizabeth never stops thinking, does she? She had now convinced herself that Douglas had drawn her attention to the tree for a reason. That he had hidden something in there for her.

And, as so often, she was right.

She asked Ron to shine his torch down into the hole, and guess what we found?

Now, I know what you’re thinking. You’re thinking we found the diamonds? No such luck, I’m afraid. I promise if we’d found the diamonds I would have started this account very differently. I would have started it ‘We just found twenty million pounds’ worth of diamonds’ or something like that. I wouldn’t have gone on about Ron’s torch or Ibrahim looking sad. I would have been straight in. In like Flynn. It would have been all diamonds.

But we found the next best thing.

Elizabeth pulled out a letter, on crisp white paper inside a clear ziplock bag. To keep it dry, of course. Honestly, there is nothing those ziplock bags can’t do, I’ve got a drawer full of them. The letter was folded over and her name was handwritten on the front. According to Elizabeth, it was written in Douglas’s handwriting. We used to know each other’s handwriting, didn’t we?

She took the letter out of the bag and unfolded it. It was expensive paper, you know the type, nothing you’d get from your bank or the council, say. Does expensive paper come from more expensive trees, or do they just make it differently?

Elizabeth read the letter, first to herself and then to us. And when you hear what is in it, you’ll know what we’re going to be doing today. You will know exactly why my flask and my umbrella are on the hallway table.

The reason I’ve just been to the shop, by the way, is that they have a photocopier there, so that’s what I’ve just been up to. One copy each of the letter for the four of us, and two more in case we decided Chris and Donna might be interested further down the line.

It is 30p a copy! That seems hard to justify. And I had to do extra copies as well, because the first two times I had the letter in the wrong way up. What a racket. You have to wonder where all that money is going. I told Ron on my way back and he was up in arms about it.

I dropped off the original with Elizabeth and she looked rather tired, which is not like her. Though we had been up very late, I suppose. Anyway, she was finally wearing the friendship bracelet I made her, so that was nice.

I have my copy of the letter in front of me now. This is what it says.

> _Dear Elizabeth,_
> 
> _Never doubted you for a moment, you clever thing. I knew you’d find the letter._
> 
> _Cards on the table, I should probably apologize for stealing the diamonds, and starting this whole parade. Everyone has their price, and it turns out that mine is twenty million pounds. Twenty million, darling, just sitting there, and me a dinosaur nearing retirement? Resistance was futile. You understand, don’t you?_
> 
> _Dinosaur that I am, I still have a few tricks left in me. Elderly as I am, I still have a few years left in me too. A few years I intend not to waste. Retirement is not for me._
> 
> _Of course I shouldn’t have stolen them, that’s a given. You wouldn’t have, for example. But I hope you don’t begrudge me the adventure of the thing. Not with all the adventures you’ve been having? It has had my blood pumping for the past weeks at least, and that’s a lovely feeling to get back._
> 
> _Enough of my bunk, let us get down to business._
> 
> _If you are reading this then I suppose one of two things has happened. I have been killed perhaps? Someone tortured the location of the diamonds out of me then disposed of me? Not impossible. I wouldn’t put up with too much torture, adventure or not. Besides, I can simply send them on a wild goose chase. By the time they realize they’ve been duped I will have been buried in woodland somewhere._
> 
> _If I have been killed then I do hope there is a part of you that will miss me, and that you will forgive my many sins. I forgave yours long ago. I don’t know who would be in charge of a funeral, there is not really anyone around who I have a particular connection to. A couple of bits on the side, but aren’t there always with yours truly? I haven’t picked up too many friends over the years, and those I had I’ve shed. If they ask you, and who knows, they might, my mother and father are buried in Northumbria. Please ensure I am buried as far away from them as possible. Rye, perhaps? Remember that weekend we spent? The cottage?_
> 
> _There is a second option, of course, which would be much more fun. And that is that I have got away with it._
> 
> _Martin Lomax wants me dead, the New York mafia wants me dead, and the Service wants to wash its hands of me. Just at this moment I can’t quite work out how I can get away with it, but I have always been resourceful, and perhaps something will come to me? I have a couple of little thoughts ticking over in my brain._
> 
> _So I am either dead or rich, and I have an easy way for you to find out which._
> 
> _The diamonds are in a left-luggage locker. You know I requested to be housed at Coopers Chase, and so I left them nearby to make them nice and easy for me to get back. Or for you to get back, if it came to that, which it may well have done._
> 
> _Darling, the diamonds are in locker 531 at Fairhaven train station. You could break into it, I’m sure, but I have left the key inside this bag._
> 
> _You go and try your luck. If you open the locker and the diamonds are there, then you will know I am dead. If you open the locker and the diamonds are gone, then you’ll know I found a way out. I will be straight over to our old friend, Franco, in Antwerp, cashing the lot in._
> 
> _On that note, if you don’t find the diamonds, it will not escape your notice that I will be roaming free, a very rich man. And if that should interest you at all then rest assured at some point I will find a way to get back in touch. You know I will find someone to share my life with, but it would make me the happiest man alive if that person was you._
> 
> _You can’t blame an old fool for trying._
> 
> _God bless you, Elizabeth, and no doubt Joyce, Ron and Ibrahim too. I am guessing you will keep this between the four of you. No need to tell Sue and Lance and the gang?_
> 
> _I wonder how long it took you to find this letter. Not long is my guess. If I am dead, then thank you for your speed and wisdom, and if I am alive then at least I have something of a head start on everyone._
> 
> _Well done on finding this dead-letter drop, I knew you wouldn’t have missed the clue, you always were, and always will be, the very best._
> 
> _Locker 531, Fairhaven station. If the diamonds are not there then I am free. If the diamonds are there then I am dead._
> 
> _So, is this another letter from a dead man? Who knows? But I imagine your blood is pumping too?_
> 
> _My love, always,_
> 
> _Douglas_

Lovely handwriting, I will give him that. Elizabeth and I are going to get the minibus down to Fairhaven in a few minutes. I don’t know Fairhaven station at all, but it’s fairly big because you can go to Brighton and to London. According to the website there is a Costa, a WHSmith and a place that does sausage rolls and pasties. There’s a First Class lounge, which looks very swish in the pictures, and a big Travel Centre. And then, of course, there are the left-luggage lockers.

So maybe we’re about to find twenty million pounds’ worth of diamonds. Elizabeth won’t let me keep them, I know, but it will be nice to have them for a bit. Will we take them to Sue and Lance? Or will we take them to Chris and Donna? I’d love to show them to Donna, that would be my choice, but there are probably protocols to follow.

Or maybe we’ll find nothing? Maybe Douglas has outfoxed us all and is out there, on the run? An old man, giddy with freedom, awash with cash, wishing Elizabeth was still in love with him.

Only one way to find out, and that’s to get on the minibus.

## 74

It is a nice enough office for one man, overseeing the day-to-day running of a slot-machine arcade on an award-winning pier.

It is a little cramped just at the moment, however. Connie Johnson sits behind a desk, with Martin Lomax opposite. Frank Andrade Jr is perched on a windowsill. Lance James leans against a wall and Bogdan stands in front of the door.

The introductions had been swift. Mainly ‘Who are you?’ and ‘None of your business.’ Frank Andrade Jr had greeted Martin Lomax with a handshake though. ‘Looks like I won’t have to kill you today, Martin!’ ‘Looks like it, Frank. How is your wife, did she get the muffins I sent?’

No one is quite sure how to begin. Because, of course, no one in this room has actually arranged this meeting. It has been arranged by a seventy-six-year-old woman currently sitting in a white van, four hundred metres away, listening to every word they are about to say.

And so it falls to the alpha character in the room to kick things off.

‘OK then,’ says Bogdan, ‘we start.’

_OK then_, says Bogdan, _we start._

Inside the white van Sue Reardon is wearing headphones and watching the monitors relaying pictures from the cameras her team had installed in the office over the weekend.

Elizabeth and Joyce are having to share headphones, one ear each. Cutbacks.

‘You’re sure she’s still got the diamonds?’ asks Sue.

‘I left Bogdan in charge of that,’ says Elizabeth. ‘So, yes, I’m sure.’

‘And what the hell’s in that bag she was carrying?’ asks Sue.

Elizabeth shrugs. The drugs are for Chris and Donna’s benefit, Sue doesn’t need to know about them. She looks back at the crowded office on her screen. The pictures are so much clearer than in her day.

Frank Andrade, sitting on his windowsill, addresses Connie Johnson.

_So you got my diamonds?_

_I’ve got diamonds_, says Connie. _I’ll take your word they’re yours._

_How’d you get ’em?_ asks Andrade.

_Fell out of my Coco Pops_, says Connie. _Are you really from the mafia?_

_He’s a businessman_, says Martin Lomax. _Very well respected._

_Yeah, I’m from the mafia_, says Andrade. _Now, show me the diamonds._

Well, here we go then, thinks Elizabeth. They are _not_ going to like what happens next. Good luck one and all.

Connie reaches into her holdall. When are they going to talk about the drugs? She wants her fifty grand, and she wants to do more business with these people. She had been worried, she has to admit, about this whole thing. Cautious. But it was all going the way she’d been told. The way Vic Vincent had explained. There was a guy from the mafia, there was some old posh guy, there always is, and there was Bogdan. All very reassuring, and she is keen to make a good impression. There’s another guy, bored and balding, but he’s probably just a bodyguard. Bogdan knew him, and that was enough for her.

She puts the blue velvet bag down on the desk in front of her.

‘Well, hallelujah,’ says the old posh guy.

‘Show me,’ says Andrade. ‘Pour the diamonds out on the table. Don’t spill any.’

Don’t spill any? That’s a weird thing to say, thinks Connie, but this guy’s American, and they say weird things.

She loosens the drawstring, and carefully tips the diamonds onto the table.

‘There you go,’ says Connie. ‘Didn’t spill a thing. Both the diamonds, safe and sound.’

There is silence. Andrade, the old posh guy, even the bodyguard are staring at the diamonds on the table. Connie senses there is suddenly an atmosphere.

‘You got two diamonds?’ says Andrade.

‘Yeah,’ says Connie. ‘These are the diamonds. What were you expecting?’

_What were you expecting?_ says Connie Johnson.

‘Where are the rest of the diamonds?’ says Sue Reardon, looking frantically at Elizabeth.

‘Oh, I only gave her the two,’ says Elizabeth. ‘Just enough to flush out the killer and liven things up a bit. Any news on whether your gang have spotted Poppy lurking about yet?’

‘Jesus Christ!’ says Sue. ‘Can’t you play anything straight?’

‘Only when it suits my purposes,’ says Elizabeth. ‘And it didn’t suit my purposes today.’

‘So where are the diamonds?’ asks Sue.

‘They’re safe,’ says Elizabeth. They are now in Joyce’s microwave, because she uses it far less than her kettle.

On screen they see Frank Andrade pull a gun.

‘Christ almighty!’ says Sue. ‘What the hell have you done, Elizabeth?’

Lance sees Frank Andrade pull his gun, and so pulls his own. Andrade’s is pointed at Connie Johnson and Lance’s is pointed at Andrade.

‘Where are my diamonds?’ asks Frank Andrade. ‘All of them.’ He sounds calm, but, in Lance’s estimation, he does not look it. Lance doesn’t blame him. What scam is being pulled here?

‘These are your diamonds,’ says Connie Johnson. ‘Put your gun down, you drama queen.’

‘Where are _the rest_?’ says Andrade. He doesn’t sound calm any more.

‘The rest?’ says Connie. ‘This is all I was given.’

‘Given?’ says Andrade. ‘Given by who?’

‘Some old guy, Vic Vincent,’ says Connie. ‘Don’t you dare shoot me for this. This guy gave me the diamonds, told me this posh guy wanted five kilos of coke and said meet you on the pier. This is between you and him.’

‘What coke?’ says Frank Andrade. ‘And who’s Vic Vincent?’

‘This coke,’ says Connie, reaching into her bag. But instead of pulling out cocaine, she pulls out her gun. She points it at Andrade.

‘This is a lot of guns in a small room,’ says Bogdan, and sighs.

‘That is such an English gun,’ says Andrade. ‘What did he look like? Vic Vincent?’

‘Old, like a boxer or something,’ says Connie. ‘Lots of tattoos, West Ham tattoos, all sorts.’

Martin Lomax slams his fist on the desk.

‘I know him,’ says Lomax.

‘I’ll bet you do,’ says Andrade, and points his gun at Lomax. ‘What have you set up here?’

Well, isn’t that just the question, thinks Lance. Connie Johnson’s gun is aimed at Andrade. Andrade’s is aimed at Lomax. Lance supposes he should aim at Connie Johnson, just for a sense of equilibrium. How does this play out now? It’s going to end badly for someone. He just needs to ensure it’s not him. What a place this would be to die. The seagulls calling overhead and the empty slot machines beeping down below. At least if he’s shot he won’t have to deal with the kitchen wall at his flat. All the same, try not to get shot, Lance.

‘I’m as baffled as you, Frank,’ says Lomax. ‘As I live and breathe. But there will be a perfectly simple –’

‘Enough,’ says Frank Andrade. He pulls the trigger and shoots Martin Lomax in the chest. Lomax doubles forward in his chair, blood spreading through his suit. Andrade aims the gun at Connie Johnson now, even though he was raised to shoot all the men first. He is too late, however. Connie Johnson squeezes off a single shot, which passes through Frank Andrade, through the window and out towards the grey sea.

Martin Lomax looks up, as if to comment on the noise. But whatever comment he has will have to go unsaid. He topples over to his left and hits the floor.

Frank Andrade slides off the windowsill, leaving a smear of thick, scarlet blood trailing down a plastic radiator. His feet end up in the crook of Martin Lomax’s arm. Two men sleeping. Dreaming of guns and drugs and money, of always taking and never giving.

What now? thinks Lance. There are two corpses on the floor, there are two diamonds on the table, and a bag full of cocaine under the desk. He and Connie have their guns pointed at one another, neither quite sure what to do.

Bogdan steps between the two guns.

‘Connie, you have no business with this guy and he has no business with you. He’s just here for dead guys and diamonds. Get your bag and run.’

Outside on the pier are members of the Special Boat Service, their eyes peeled for Poppy. They know not to touch Connie Johnson. Their orders are clear. She will reach her car.

Connie grabs the bag, slides over the desk and makes for the door. Bogdan opens the door for her. She reaches up to his face and kisses him.

‘Call me, yeah?’ she says, and then disappears at speed, holdall full of cocaine swinging as she goes.

Lance surveys the scene. The big Polish man next to him is blushing. The blood of the two corpses on the floor is starting to intermingle.

Sue had raced from the van as soon as the two shots had gone off. Elizabeth hadn’t felt the need to follow, and so Joyce has stayed where she is too.

‘Well, I never,’ says Joyce.

‘I don’t really like anyone being killed if one can avoid it,’ says Elizabeth. ‘But no great loss here.’

Joyce thinks about this. As soon as Elizabeth had decided to give Connie Johnson just the two diamonds, something like this had been inevitable. Elizabeth could be brutal sometimes. She was a very bad enemy to make.

The world was better off without Frank Andrade Jr, that was for certain. Mark from Robertsbridge Taxis had wanted to talk to him about baseball, but had been told to ‘shut the hell up’. Except Andrade hadn’t said ‘hell’. Mafia or no mafia, what a dreary, inadequate man Frank Andrade Jr is.

Was.

And Martin Lomax? With his house and his millions, and his work. The things he had helped to fund. The weapons, the gangs, the warlords. The smell of honeysuckle covering the stench. She thinks about his cheque for Living With Dementia. Five pounds. She looks at the screen, sees his body and feels nothing.

Joyce has seen so many good people, innocent people, unlucky people, die over the years. Sometimes she would go home and cry, and Gerry would hold her, knowing there was nothing he could say.

But she would shed no tears for these two. ‘Good riddance,’ Gerry would say, and Joyce quite agrees. Still, to _make_ it happen, as Elizabeth has just done? Was that worse? Or just more honest? A question for someone cleverer there. She would ask Ibrahim.

She watches the monitors and sees Lance approach each camera in turn and switch it off. The last thing she sees each time is her friendship bracelet. The final screen goes black.

‘What now?’ she says to Elizabeth. ‘I don’t suppose they found Poppy?’

‘Oh, Poppy’s dead, Joyce,’ says Elizabeth. ‘I worked it all out in the car on the way down here. It all clicked while the Jeremy Vine show was on.’

‘Oh,’ says Joyce. ‘So what now?’

‘Well,’ says Elizabeth, looking at her watch. ‘I’d give it half an hour or so, but then, I hope, a trip back to Godalming in a coroner’s van with the person who killed Douglas and Poppy.’

Connie is running at full pelt along the pier. She has shot a mafia boss, she has kissed Bogdan and she still has her cocaine, so it is hard to judge how that went. She needs to get back to the office. Regroup. It honestly feels like she might come out of it all pretty cleanly. She trusts Bogdan, and the other guy seemed to have no interest in her.

The Range Rover is up ahead. The driver, Ryan Baird, was deeply unimpressive. She remembered he had done a few jobs for her before, and not particularly well. He stunk of weed and didn’t know how the heated seating worked. And he tried to talk to her, which was unforgivable. When she sees Vic Vincent again she will have to tell him the truth about his nephew, family or no family.

Connie risks a look behind her, but no one is giving chase. No one is even looking in her direction, which is strange. A blonde woman in a business suit running down a pier with a sports bag? Surely someone would turn their head? But the pier was quiet, just a few couples in dark clothing walking arm in arm.

She reaches the door of the Range Rover, throws it open and dives in. Straight into the lap of DCI Chris Hudson. She is cuffed before she can speak.

‘Hi Connie,’ says Chris. ‘You’re under arrest. You do not have to say anything, etc.’

In the front, Connie sees Ryan Baird, handcuffed in the passenger seat. Behind the wheel is Donna De Freitas. She turns to Connie.

‘I’ve never driven a Range Rover before, Connie, so forgive me if I’m a bit stop-start. I’ve put Fairhaven Police Station in the satnav though, so we won’t go far wrong. What’s that scent you’re wearing? It’s gorgeous.’

‘So we just need another word for a horse,’ says Ibrahim, crossword propped up on his laptop.

‘Horsey?’ says Kendrick, bouncing his way in and out of the FaceTime screen.

‘Too many letters,’ says Ibrahim.

‘I think it’s the only word though,’ says Kendrick. ‘So maybe they got it wrong?’

Ibrahim nods. ‘Perhaps, yes.’

He should have gone today. Should have driven Joyce and Elizabeth to the airport. Should have driven them down to the pier. Should be there now. Ron has texted. Two more people dead, but the right people, so everyone seems happy.

Mark from the taxi company is driving Ron home, and he’s bringing fish and chips with him. Elizabeth and Joyce still have a long night ahead of them.

‘Do you still hurt?’ asks Kendrick.

‘I do,’ says Ibrahim. ‘But not when I’m talking to your grandad, and not when I’m talking to you.’

Through the windscreen of the Range Rover, Donna sees Elizabeth and Joyce climbing out the back of the white van. Elizabeth sees Donna behind the wheel and gives her a hopeful look. Donna responds with a thumbs-up, and Elizabeth nods and mouths ‘well done’.

Ron now appears at her open driver’s window.

‘Oh, they’re all here today,’ says Donna. ‘Pensioners’ outing?’

‘That’s Vic Vincent,’ says Connie, lunging forward as far as her cuffed hands will allow. ‘These are his drugs. Arrest him.’

Ron looks at Connie. ‘Never heard of him, love. Sounds like a right wrong ’un.’ He then looks at Chris. ‘What she do, then?’

‘Murder,’ says Chris. ‘All on camera. Plus a big bag of coke.’

‘That’s her dealt with then, eh?’ says Ron. He then looks over at Ryan Baird.

‘You all right there, Ryan?’

Ryan Baird is quietly crying.

‘You have a good cry,’ says Ron. ‘And I’ll tell you a story. Couple of weeks ago, you nicked a bloke’s phone. My sort of age, the bloke, but looks older, losing a bit of hair. You gave him a nasty little kick to the back of the head, do you remember? No reason I can make out. I’ve seen him cry too, you know, since you done that, and I don’t like it, Ryan. I know you don’t care, old son, but he’s my best mate, this fella. I want you to remember his name for me. Will you do that? Ibrahim Arif. You remember that name every night you’re locked up. No one messes with Ibrahim Arif.’

Connie leans forward again, getting as close to Ron as she possibly can. She hisses, ‘When I get out, you’re a dead man.’

Ron looks back at her. ‘Well I’m seventy-five, and you’ll be doing thirty years so, yeah, agreed.’

Donna sees Bogdan approach. Oh boy. He walks up behind Ron and pulls him away from the window.

‘Time to go,’ says Bogdan, and Ron nods, giving the weeping Ryan Baird one final look.

‘Ibrahim Arif,’ says Ron. ‘Don’t you forget now, Ryan.’

Bogdan looks at Donna. ‘You are Donna?’

‘Yes,’ confirms Donna.

‘I am Bogdan,’ says Bogdan.

‘I know,’ says Donna.

Bogdan nods. ‘OK.’ He then looks into the back seat, and says, ‘Hello, Connie.’

‘You’re all dead,’ says Connie. ‘Every single one of you.’

‘Sooner or later, for sure,’ agrees Bogdan, and Donna watches him walk away, his arm around Ron.

## 47

‘Uncle Ibrahim, what’s better, a monkey or a penguin?’

‘A penguin,’ says Ibrahim, and pats the seat next to the bed. Kendrick sits down.

‘Oh, OK, Grandad didn’t know. Why is a penguin better than a monkey?’

Ibrahim puts his paper down. ‘Kendrick, do you know why I like you?’

Kendrick shakes his head. ‘I don’t even know at all.’

‘You ask very good questions. Not many people do.’

‘Why don’t they?’ asks Kendrick.

‘Well, there you go again,’ says Ibrahim. ‘Now, penguins are better than monkeys, because “penguin” is a very specific term, and “monkey” is very unspecific. If we say “monkey” then different people see different things, maybe a mandrill, maybe a little marmoset, whereas if you say “penguin” then we all picture the same thing. Words are very important, most people don’t know that, and the more specific a word is, the better it is.’

‘But is an actual penguin better than an actual monkey?’

Ibrahim thinks. ‘No animal is better than any other animal. We are all just a collection of atoms smashed together. Even people. Even trees.’

‘Even tigers?’

‘Even tigers.’

Kendrick blows out his cheeks.

‘Even hippos?’

Ibrahim nods. He goes back to his crossword.

‘What are you doing?’ asks Kendrick, hopping. ‘Is it a puzzle?’

‘A crossword puzzle,’ says Ibrahim.

‘Is it boring or interesting?’

‘A bit of both,’ says Ibrahim. ‘That’s why I like it.’

Ron stands and stretches. ‘I’m just going to nip down to the shop. Ibrahim, would you like an ice cream?’

‘No, thank you, Ron,’ says Ibrahim.

‘No one wants an ice cream, righty-ho,’ says Ron and turns to go.

Kendrick clamps his lips together and lets out a small noise. Ron turns back.

‘You all right there, Kendrick?’

Kendrick keeps his lips together, and murmurs an uncertain ‘mmm hmm’.

‘Nothing you want? Some eggs? Washing-up brush? Toilet cleaner? Sardines?’

Kendrick shakes his head.

‘You sure? I’m going to the shop anyway. Bottle of whisky? A cabbage? I can get you a cabbage, if you want?’

Kendrick looks down. ‘No, thank you, Grandad.’

Ron smiles and picks his grandson up. ‘Maybe an ice cream though?’

Kendrick looks at him. ‘Really?’

‘You’re on holiday, Kenny. It ain’t a holiday without an ice cream.’

‘Were you just teasing?’

‘I was just teasing.’

‘Could I get a Twister? I had one when I stayed at Grandad Keith’s.’

Grandad Keith. That old fraud. You don’t buy a house that big from selling used cars. And a Millwall fan too. Also, when had Kendrick stayed at Grandad Keith’s? Suzi had kept that quiet. Something wasn’t right with Suzi and Danny.

‘I’ll tell you what, you can have two,’ says Ron, and puts Kendrick down as he wriggles with delight.

‘I have _never_ had two Twisters before.’

Out of the window Ron sees Joyce walking with Siobhan. Poor Poppy’s mum, she turned up last night. Ron knows he should be feeling nothing but sympathy for Siobhan, but really he’s thinking what a good-looking woman she is. Give it a week though, he thinks. He really wouldn’t mind chancing his arm. After the funeral, maybe?

He leaves Kendrick with Ibrahim, both happy. As he slips on his coat he can still hear Ibrahim.

‘What’s another word for “parallelogram”? Seven letters?’

‘I don’t think there is another word,’ says Kendrick.

‘Maybe you’re right,’ says Ibrahim.

Ron opens the front door and smiles. How did he end up with a grandson and a best mate like these two? Lucky fella.

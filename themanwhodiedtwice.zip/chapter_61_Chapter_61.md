## 61

There were two lakes at Coopers Chase. One was man made, dug by Tony Curran’s construction team during the first phase of building work at the development. Ron loved this lake. It was manicured to within an inch of its life, and it had a beautiful paved path all the way around. The fish loved it, the swans loved it and Ron loved it. It was even sparkling blue, because of a chemical they mixed into it once a week. Exactly what a lake should look like.

You had to hand it to Tony Curran, God rest his soul. He was a terrible human being, and there were probably bales of cocaine buried somewhere under the water, but he knew how to dig a lake.

The other lake had been there for centuries; it was surrounded by reeds and wildflowers, and skimmed with lily pads and algae. At best it was a greeny-brown. The insects adored it and Ron didn’t see the point of it at all.

Colin Clemence from Ruskin Court used to swim across it every morning. Absolutely swore by it, until he caught Weil’s disease and they’d had to put up signs.

He can see one of the signs now. They really could be having this meeting indoors, but Ron had wanted Ibrahim to take a walk and to get some air. If he wasn’t going to leave Coopers Chase, at least he could leave his flat. So Ron had suggested they meet by the lake. He had meant the other lake, of course, but Ibrahim looked happy, and so he couldn’t really complain.

They took up two benches. Both looking out over the disappointingly untamed lake.

‘So beautiful,’ says Sue Reardon. She had been at lunch with Elizabeth. They’d kept that quiet.

‘Isn’t it?’ says Joyce. ‘So wild.’

Even Joyce likes this stupid real lake?

Ibrahim hands around a printout of the CCTV image. Siobhan, helmet off, hair down, sequined bracelet glinting off a strip light.

‘Siobhan!’ says Joyce.

‘Siobhan,’ says Elizabeth.

‘Well, now,’ says Sue Reardon.

Bloody typical, thinks Ron. The second I start fancying someone.

‘I know that now isn’t the time or place,’ says Joyce, ‘but how lovely she’s wearing the bracelet.’

They continue to stare in disbelief, trying to work out what has happened.

‘This is the woman who turned up at yours, Joyce,’ says Chris Hudson. Chris and Donna are on the third bench.

‘Poppy’s mum, yes,’ says Joyce. She squashes a tick on her neck. How do you like the lake now, Joycey?

‘And this footage is from the day before Poppy and Douglas were killed,’ says Donna.

‘The evening before,’ says Elizabeth. ‘Before the shootings, and before any of us knew where the diamonds were supposed to be hidden.’

‘So how did Siobhan know about the locker before we did?’ asks Joyce. ‘That doesn’t make any sense?’

Sue Reardon picks up the picture of Siobhan. ‘Elizabeth, I suspect you might be thinking what I’m thinking? That only one person could have told her?’

Elizabeth nods. ‘It could only have been Poppy.’

Sue nods. ‘Would Douglas really have told her though? I doubt that.’

‘I doubt that too,’ says Elizabeth.

‘Maybe they were in it together?’ says Ron. ‘They were both at the Lomax robbery, right?’

Donna nods. ‘Douglas knows he’s going to be locked up a while longer, so he tells Poppy about the locker. Poppy gets her mum to go and collect the diamonds for them.’

‘Can you spot the slight flaw in that, Donna?’ says Elizabeth.

‘Douglas hadn’t put the diamonds there in the first place,’ says Ibrahim. ‘If they were in it together, then why send Siobhan on a wild goose chase?’

‘But if Douglas didn’t tell Poppy about the locker, then how on earth did she find out?’ asks Sue. ‘The only place it was referred to was in the letter?’

There is silence all around and everybody tries to think of any possible solution. Donna notices that the only person not deep in thought is Joyce. Joyce is simply looking at Elizabeth, with a kind smile on her face. As if waiting for something. But Ron is the first into action.

‘OK,’ says Ron. ‘I got it. I read the mafia have got listening devices, and they can point them at lightbulbs, and there’s some science or other, don’t ask me, it’s on Google, and the glass vibrates, and they can hear what’s being said in any room. They had it on talkSPORT the other day. So the mafia show up here, in a hired car probably, and –’

‘Oh, for goodness’ sake,’ says Joyce.

Ron stops, and all eyes are on Joyce.

‘Two spies, and you can’t work it out? Two police officers and a psychiatrist? And none of you can work it out?’

‘What about me?’ says Ron.

‘Well, at least you tried,’ says Joyce.

‘And I suppose you have worked it out?’ says Elizabeth.

‘Elizabeth,’ says Joyce, shaking her head kindly. ‘For the cleverest person I know, you can be very dim sometimes.’

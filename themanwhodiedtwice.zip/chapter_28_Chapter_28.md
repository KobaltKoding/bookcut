## 28

Say what you like about Ron, but you can’t say he doesn’t look like a plumber. Ryan Baird had let him in without a second glance. Housing Association sent me round, water pressure. Hold up the bag, here’s my tools. It’s all free, don’t worry.

So this was Ryan Baird?

This was the kid who kicked Ron’s best friend in the back of the head and left him for dead?

What was he? Seventeen? Eighteen? Skinny, hair dyed blond, electric-blue tracksuit bottoms and bare top. He’d had a games controller in his hand, and had gone straight back to playing a game after Ron had asked him where the bathroom was. A few years ago Ron would have decked him there and then. But sometimes Elizabeth’s way was the best way, so he’ll do what he’s told. And perhaps he’ll still get his chance to smack Ryan Baird right in that gaping mouth before this is all over. Ron hopes so. He has a lot of respect for Gandhi and his ilk, but sometimes you have to cross the line.

Ron lifts the lid from the cistern and takes the brown package from his sports holdall. He wedges it down as far as it will go. Ten grand really doesn’t buy you that much coke, he thinks. He’ll talk to his son, Jason, about it when he next sees him.

Ron checks that the lid will fit back on the cistern, then removes it again. He puts his hand into the pocket of his overalls. He doesn’t know where Elizabeth got hold of the overalls, but boy were they comfortable. He wonders if he’s allowed to keep them. Wearing overalls every day would be a slippery slope though. There’s a thin line between wearing overalls and going to the shop in your pyjamas.

He pulls out Ibrahim’s debit card and places it carefully inside the cistern.

Lid back on, Ron zips his bag back up. He realizes he actually needs to use the loo, but decides to wait. Who knows what happens when you flush a loo with a kilo of cocaine in the cistern?

Ron goes back into the hallway, calls out, ‘All done, mate!’ to no response from Ryan Baird and leaves the flat.

He gives it a minute or so, as you never know who’s listening, before pulling out his phone. It is a burner phone, untraceable. Jason had lots of them and hadn’t batted an eyelid when his dad had asked for one. He rings the number of PC Donna De Freitas. She answers on the third ring.

‘Hello?’

‘Hello, is that Donna De Freitas?’

‘Hi, Ron, is that you?’

‘No, no, I don’t know a Ron. I just got some information.’

‘Well, OK, I’ll play along. But quick, I’m watching CCTV of someone driving a Renault into a Greggs.’

‘It’s just I’m a plumber …’

‘Right.’

‘And I’ve just been doing a job, flat eighteen, Hazeldene Gardens.’

‘Eighteen Hazeldene Gardens?’

‘Yep, only I found something when I was there. It’s in the toilet cistern, first door off the hallway when you break your way in.’

‘I see … sir. And is the resident of the flat at home right now?’

‘He is. He’s not even wearing a top, Donna. Jesus. I was going to deck him.’

‘Well, Fairhaven Police would like to thank you for your help, sir. But we can’t break into a private residence without due cause.’

‘What sort of thing?’

‘Like, someone being attacked.’

‘Oh yeah, and someone was being attacked. Screams, the lot.’

‘OK. We’ll be right over.’

‘Good, take Chris with you, too.’

‘Could I take your name, then?’

‘I prefer to remain anonymous.’

‘Make one up, just for me.’

Ron thinks. ‘Jonathan Ovaltine.’

‘Thank you, Mr Ovaltine.’

‘Thanks, darling, you go get him. See you soon.’

Ron ends the call and walks out of the estate, whistling as he goes.

Job done. Elizabeth will be pleased. Perhaps he’ll give her a ring, too. A pint first, though.

## 58

Elizabeth has read the letter again and again. What was Douglas trying to tell her? And if the clue wasn’t in the letter, then where was it? The locket? She’d checked again, and nothing.

‘And you checked the cottage in Rye?’ says Sue Reardon, the letter in front of her.

‘First thing I did,’ says Elizabeth. ‘And I wonder if you noticed the first two paragraphs?’

‘Nice try, dear,’ says Sue. ‘Very Douglas.’

It had taken Elizabeth a lot longer to spot that. Sue Reardon was quick. Which was why they were there, of course.

They are having an early lunch in Le Pont Noir. Elizabeth had come to a dead end, and thought it might be time to share the letter with Sue. Their minds were alike. Sue had grumbled a bit about Elizabeth keeping the letter to herself, but hadn’t taken it as badly as she might have. The lack of a big fuss had saved them both a bit of time. Sue filled her in a little. A mafia boss is about to fly over, either to claim his diamonds or to kill Lomax. All the fun of the fair. Elizabeth is glad to be back in this world. A last hurrah.

‘Any old haunts he might have hinted at?’ says Sue. ‘It’s clear he wants you to find the diamonds. The love of his life, and so on. So something only you and he would know?’

‘Nothing springs out. But I hadn’t seen the man in twenty years,’ says Elizabeth.

‘You lucky thing,’ says Sue.

‘Sounds like you’ve had a few run-ins with him?’

‘He’s of a certain generation, isn’t he?’ says Sue. ‘I’m glad you trusted me with this letter, Elizabeth. It would have been deeply unprofessional if you hadn’t, but I appreciate it all the same.’

‘Sometimes we have to stick together, don’t we?’ says Elizabeth. ‘I am learning to be more trustworthy as the years go by.’

‘Well, I hope that epiphany comes to me one day,’ says Sue. ‘But I trust you, for what that’s worth. I wouldn’t put it past us to find the diamonds together.’

‘We are peas in a pod,’ says Elizabeth.

Sue raises her glass. ‘Let’s drink to that.’

![Penguin walking logo](./images/00005.jpeg)


## 1

_The following Thursday …_

‘I was talking to a woman in Ruskin Court and she said she’s on a diet,’ says Joyce, finishing her glass of wine. ‘She’s eighty-two!’

‘Zimmer frames make you look fat,’ says Ron. ‘It’s the thin legs.’

‘Why diet at eighty-two?’ says Joyce. ‘What’s a sausage roll going to do to you? Kill you? Well, join the queue.’

The Thursday Murder Club has concluded its latest meeting. This week they have been looking at the cold case of a Hastings newsagent who murdered an intruder with a crossbow. He’d been arrested, but then the media had got involved, and the consensus was that a man should be allowed to protect his own shop with a crossbow, for goodness’ sake. He walked free, head held high.

A month or so later police had discovered that the intruder was dating the newsagent’s teenage daughter, and the newsagent had a long record of GBH, but at that point everybody had moved on. It was 1975, after all. No CCTV, and no one wanting to make a fuss.

‘Do you think a dog might be good company?’ asks Joyce. ‘I thought I might either get a dog or join Instagram.’

‘I would advise against it,’ says Ibrahim.

‘Oh, you’d advise against everything,’ says Ron.

‘Broadly, yes,’ agrees Ibrahim.

‘Not a big dog, of course,’ says Joyce. ‘I haven’t got the hoover for a big dog.’

Joyce, Ron, Ibrahim and Elizabeth are enjoying lunch at the restaurant that sits at the heart of the Coopers Chase community. There is a bottle of red and a bottle of white on their table. It is around a quarter to twelve.

‘Don’t get a small dog though, Joyce,’ says Ron. ‘Small dogs are like small men: always got a point to prove. Yapping it up, barking at cars.’

Joyce nods. ‘Perhaps a medium dog, then? Elizabeth?’

‘Mmm, good idea,’ replies Elizabeth, though she is not really listening. How could she be, after the letter she has just received?

She’s picking up the main points, of course. Elizabeth always stays alert, because you never know what might fall into your lap. She has heard all sorts over the years. A snippet of conversation in a Berlin bar, a loose-lipped Russian sailor on shore leave in Tripoli. In this instance, on a Thursday lunchtime in a sleepy Kent retirement village, it seems that Joyce wants a dog, there is a discussion about sizes and Ibrahim has doubts. But her mind is elsewhere.

The letter was slipped under Elizabeth’s door, by unseen hand.

> _Dear Elizabeth,_
> 
> _I wonder if you remember me? Perhaps you don’t, but without blowing my own trumpet, I imagine you might._
> 
> _Life has worked its magic once more, and I discover, upon moving in this week, that we are now neighbours. What company I keep! You must be thinking they let in any old riff-raff these days._
> 
> _I know it has been some while since you last saw me, but I think it would be wonderful to renew our acquaintance after all these years._
> 
> _Would you like to join me at 14 Ruskin Court for a drink? A little housewarming? If so, how would 3 p.m. tomorrow suit? No need to reply, I shall await with a bottle of wine regardless._
> 
> _It really would be lovely to see you. So much to catch up on. An awful lot of water under the bridge and so on._
> 
> _I do hope you remember me, and I do hope to see you tomorrow._
> 
> _Your old friend,_
> 
> _Marcus Carmichael_

Elizabeth has been mulling it over ever since.

The last time she had seen Marcus Carmichael would have been late November 1981, a very dark, very cold night by Lambeth Bridge, the Thames at low tide, her breath clouding in the freezing air. There had been a team of them, each one a specialist, and Elizabeth was in charge. They arrived in a white Transit van, shabby on the outside, seemingly owned by ‘G. Procter – Windows, Gutters, All Jobs Considered’, but, on the inside, gleaming, full of buttons and screens. A young constable had cordoned off an area of the foreshore and the pavement on the Albert Embankment had been closed.

Elizabeth and her team clambered down a flight of stone steps, lethal with slick moss. The low tide had left behind a corpse, propped, almost sitting, against the nearest stone pillar under the bridge. Everything had been done properly, Elizabeth had made sure of that. One of her team had examined the clothing and rifled through the pockets of his heavy overcoat, a young woman from Highgate had taken photographs and the doctor had recorded the death. It was clear the man had jumped into the Thames further upstream, or been pushed. That was for the coroner to decide. It would all be typed into a report by somebody or other and Elizabeth would simply add her initials at the bottom. Neat and tidy.

The journey back up those slick steps with the corpse on a military stretcher had taken some time. The young constable, thrilled to have been called to help, had fallen and broken an ankle, which was all they needed. They explained they wouldn’t be able to call an ambulance for the time being, and he took it in fairly good part. He received an unwarranted promotion several months later, so no lasting harm was done.

Her little unit eventually reached the Embankment, and the body was loaded into the white Transit van. ‘All jobs considered’.

The team dispersed, save for Elizabeth and the doctor, who stayed in the van with the corpse as it was driven to a morgue in Hampshire. She hadn’t worked with this particular doctor before – broad, red-faced, a dark moustache turning grey – but he was interesting enough. A man you would remember. They’d discussed euthanasia and cricket until the doctor had dozed off.

Ibrahim is making a point with his wine glass. ‘I’m afraid I would advise against a dog altogether, Joyce, small, medium, or large. At your time in life.’

‘Oh, here he comes,’ says Ron.

‘A medium dog,’ says Ibrahim, ‘say a terrier, or a Jack Russell perhaps, would have a life expectancy of around fourteen years.’

‘Says who?’ asks Ron.

‘Says the Kennel Club, in case you want to take it up with them, Ron. Would you like to take it up with them?’

‘No, you’re all right.’

‘Now, Joyce,’ Ibrahim continues, ‘you are seventy-seven years old?’

Joyce nods, ‘Seventy-eight next year.’

‘Well, that goes without saying, yes,’ agrees Ibrahim. ‘So, at seventy-seven years old, we have to take a look at your life expectancy.’

‘Ooh, yes!’ says Joyce. ‘I love this sort of thing. I had my Tarot done on the pier once. She said I was going to come into money.’

‘Specifically, we have to look at the chances of your life expectancy exceeding the life expectancy of a medium dog.’

‘It’s a mystery to me why you never got married, old son,’ says Ron to Ibrahim, and takes the bottle of white wine from the cooler on the table. ‘With that silver tongue of yours. Top-up, anyone?’

‘Thank you, Ron,’ says Joyce. ‘Fill it to the brim to save having to do it again.’

Ibrahim continues. ‘A woman of seventy-seven has a fifty-one per cent chance of living for another fifteen years.’

‘This is jolly,’ says Joyce. ‘I didn’t come into money, by the way.’

‘So if you were to get a dog now, Joyce, would you outlive it? That’s the question.’

‘I’d outlive a dog through pure spite,’ says Ron. ‘We’d just sit in opposite corners of the room, staring each other out, and see who went first. Not me. It’s like when we were negotiating with British Leyland in ’seventy-eight. The moment one of their lot went to the loo first, I knew we had ’em.’ Ron knocks back more wine. ‘Never go to the loo first. Tie a knot in it if you have to.’

‘The truth is, Joyce,’ says Ibrahim. ‘Maybe you would, and maybe you wouldn’t. Fifty-one per cent. It’s the toss of a coin, and I don’t believe that is a risk worth taking. You must never die before your dog.’

‘And is that an old Egyptian saying, or an old psychiatrist’s saying?’ asks Joyce. ‘Or something you just made up?’

Ibrahim tips his glass towards Joyce again, an indication of more wisdom to come. ‘You must die before your children, of course, because you have taught them to live without you. But not your dog. You teach your dog only to live _with_ you.’

‘Well, that is certainly food for thought, Ibrahim; thank you,’ says Joyce. ‘A bit soulless perhaps. Don’t you think, Elizabeth?’

Elizabeth hears, but her mind is still in the back of the speeding Transit van, with the corpse and the doctor with the moustache. Not the only such occasion in Elizabeth’s career, but unusual enough to be memorable – anyone who knew Marcus Carmichael would have known that.

‘Beat Ibrahim’s system,’ Elizabeth says. ‘Get a dog that’s old already.’

And here was Carmichael again, years later. Looking for what? A friendly chat? Cosy reminiscence by an open fire? Who knew?

Their bill is brought to the table by a new member of the serving staff. Her name is Poppy and she has a tattoo of a daisy on her forearm. Poppy has been at the restaurant for nearly two weeks now and, thus far, the reviews have not been good.

‘You’ve brought us table twelve, Poppy,’ says Ron.

Poppy nods. ‘Oh, yes, that’s … silly me … what table is this?’

‘Fifteen,’ says Ron. ‘You can tell because of the big number fifteen written on the candle.’

‘Sorry,’ says Poppy. ‘It’s just remembering the food, and carrying it, and then the numbers. I’ll get the hang of it eventually.’ She walks back to the kitchens.

‘She is very well meaning,’ says Ibrahim. ‘But ill suited to this role.’

‘She has lovely nails, though,’ says Joyce. ‘Immaculate. Immaculate, aren’t they, Elizabeth?’

Elizabeth nods. ‘Immaculate.’ Not the only thing she has noticed about Poppy, who seems to have sprung from nowhere, with her nails and her incompetence. But she has other things on her mind for now, and the mystery of Poppy can wait for another day.

She is going through the text of the letter again in her head. _I wonder if you remember me? An awful lot of water under the bridge_ …

Did Elizabeth remember Marcus Carmichael? What a ridiculous question. She had found Marcus Carmichael’s dead body slumped against a Thames bridge at low tide. She had helped to carry that body up those slick stone steps in the dead of night. She had sat feet away from his corpse in a white Transit van advertising window-cleaning services. She had broken the news of his death to his young wife and she had stood beside the grave at his funeral, as an appropriate mark of respect.

So, yes, Elizabeth remembers Marcus Carmichael very well indeed. Time to be back in the room though. One thing at a time.

Elizabeth reaches for the white wine. ‘Ibrahim, not everything is about numbers. Ron, you would die long before the dog, male life expectancy is far lower than female life expectancy, and you know what your GP has said about your blood sugar. And Joyce, we both know you’ve already made up your mind. You’ll get a rescue dog. It’ll be sitting somewhere right now, all alone with big eyes, just waiting for you. You will be powerless, and, besides, it’ll be fun for all of us, so let’s stop even discussing it.’

Job done.

‘And how about Instagram?’ says Joyce.

‘I don’t even know what that is, so feel free,’ says Elizabeth, and finishes her wine.

An invitation from a dead man? On reflection, she will be accepting.

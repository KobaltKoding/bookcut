## 45

‘He called it ham-fisted,’ says Stephen. ‘Ham-fisted!’

‘I know, dear,’ says Elizabeth. It is 2.30 a.m.

Many years ago, a man named Julian Lambert had written a review of one of Stephen’s books, _Iran – Art After the Revolution_. It had not been a good review. Mean-spirited. They were rivals.

‘I’ll knock his block off. How dare he?’ Stephen slaps both palms against the hallway wall, with some force. Stephen is a big man still. Elizabeth has never had to fear his physicality. Might she have to one day? Every day he slips further away.

‘Don’t give him the satisfaction, darling,’ says Elizabeth. Julian Lambert died in 2003, a hosepipe fitted to his car exhaust, in the garage of a house he was renting after an expensive and self-inflicted divorce.

‘I’ll give him more than satisfaction,’ says Stephen. ‘Let’s see how clever he looks on his arse, shall we? Where are my keys?’

Keys to what, wonders Elizabeth. Car keys, long gone. Keys to the flat, hidden many months ago. Stephen no longer has any keys. How to calm him down though?

‘I’ve just had a rather wonderful idea,’ says Elizabeth. ‘I wonder if you’d like to hear it before you head off?’

‘Don’t talk me out of this, Elizabeth. Lambert has had this coming a long time.’ Stephen is checking through drawers. ‘Damn and blast, where are my keys?’

Stephen has never been a vengeful man or an angry man. Never been ruled by his pride. Never had those traits you see in weak men. Never felt the need to prove himself at the expense of others.

‘I wouldn’t talk you out of anything,’ says Elizabeth. ‘I agree with you entirely. Anyone who insults your book insults you. And anyone who insults you, insults me.’

‘Thank you, darling,’ says Stephen.

‘It’s just I was thinking you might take Bogdan with you? He could drive you up.’

Stephen considers this for a moment, then nods. ‘He’d scare the living daylights out of Lambert, wouldn’t he?’

Elizabeth takes out her phone. ‘I’ll ring him, dear.’

It is nearly 2.30 in the morning, but Bogdan answers on the first ring.

‘Hello, Elizabeth.’

‘Hello, Bogdan, Stephen wanted to ask you a favour.’

‘OK, hand me over,’ says Bogdan. Elizabeth would love to know why Bogdan is wide awake at 2.30 in the morning. He is infuriatingly opaque. She hadn’t even heard any background noises, despite her well-trained ear.

‘Bogdan? Is this you?’ says Stephen.

‘Yes, Stephen. What can I do?’ says Bogdan.

‘There’s a fella. He’s in Kensington, or Camden, and we need to duff him up.’

‘OK, now?’

‘Soon as you can get here.’

‘OK, I be maybe an hour. Get some rest before, OK? Put me back to Elizabeth.’

Stephen hands the phone back to Elizabeth.

‘Thank you, Bogdan,’ says Elizabeth. ‘You are a good friend.’

‘You are, too,’ says Bogdan. ‘I hope you get him back to sleep.’

‘Thank you, darling. What are you up to?’

‘Bits and bobs,’ says Bogdan.

‘What’s that I can hear in the background?’ she asks.

‘I don’t think you can hear anything,’ says Bogdan.

Elizabeth rolls her eyes. ‘Night, night, Bogdan.’

Elizabeth leads Stephen back to bed, and he is already much calmer. Bogdan does that to people. She can’t persuade Stephen to undress, but she persuades him to get under the covers beside her.

‘You found out who shot your friends yet?’ he asks.

Elizabeth seizes on the change of subject. ‘Not yet, but I will.’ She knows she already has the clue. But what is it? Where is it?

‘Of course you will,’ says Stephen. ‘You always get your man.’

Elizabeth smiles, and kisses her husband on the cheek. ‘I certainly got you, didn’t I?’

‘No, no, I got you, darling,’ says Stephen. ‘Had it planned from the moment I saw you.’

They had met when Stephen had handed her a dropped glove, outside a bookshop, in an act of tactical chivalry. Elizabeth has never told him that, actually, she had spotted him from a distance earlier that day, sitting on a bench, looking like quite the most beautiful man she had ever seen. As she walked past the bench she had dropped the glove on purpose. He had picked it up, as she knew he would. The dropped glove, a romantic cliché no man could resist. So, yes, Elizabeth always got her man, even when they didn’t know it. You should always have a plan.

‘He left me a note,’ says Elizabeth. ‘Telling me where to find the diamonds. Joyce and I followed the trail, and it just led to another note, telling me I knew where the diamonds were if only I were to think about it.’

‘Telling you to pull your finger out?’

‘That’s the long and short of it.’

‘How did you find the first note?’

‘We were by a tree, up in the woods, and he talked about dead-letter drops.’

‘Bit obvious for you,’ says Stephen.

Elizabeth laughs. ‘In retrospect.’

‘He say anything else? Anything in the note?’

‘Shall I get it?’ says Elizabeth. ‘We can look through it together?’

‘Yes, let’s, what fun. Shall I put the kettle on?’

‘No, you stay where you are, darling. Perhaps slip your shoes and jacket off though, make yourself comfortable.’

‘Right you are,’ says Stephen.

Elizabeth swings her legs out of bed and walks over to her desk. Stephen’s shoes fly across the room as she retrieves the photocopy of the letter and gets back into bed. She smiles at her husband, still wearing his tie.

They read through the letter together, Stephen making the occasional comment of ‘Northumbria’, ‘remember that weekend in Rye’, ‘mafia, of all things’ and ‘my love always? Well, you lost out there, Chief.’

Perhaps the clue is hidden in plain sight, Elizabeth thinks. There was a very simple technique she and Douglas would use for fun. Spelling out a message with the first letter of successive sentences. They would write huge sweeping love letters to each other, where the initial letters would spell out ‘DON’T FORGET WE NEED EGGS AND TOILET ROLL’.

Would Douglas try so simple a trick here? For old times’ sake? Surely not?

‘I’d say they are at the cottage in Rye, darling,’ says Stephen. ‘Wouldn’t you? Funny to mention it otherwise?’

They are not at the cottage in Rye. It was the first thing Elizabeth checked. It was bulldozed in 1995 to make way for a bypass. Elizabeth picks up the letter again, and looks to see if Douglas has left her a message in the first letter of each sentence. She scans the opening paragraphs.

> _Never doubted you for a moment, you clever thing. I knew you’d find the letter._
> 
> _Cards on the table, I should probably apologize for stealing the diamonds, and starting this whole parade. Everyone has their price, and it turns out that mine is twenty million pounds. Twenty million, darling, just sitting there, and me a dinosaur nearing retirement? Resistance was futile. You understand, don’t you?_
> 
> _Dinosaur that I am, I still have a few tricks left in me. Elderly as I am, I still have a few years left in me too. A few years I intend not to waste. Retirement is not for me._

Elizabeth smiles. You win that one, Douglas. Sometimes, if she thought really hard, she could remember why she’d married him.

‘Darling,’ says Stephen. ‘Do you remember Julian Lambert, he just popped into my head.’

‘Never heard of him,’ says Elizabeth.

‘I might put in a lunch with him. He’s just had the most awful divorce. Be nice to check he’s all right.’

Oh, stay with me, Stephen, thinks Elizabeth. Stay with me, stay with me, stay with me.

## 50

Chris Hudson pads over to the handset on the wall and picks it up.

‘Hello?’ Perhaps it’s Donna on her way home from a disastrous date with an ice-cream salesman?

‘Hi, Chris, it’s me,’ says a disembodied female voice. Not Donna.

‘OK,’ says Chris. ‘Any other clues?’

The voice on the phone laughs. ‘I told you I knew where you lived, silly!’

Chris freezes. Connie Johnson.

‘Are you going to let me up? I have something to discuss with you. Won’t take long.’

Chris curses beneath his breath and buzzes her in. What is this going to be? He quickly types out a text message to Donna.

_Connie Johnson at flat. If I don’t ring in 15 mins, send squad car._

Chris looks around to see if the flat is in any way presentable. And, of course, it is, because he’d made it presentable for Patrice, and hasn’t had enough time to ruin it yet. There is a knock at the door. Chris takes a deep breath and opens it.

‘Hello, Chris,’ says Connie Johnson.

Chris refuses to respond, but ushers her in.

‘Well, this is nice, isn’t it?’ says Connie, surveying the flat. ‘Small, but nice.’

‘Well, it’s all I can afford without selling cocaine to children,’ says Chris.

‘All right, Mother Teresa,’ says Connie, and sits on Chris’s sofa. Chris takes a dining chair, places it opposite her, and sits.

‘You know you’re on thin ice?’ says Chris. ‘Coming round to a police officer’s home?’

‘Mmm,’ says Connie. ‘You’re probably on thin ice inviting me up. Do you have anything to drink?’

‘No,’ says Chris. Which is, actually, pretty much the truth.

‘Be like that then,’ says Connie. ‘I’ll just get straight to it. What do you know?’

‘About you?’

‘Yep,’ says Connie.

‘I know you killed the Antonios. I know you’ve got a Range Rover. I know you’re clever, but not quite clever enough to get away with what you’re doing, so I’ll just keep plodding on.’

‘Mmm,’ says Connie again. ‘Well, firstly, no comment, and secondly, I think you’re pretty smart too. That’s what people say.’

‘I’m not smart,’ says Chris. ‘I’m smarter than you, but I’m not smart.’

Connie nods. ‘Maybe. It was certainly easy to find out where you lived.’

Chris shrugs. ‘It’s quite easy to follow someone home, Connie.’

‘It is,’ agrees Connie. ‘It was easy to follow you here, and it was easy to follow Donna De Freitas to 19 Barnaby Street too. She’s on a date tonight, by the way. Pont Noir.’

Chris laughs. ‘This isn’t the school playground. We’re Fairhaven police officers, we live in Fairhaven. It’s pretty easy to track us down. But if you’re trying to scare me, try harder, you wouldn’t touch a police officer, and you know it.’

‘I do,’ says Connie.

‘So what do you want?’

‘Well, nothing really, I just wanted to say that, as a businesswoman, there’s a limit to how much I’m going to tolerate you poking into my affairs.’

‘Is there?’

‘There is. Taking photographs of my customers and so on. I’m approaching my limit now, so, just between friends, I’m telling you to tread very carefully.’

Chris nods. ‘Sure, because you know my address, and you know Donna’s address? Terrifying.’

‘It’s just a friendly warning,’ says Connie, pushing herself up off the sofa. ‘If you’re not worried, you can just ignore it.’

‘I will, thanks,’ says Chris, showing her to the door.

‘Sorry I called so late,’ says Connie. ‘I keep funny hours. She’s gorgeous, by the way.’

Chris had been about to shut the door behind her, but has stopped in his tracks.

Connie laughs. ‘You’ve done very well for yourself, if you don’t mind me saying. I bet you’re missing her already? You here, and her up in south London?’

‘Don’t even think about this, Connie,’ says Chris.

‘Think about what?’ asks Connie. ‘Just saying Streatham’s a long way away, eh?’

‘Connie, I’m not kidding, you’re not smart enough to pull this off. Let it go.’

‘I might not be smart enough,’ smiles Connie, ‘but I’m quite dangerous. Or unpredictable, that’s the nicest way of putting it. I followed you home, but someone else followed Patrice home for me.’

‘Get out,’ says Chris.

‘I’m already out, silly,’ says Connie. ‘I promise we’ll keep an eye on her for you. Make sure she’s not up to mischief. She’s really very pretty. Bet she keeps you on your toes. Like all the best women.’

As Connie blows him a kiss, Chris slams the door and slumps back against it. Think quickly, assess the risk. Tell Patrice that Connie has just threatened her? Ask her to be careful? Look out for Range Rovers? Terrify her? For what? For some amateurish bluff? Jesus! Was it a bluff? Just how unpredictable was Connie Johnson? Could he –

Chris’s phone rings. Donna. His fifteen minutes are up. He knows he has to pick up.

‘All clear,’ he says.

‘What did she want?’ asks Donna.

Tell Donna the truth? Chris makes an instant decision. He hopes it’s the right one.

‘She just wanted to threaten me. And you. Just letting me know she had our addresses. Telling us to ease off.’

Donna laughs. ‘She thinks we’ll be scared of her?’

‘I laughed her off too. Told her to do her worst.’

‘And that’s all?’ asks Donna. ‘Just some amateur intimidation?’

‘Yep, sorry if I worried you.’

‘Don’t be silly. You OK? You want me to pop over? We could watch another episode of _Ozark_?’

Chris opens a kitchen drawer and looks at the takeaway menus, neatly tidied away by Patrice.

‘No, I should get some sleep. You had a good evening?’

‘Surveillance with that guy from the Met. Jayden? Jordan?’

‘Jonathan,’ says Chris. ‘I’ll see you in the morning.’

‘Night, skipper,’ says Donna.

Chris looks at the menus again. He would kill for a curry. He slams the drawer shut.

If you don’t love yourself, who’s going to love you?

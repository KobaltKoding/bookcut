## 4

It is another glorious autumn day, but there is a bite in the air that tells you there won’t be too many left. Winter is waiting impatiently round the corner.

It is 3 p.m., and Elizabeth is carrying flowers for Marcus Carmichael. The dead man. That drowned body, suddenly alive as you like and living at 14 Ruskin Court. The man she saw lowered into a grave in a Hampshire churchyard, now unpacking boxes and struggling with his new Wi-Fi.

She walks past Willows, the nursing home at the heart of Coopers Chase. The place Elizabeth would visit every day while Penny was there, just to sit and chat to her old friend, to plot and to gossip, not knowing whether Penny could hear her or not.

No more Penny now, of course.

The nights are beginning to draw in a little, and the sun is sinking behind the trees on top of the hill as Elizabeth reaches Ruskin Court and rings the bell for number 14\. Here goes nothing. There is a brief wait and she is buzzed up.

There are lifts in all the buildings, but Elizabeth will use the stairs while she still can. Stairs are good for hip and knee flexibility. Also, it is very easy to kill someone in a lift when the doors open. Nowhere to run, nowhere to hide, and a _ping_ to announce you’re about to appear. Not that she’s worried about being killed, it doesn’t feel to her like that’s what is happening here, but it’s always important to remember best practice. Elizabeth has never killed anyone in a lift. She once saw someone pushed down an empty lift shaft in Essen, but that was different.

She turns left at the top of the stairs, transfers the flowers to her left hand and knocks on the door of number 14\. Who will answer the door? What is the story here? Should she be worried?

The door opens, and she sees a very familiar face.

It’s not Marcus Carmichael, how could it have been? But it is certainly someone who knew the name Marcus Carmichael. And who knew it would get her attention.

And it turns out that, yes, she should be worried.

The man is handsome and tanned, strands of sandy grey hair still gamely holding on. She might have known he would never go bald.

How to play this one?

‘Marcus Carmichael, I assume?’ says Elizabeth.

‘Well, I assume so, too,’ says the man. ‘Good to see you, Elizabeth. Are those flowers for me?’

‘No, I have taken to carrying flowers around with me as an affectation,’ says Elizabeth, handing them over as she is ushered in.

‘Quite right, quite right, I’ll put them in water, nonetheless. Come in, sit down, make yourself at home.’ He disappears into the kitchen.

Elizabeth takes in the flat: bare, not a picture, not an ornament, not a single frill to be seen. No sign of anyone ‘moving in’. Two armchairs, both ready for the skip, a pile of books on the floor, a reading lamp.

‘I like what you’ve done with the place,’ says Elizabeth in the direction of the kitchen.

‘Not my choice, dear,’ says the man, re-entering the room with the flowers in a kettle. ‘I daresay I’ll grow into it, though I hope I shan’t be here for long. Can I get you a glass of wine?’ He sets the kettle on a windowsill.

‘Yes, please,’ says Elizabeth, settling into an armchair. What was happening? Why was he here? And what did he want from her after all this time? Whatever it was looked like trouble to her. A room barely furnished, blinds drawn, a padlocked bedroom. Number 14 Ruskin Court had the look of a safe house.

But safe from what?

The man walks back in, with two glasses of red wine. ‘A Malbec for you, if I’m not mistaken?’

Elizabeth takes her glass as the man sits in the armchair opposite her. ‘You seem to think that’s a stunning feat of memory, to remember the wine I drank for the twenty-odd years we knew each other?’

‘I’m nearly seventy, darling, everything is a stunning feat of memory these days. Cheers!’ He raises his glass.

‘And to you,’ says Elizabeth, raising hers. ‘Long time.’

‘Very long time. But you remembered Marcus Carmichael?’

‘That was very neat.’

Marcus Carmichael had been a ghost, invented by Elizabeth. She was an expert in it. A man who never existed, concocted entirely to pass secrets to the Russians. A man with a past created from false documents and staged photographs. An agent who never existed, passing secrets that never existed, to the enemy. And when the Russians got a bit closer, and wanted a bit more from their new source, it was time to kill Marcus Carmichael off, to ‘borrow’ an unclaimed cadaver from one of the London teaching hospitals and bury it in a Hampshire churchyard, with a young typist from the pool bawling her eyes out as the grieving widow. And bury the lie with him. So Marcus Carmichael was a dead man who had never lived.

‘Thank you, I thought it might amuse you. You look very well. Very well. How is … remind me … is it Stephen? The current husband?’

‘Shall we not do this?’ sighs Elizabeth. ‘Shall we cut to you telling me why you’re here?’

The man nods. ‘Certainly, Liz. Plenty of time to catch up when everything is out in the open. I believe it is Stephen, though?’

Elizabeth thinks about Stephen, back at home. She left him with the television on, so hopefully he is dozing. She wants to be back with him, to sit with him, to have his arms around her. She does not want to be here, in this empty flat with this dangerous man. A man she has seen kill before. This is not the adventure she was hoping for today. Give her Stephen and his kisses. Give her Joyce and her dogs.

Elizabeth takes another sip of wine. ‘I’m assuming you want something from me? As ever.’

The man sits back in his armchair. ‘Well, yes, I suppose I do. But nothing too taxing – in fact, something you might think is rather fun. You remember fun, Elizabeth?’

‘I’m already having my fair share of fun around here, but thank you.’

‘Well, yes, so I hear. Dead bodies and so on. Read the whole file.’

‘File?’ asks Elizabeth. A sinking feeling.

‘Oh yes, you’ve caused quite a stir in London, asking for all kinds of favours over the last couple of months. Financial records, forensics reports, I believe you even had a retired pathologist down here, digging up bones? You thought that might go unnoticed?’

Elizabeth realizes she has been short-sighted. She had certainly called in favours while she and the Thursday Murder Club were investigating the deaths of Tony Curran and Ian Ventham. And when they were identifying the other corpse they’d found, buried in the graveyard up on the hill. She should have known that somebody, somewhere was taking notes. You can’t expect favours without being asked to repay them. So what was it to be?

‘What do you need from me?’ she asks.

‘Just some babysitting.’

‘Babysitting who?’

‘Babysitting me.’

‘And why would someone need to babysit you?’

The man nods, takes a sip of his wine and leans forward. ‘The thing is, Elizabeth, I’m afraid I’ve got myself in a spot of bother.’

‘Some things never change, do they? Why don’t you tell me about it?’

There is the sound of a key in the lock and the door swings open.

‘Bang on time for once,’ says the man. ‘Here’s just the woman to help me tell the story. Meet my handler.’

Into the room walks Poppy, the new waitress from the restaurant. She nods to them both. ‘Sir, ma’am.’

‘Well, that explains an awful lot,’ says Elizabeth. ‘Poppy, I hope you’re a better operative than you are a waitress.’

Poppy blushes. ‘To be honest, I’m not sure I am, I’m afraid. But between the three of us I expect we can muddle through it all and stay safe.’

Safe houses, in Elizabeth’s experience, rarely stayed safe for long. Poppy moves the flowers in the kettle to one side. ‘Lovely flowers.’ She perches on the windowsill.

‘Safe from what, exactly?’ asks Elizabeth.

‘Well, let me start at the beginning,’ says the man.

‘I wish you would, Douglas,’ says Elizabeth, and downs her glass of wine. ‘You were an awful husband, but you always knew how to tell a good story.’

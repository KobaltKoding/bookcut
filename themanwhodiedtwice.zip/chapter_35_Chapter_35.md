## 35

Martin Lomax takes the tray of coffee and biscuits down to his home cinema. Twenty leather seats all angled towards the screen, which takes up an entire wall. The most people he has ever had in here was four, when the Azerbaijani cup final coincided with a particularly profitable heroin deal. Martin Lomax had brought them down nibbles and everybody seemed to have a good time. Lomax didn’t really understand much about having a good time, but he was good at blending in and not spoiling things for other people. When there was money to be made, at least.

He points the remote control at the screen and brings up his library of movies. Martin Lomax can’t see the point in films at all. It’s just some people acting, how could everyone not see that? Someone writes some words, some idiots from America say them and it seems to send everybody cuckoo. Lomax had gone to the theatre once, and that seemed marginally better. At least the actors were there. At least you could talk to them when you disagreed. He had been asked to leave, but he certainly wouldn’t rule out going again one day.

He scrolls past countless films he will never watch, although he knows lots of the titles by now. He finally reaches another film he will never watch. It is called _The Treasure of the Sierra Madre_ and you can tell by the picture that it is black and white. Black and white? People really were fools. He selects the film and then navigates down through the menu until he finds ‘Subtitles’. A list of languages appears, and Martin Lomax scrolls down until he finds ‘Cantonese’. He selects it. He immediately hears those three familiar electronic beeps, and the cinema screen disappears up into the ceiling. Painted on the wall behind is a rainbow. Martin Lomax places his fingertips at either end of the rainbow. There are three more electronic beeps and a door slides open. Martin Lomax picks up his tray and walks into the vault.

Martin Lomax often likes to have his coffee and biscuits in the vault. It is lovely and cool so as not to damage any of the banknotes, or the priceless paintings that are rolled up against the far wall. He has just received his first Banksy, and he is unimpressed. It is a rat looking at a mobile phone. Why would a rat be looking at a mobile phone? Modern art is beyond Lomax, but he bets that Banksy would be delighted to know his work was now valuable enough to be used as a down payment on an international arms deal. The man who had dropped it off, a Chechen, had said that Banksy’s real name was a secret, but he told him what it was, regardless. Lomax has already forgotten it. Art was a racket; give him gold any day of the week. You didn’t have to understand gold.

The vault is also very quiet, thanks to the six-foot-thick walls surrounding him. You could easily kill someone in here and, in fact, that did happen once. It caused quite a kerfuffle at the time.

Lomax dunks a chocolate-chip cookie in his coffee. The Open Garden week starts today. What will people think of the grounds? Too ornate, too cultivated? Not cultivated enough? Would it rain? Google says there is a zero per cent chance, but how could it possibly know? Would people come? Would they buy his brownies? Would anybody try and get into the house? They would soon discover it was impossible, but what if they got close enough to see all the lasers and the tiny cameras in the hanging baskets? He will leave a comments book outside the pagoda, and he can spend Monday looking through it. Will people write their names? Perhaps he will leave a space for people’s addresses too. If anyone leaves an unpleasant comment he can send someone to pay them a visit.

Lomax sips at his coffee, noticing a couple of cookie crumbs floating on the surface. The coffee is Colombian, as was the man who was shot in the vault with a bolt gun that time. The man’s boss – who had done the shooting, and presumably had his own reasons – had asked Lomax if he might bury the body in the gardens, but Lomax had quite enough buried there already, and so had politely said no. The boss had been understanding, and Lomax had helped drag the body out to his helicopter by way of an apology.

If Lomax sells all of his brownies then he thinks he will be able to raise seventy pounds. He wonders what he will spend it on.

On the whole, Martin Lomax enjoys his job. It is lucrative, and while money isn’t everything – far from it – Martin Lomax has been poor and he’s been rich, and he prefers rich. There is variety, no two days are the same, and that is psychologically healthy. One day will run smoothly, you’ll return some gold bullion to a Bulgarian and everyone is smiles and handshakes, then the next day there’s a car bomb in Kabul and person Y is cutting off person X’s fingers, and everyone wants their money or their paintings or their racehorse, and Martin Lomax is rushed off his feet. It certainly keeps his mind active. Best of all, though, he gets to work from home. Everyone knows that. Martin Lomax won’t come to Monte Carlo or Beirut or Qatar or Buenos Aires. Martin Lomax won’t even travel to the Winchester M&S if he can avoid it. No, you come to Martin Lomax, whether you’re a warlord, whether you’re a trafficker, or whether you’re Ocado.

But sometimes – not often, touch wood – the job is stressful, and this is one of those times. He flips open his laptop and rings the number he has been sent on his encrypted phone. Frank Andrade Jr, the second-in-command of one of New York’s leading crime families. Lomax knows that if the conversation goes badly, the next person he will be speaking to is Frank’s father. Who, from memory, is also called Frank. And if that happens, then Martin Lomax really would have to travel. Probably against his will, in the hold of a private jet.

The Americans want to know what has happened to their twenty million pounds’ worth of diamonds. Of course they do, that’s natural. Martin Lomax doesn’t suppose the value matters all that much to them – they can afford to misplace the odd twenty million every now and again – it is more the issue of trust. Martin Lomax has provided an invaluable service for a long time now, and he has provided it with skill and discretion. He has been a well-oiled cog in the wheels of these huge organizations, beyond reproach and above suspicion. But now?

Andrade’s face fills the screen, suddenly, and he immediately begins to remonstrate with Lomax, his arms windmilling. He brings a fist down on his New York desk.

‘Frank, you’re on mute, I think,’ says Martin Lomax. ‘You need to click on the little microphone. The green button.’

Frank Andrade leans into his screen, mouth open and eyes scanning for the button. He presses it.

‘Can you hear me?’

‘That’s perfect, Frank,’ says Martin Lomax. ‘What were you saying? When you were banging your fist on the desk?’

‘Ah, nothing,’ says Frank. It always disappoints Martin Lomax that Frank doesn’t have a thick New York accent like in the films. He just sounds like a normal American. ‘I was just creating a mood.’

‘No need to create anything with me, Frank,’ says Martin Lomax.

‘Listen, Lomax,’ says Frank. ‘I like you, you know that. My dad likes you. You’re English, we respect that.’

‘I sense a “but” coming, Frank,’ says Martin Lomax.

‘Well, sure,’ says Frank. ‘If we don’t have our diamonds back by the end of next week, we’ll kill you.’

‘OK,’ says Martin Lomax.

‘Maybe you stole them, maybe you didn’t, we’ll deal with that another day. But I will fly over to see you, and if you don’t have them then we will conclude our business with you.’

Martin Lomax nods. This and worrying if everyone will be able to park later. What a day!

‘I will do it myself,’ says Frank. ‘It’ll be quick, I promise you that. That’s the least I can do.’

‘Do you never get tired of all this?’ says Martin Lomax. ‘You know I didn’t steal them, but there always has to be melodrama. I know you have a boss, but really, you should listen to yourself sometimes. You don’t always have to kill everyone, Frank. Douglas Middlemiss stole the diamonds from me …’

‘You say,’ says Frank.

‘Yes, I say,’ says Martin Lomax. ‘And you’ve worked with me long enough to trust me when I do. I am tracking him down as I speak, and soon I will have news for you.’

‘I don’t need news, Martin, I need the diamonds, and I need them the second I see you. Or …’

‘Or you’ll kill me, yes,’ says Martin Lomax. ‘I’ve got it. Nice and quickly as a mark of respect.’

‘Get my diamonds,’ says Frank.

‘Right you are,’ says Martin Lomax. ‘Love to Claudia and the kids.’

Frank shouts off camera, then returns to the microphone. ‘Claudia says hi back. See you soon, Martin.’

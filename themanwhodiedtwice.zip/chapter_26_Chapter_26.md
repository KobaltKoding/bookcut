## 26

‘And he kicked you in the back of the head?’

‘I’m afraid he did, Anthony, yes.’

Ibrahim had not told the others what time he was coming back today. He knew they would make a fuss, and he didn’t want a reception committee when he was unshaven. Instead he managed to get the final appointment of the day with Anthony, the hairdresser so in demand he now visits Coopers Chase three times a week. Ibrahim hasn’t been at all happy with his hospital hair.

‘You wouldn’t be able to tell, honestly,’ says Anthony, running a comb through Ibrahim’s hair. ‘No footprint, nothing.’

‘Well, it’s a skull,’ says Ibrahim.

‘You said it,’ agrees Anthony. ‘Tell me if I’m pressing too hard, though. We’ll get you feeling better in no time. That’s my job.’

‘Thank you, Anthony.’

‘You’ll bounce back, I know you will.’

‘Bouncing back is for younger men.’

‘Nonsense, what doesn’t kill you makes you stronger.’

‘Well, I disagree at my age.’

‘I’ll give you a for example. I once had a two-day acid trip, in Kavos. You know Kavos?’

‘Is that Greece?’

‘Ooh, I wouldn’t know, somewhere hot. Anyway, at the time it was terrifying, you know? I thought the walls of the villa were bleeding. I stood on the roof trying to grab hold of the aeroplanes as they were flying over. My mate Gav put it on Insta, 30,000 likes, and now I can see the funny side. But I thought I was going to die, and I didn’t, and the experience has made me a stronger man.’

‘In what way?’

‘Well, I don’t know. I mean, I do less acid these days? So that’s something, isn’t it? And I got about four hundred new followers on Insta. That’s my point, really. I don’t know what they did to your hair in hospital. I’m guessing no conditioner?’

‘I asked Ron to get me some, but he said he wasn’t sure what to ask for.’

‘Well, you’ve got me now.’

‘Anyway, I don’t think this has made me stronger. I am rattled, Anthony.’

‘Of course,’ says Anthony. ‘Post-traumatic whatever.’

‘But I will get over it eventually.’

‘Of course you will. Look at what Oprah’s been through over the years.’

‘Unless I die before I get over it. And then I will never get over it. That’s how I feel right now. Perhaps I will never heal.’

‘I’ll tell Joyce you were being morose if you keep this up.’

‘It is fine to say “what doesn’t kill you makes you stronger”. It is admirable. But it no longer applies when you’re eighty. When you are eighty whatever doesn’t kill you just ushers you through the next door, and the next door and the next, and all of these doors lock behind you. No bouncing back. The gravitational pull of youth disappears, and you just float up and up.’

‘Well,’ says Anthony, putting his palms on Ibrahim’s temples and lifting his head to look into the mirror, ‘I’ve just knocked ten years off you, so I’m doing the best I can to help. Do they know who mugged you?’

Ibrahim nods. ‘They have a name, yes. But no evidence.’

‘And what’ll happen?’

‘I suspect Elizabeth will happen.’

‘Well, let’s hope so,’ says Anthony, holding up a mirror behind Ibrahim’s head and getting another nod. ‘No one touches my friends and gets away with it. You tell Elizabeth if she needs any help, just ask.’

‘I will pass that on.’

‘For what it’s worth, and I do listen sometimes, you won’t die before you get better, I promise.’

‘Impossible to say.’

‘Ibrahim, you’re talking to someone who once dreamt the lottery numbers. Four of them. Three hundred and sixty quid. If I tell you you won’t die yet, you won’t die yet.’

‘That is a comfort, thank you.’

Anthony is packing up his kit. ‘We all know the order you lot will die. Ron first …’

Ibrahim nods.

‘Then Elizabeth, probably shot. Then it’s tough to call between you and Joyce.’

‘I wouldn’t want to be the last one left,’ says Ibrahim. ‘I have always tried to never get attached to people, but I have got attached to these three.’

‘Well, let’s say you third and Joyce last then.’

‘I wouldn’t want Joyce to be on her own either,’ says Ibrahim.

‘Oh, I don’t think Joyce would be on her own for long, do you?’

‘Well, I suppose not,’ smiles Ibrahim.

‘Such a naughty girl, that one.’

Ibrahim reaches into the pocket of his jacket, hanging behind the door, and pulls out his wallet. ‘Card, I’m afraid, Anthony – I used my last cash for the taxi.’ Ibrahim frowns as he opens the wallet. ‘Well, that’s peculiar, my card isn’t in here.’

‘I’ve heard it all now,’ chuckles Anthony.

‘I must have mislaid it, I’m ever so sorry. Can I owe you?’

Anthony walks over to Ibrahim and gives him a hug. ‘This one’s on me. Now, off you pop, handsome, they’ll all be dropping like flies when they see you.’

Ibrahim looks at his reflection, moving his head to see both profiles. He nods. ‘Thank you, Anthony. I rather think they will.’

## 79

Patrice looks at the clock, sighs and pours herself another glass of wine.

Nine thirty, dark outside, and she is only halfway through marking the Jane Austen homework. She thinks about Chris. She thinks about him more and more these days. Patrice has fallen in love before, and this is beginning to show all the signs. That might just be the wine and the Jane Austen though.

She has always worried about Donna’s work, and now she worries about Chris’s too. Is that something she could get over? At least they are both in Fairhaven. That felt safer than London. How much trouble could there be in Fairhaven?

There were schools down there, weren’t there? Of course there were, Patrice, you idiot, there are schools everywhere. What even made you think about it? It’s not like you’re going to be moving down there or anything.

She had felt safe and happy there during half term. Safe with Chris, and with Donna nearby. Happy with Chris, and with Donna nearby. They both feel a long way away now, as she sits alone in the house. But the weekend? At the weekend she is driving down to see them.

She thinks about ringing Chris. Maybe tell him how much she’s been thinking about him? Maybe. Or perhaps just tell him tomorrow? When she’d had less to drink? Yes. There are certain steps you take in life that you can’t easily turn back from. So take them with care. You don’t want to make a fool of yourself.

Patrice smiles. How could she ever make a fool of herself in front of Chris? She will ring him. She’ll mark three more essays, then she’ll ring Chris as her treat. She will be slurring her words a little bit, but if you slur your words with a man you can get away with saying anything. Maybe she will mention Jane Austen, and see where that leads? It will be nice to hear his voice. Do they have darts on TV on Mondays? If they do she is sure that’s what he’ll be watching.

There is a noise on the street outside. Probably foxes.

She picks up the next essay on the pile. Ben Adams. Patrice suspects that Ben hasn’t read a single word of _Sense & Sensibility_. She also suspects he has watched the film instead, mainly because at one point he accidentally calls Elinor Dashwood ‘Emma Thompson’. Nice try, kid. Oh God, this is going to take her for ever.

Patrice has said it so many times, marking will be the death of her.

As she picks up the next essay, she hears a knock at the door. Another glance at the clock. That’s late.

Patrice knows she should probably ignore it. But perhaps it’s a neighbour needing something. And she’ll do anything to leave the marking alone for a moment.

Patrice walks down the hallway, glass of wine still in hand. Donna has told her a hundred times to get deadlocks, to get peepholes, ‘Never answer your door to strangers, Mum.’ How old did she think Patrice was? Patrice will get peepholes and deadlocks when she’s older. Patrice isn’t even fifty, and she’s not going to be frightened in her own home. It’s nice that Donna cares, but Patrice can look after herself, thank you very much. She should ring Donna too. She’s been a little down. So, ring Chris, then ring her little girl. Or ring her little girl first?

Patrice puts her wine down on the hall table and gives her hair a quick check. She nods her approval. You should always look your best, whoever’s at the door.

The knock comes again, a little more insistent. All right, all right. Patrice flicks up the latch and pulls the door open.

Her mouth falls open, marking forgotten, wine forgotten, hair forgotten.

It is not a neighbour. She tries to compute, but there is no time.

‘Look,’ says Chris, standing on her doorstep, flowers in his hand and tears on his cheek. ‘I know it’s late, but it couldn’t wait. I can’t go another minute without telling you. I’m in love with you. I’m sorry if that’s stupid.’

Patrice tries to think of something to say. She is so pleased she checked her hair. What would Jane Austen say?

‘Can I come in?’ Chris asks.

‘Yes, my darling. Yes, you can come in,’ she says. Patrice takes her wine from the hall table and reaches out her hand to lead Chris inside.

That will do just fine.

## 20

Something happened last night, Bogdan Jankowski can just tell.

He is on his way to the building site on top of the hill, but has popped into the shop at Coopers Chase to buy some Lilt Zero and twenty Rothmans.

A man he doesn’t know has just got out of a van he doesn’t recognize and headed over to Ruskin Court.

Bogdan watches as the man lets himself into Ruskin Court using a key he shouldn’t have.

Something is up here. Bogdan approaches the van. As he peers through the passenger side window he sees a newspaper, which is usual in a van, but then notes it is the _Daily Telegraph_, which is not. He looks at the side of the van, ‘F. Walker Roofing – All Jobs Considered’.

From the corner of his eye, Bogdan sees Elizabeth, Ron and Joyce emerging from Ruskin Court. What are they all doing in Ruskin Court? Trouble, always trouble. And if there is trouble to be had, then Bogdan would like a piece of it.

Elizabeth waves goodbye to Ron and Joyce, hurries over to him and, hooking her arm through his, leads him away from the van.

‘What’s the van?’ asks Bogdan.

‘How should I know?’ says Elizabeth, who makes it her business to know everything. ‘Good morning, though.’

‘Good morning to you. Who are you seeing in Ruskin Court so early?’

‘I borrowed a book from Margery Scholes,’ says Elizabeth.

‘What book?’ asks Bogdan.

‘A Jeffery Deaver,’ says Elizabeth. ‘It’s terrific.’

‘Which one?’ asks Bogdan. They are now approaching Elizabeth’s home in Larkin Court.

‘The most recent one. Thank you for walking me home. Will you be coming to see Stephen later?’

Bogdan nods. ‘We got a big crane going up this morning, but nothing special after lunch so I come down.’ Bogdan is in charge of the new Hillcrest development currently taking shape high up above them. He has had a series of rapid promotions due to the recent events, but is taking everything in his stride. Bogdan always takes everything in his stride.

‘Who was the guy who went into Ruskin Court? Wearing gloves?’

‘No idea, darling. Drains? Drains would wear gloves, wouldn’t they?’

‘He walked in thirty seconds before you walked out. And you walked out ten seconds after I start to look at the van?’

‘I think you’re being a little paranoid, Bogdan. Are you getting enough sleep?’

‘I get eight hours and twenty minutes every night,’ says Bogdan. ‘You promise me something, though?’

‘If I can, of course. If I can’t, then no.’

‘You tell me why you’re lying eventually? About the van and the man? And I just saw Margery Scholes in the shop, so how did you get into Ruskin? You tell me sooner or later?’

‘Oh, Bogdan, we all have our secrets. I’ll see you later, I hope?’

Bogdan nods and Elizabeth goes inside. Bogdan retraces his steps, but the van has gone.

He walks up the hill thinking about men with gloves, and keys they shouldn’t have.

The Hillcrest development is running according to plan. Of course it is. He is making plenty of money too. Half goes into the building society, and half goes into Bitcoin. He is not tempted to buy a house, because buying a house meant you were staying, and you could never really predict if you were staying, could you? Bogdan spends the morning checking the works, supervising the installation of the crane and smoking his Rothmans. He then makes his way back down the hill, to play chess with Elizabeth’s husband, Stephen.

He passes the graveyard where the nuns are buried. What do they make of the steam hammers sinking foundation posts further up the hill? Bogdan finds the noise soothing, and he hopes they do, too. No one wants silence for eternity.

He passes Bernard’s bench. It was strange not to see the old man there, keeping guard. People here came and went, they came and went. Knowing they were here to live out their days made them vital. They moved slowly, but their time ran fast. Bogdan liked to be among them. They will die, but so will we all. We are all gone in the blink of an eye, and there is nothing to do but live while you’re waiting. Cause trouble, play chess, whatever suits you.

He and Stephen try to play at least three times a week. It gives Elizabeth a bit of time off to go shopping, visit friends, solve murders. Stephen forgets most people’s names now, but he has never forgotten Bogdan’s.

Inside Elizabeth’s flat, the game is twelve moves old, and Bogdan has Stephen in something of a bind. Bogdan is not counting his chickens, of course – you must never do that with Stephen – but he is happy with his position. He doesn’t see that Stephen has many options for his next move.

That next move may take a while, as Stephen has fallen asleep. It is happening more and more often these days as he shuts down further and further still. But so long as Stephen is here, Bogdan will play chess with him.

And whenever Stephen’s eyes pop back open, Bogdan knows he will still be in for a brutal game. Exactly the way he likes it. Stephen has forgotten many things, but he hasn’t forgotten how to win a game of chess. He also hasn’t forgotten Bogdan’s big secret, the part he played in the recent murders, and is happy to bring it up whenever a game is particularly tight.

Bogdan has no fear though. He trusts Stephen absolutely. And who would Stephen tell anyway? Only Elizabeth, and Bogdan trusts Elizabeth completely too.

And speak of the devil, Bogdan hears the key in the door, and sees Elizabeth walk in. She is carrying a large sports holdall. Which is unusual.

‘Hello, dear,’ says Elizabeth. ‘Is he asleep?’

‘Maybe. I think he’s faking it though. He knows I’ve got him beaten.’

‘Let me make you both a cup of tea. Could I ask you a favour, Bogdan?’

‘Who was the man with the gloves?’ asks Bogdan.

‘An MI5 risk-assessment underwriter,’ says Elizabeth. ‘Happy?’

‘Yes, thank you,’ says Bogdan. ‘What favour do you need?’

Elizabeth puts the holdall down on the dining table, next to the chess board. She unzips it to reveal bundles of money.

‘Money,’ says Bogdan.

‘Nothing gets past you, does it, dear?’ says Elizabeth.

‘And what for?’ asks Bogdan.

Elizabeth double-checks that Stephen is still asleep. ‘Could you buy me ten thousand pounds’ worth of cocaine?’

Bogdan looks at the money and nods. ‘Sure.’

Elizabeth smiles. ‘Thank you, I knew I could rely on you. Wholesale though, not street price.’

‘Of course,’ says Bogdan. ‘Is this to do with the man and the van?’

‘No, this is something different.’

‘When do you need it by?’

‘Tomorrow lunchtime?’

‘No problem,’ says Bogdan.

‘Lovely, you’re such a help, you really are. I’ll flick the kettle on.’

Bogdan takes another look at the holdall as Elizabeth disappears into the kitchen. Who would have that much cocaine at this short notice? There was a woman in St Leonards who used to be a teaching assistant at a primary school and now works out of a row of lock-up garages by the seafront. He would try her first. She had once asked him on a date, and he had told her that he wasn’t attracted to her, and that he worried about her career, because it is very important to be honest in romantic endeavours. No one will ever thank you for dishonesty. She had thrown a pint glass at him, but it was some months ago now, and he’s sure she’ll still do him a favour. Bogdan takes out his phone, but before he can text, Stephen wakes, looks at the board as if there has been no delay, and moves his bishop. Bogdan puts down his phone and processes what Stephen has done. He had not seen that coming at all. What a move. Bogdan smiles.

Elizabeth’s ten thousand pounds. Stephen’s bishop. No wonder they got married. You had to hand it to these two.

Bogdan has a job to do, and some thinking to do. Which is just how he likes it.

## 43

The Left-Luggage Office is attended by a bored-looking teenage girl wearing headphones. Elizabeth holds up her key as she and Joyce walk past, and the girl nods them through.

‘I don’t think you should be allowed to wear headphones at work,’ says Elizabeth. ‘You miss everything.’

Joyce nods. ‘Lovely hair though.’

There are five rows of lockers, grey metal frames and chipped blue doors, stacked three lockers high from floor to ceiling. Elizabeth leads Joyce to the fifth row, and they begin the walk down it.

‘I hope it’s a middle one,’ says Joyce. ‘No bending or reaching.’

Elizabeth stops. ‘You’re in luck, Joyce; middle locker, 531.’

They both look at the locker: 531 is written in sloping white numerals against the blue door. Elizabeth looks at the key. Small and flimsy. Anyone could break in. The girl on reception wouldn’t exactly stop you. What a place to hide twenty million pounds.

‘Well, here goes nothing,’ says Elizabeth and slides the key into the lock. At first it meets resistance, so Elizabeth pulls it out and tries again. But there is resistance once again, and she frowns. She lowers her eye to the keyhole.

‘Lock must be damaged. Hairpin, Joyce.’

Joyce searches through her bag and pulls out a hairpin. Elizabeth inserts it into the keyhole very gently, pushing, then twisting, then pushing again. The metal door swings open, to reveal the fate of Douglas Middlemiss.

To reveal nothing.

Well, not nothing exactly. Three grey walls, and a discarded crisp packet. The diamonds are gone.

Elizabeth looks at Joyce. Joyce looks at Elizabeth. They are both quiet for a moment.

‘It’s empty,’ says Joyce.

‘Up to a point,’ says Elizabeth, and pulls out the crisp packet.

‘Is this good news, or bad news?’ says Joyce.

Elizabeth stays silent for a moment, then nods herself back into action.

‘Well, it’s news, certainly,’ says Elizabeth. ‘Time will tell whether it’s good or bad. Joyce, put the crisp packet in your bag.’

Joyce obediently folds the crisp packet and puts it into her bag. Elizabeth shuts the locker door and inserts the hairpin once again. She twists it until the door locks with an unconvincing click.

Joyce leads the way out and they nod to the girl on reception as they leave.

‘Excuse me,’ says the girl. Elizabeth and Joyce turn back and the girl takes her headphones off. ‘A couple of things. First off, there’s nothing on these headphones, I only wear them because it stops the manager of Costa coming over and chatting me up, if he thinks I’m listening to something.’

‘Well, I apologize,’ says Elizabeth. ‘What’s the second thing?’

The girl looks at Joyce. ‘I just wanted to say thank you for being nice about my hair. It’s my first post-break-up haircut, so you’ve made my day.’

Joyce smiles. ‘Plenty more fish in the barrel, dear, you take my word for it.’

The girl smiles back and makes a head gesture towards the lockers. ‘I hope you found what you wanted today.’

‘Yes and no, apparently,’ says Joyce, and the girl slides her headphones back on.

As they leave the station Elizabeth sends a text, then plunges into the warren of alleyways behind the station. Joyce has no idea where they are walking now, but they are certainly walking somewhere as Elizabeth leads her expertly through the back streets of Fairhaven.

They take a left and then start down a small footpath. Are they headed for the police station? Why would they be headed for the police station? To give Chris and Donna a crisp packet? Joyce rarely questions Elizabeth, but one of these days she will lose it, surely? Perhaps today is that day?

They are crossing a small park now; there are children on a climbing frame, trying to get the attention of parents looking at mobile phones. They are definitely going to the police station. Joyce is trying to remember if there are toilets there. Surely there must be? But what if they’re just for prisoners?

Soon Joyce sees the police station in the distance, and sitting on the stone steps outside is Donna. That must have been who the text was for.

Donna pushes herself up as Elizabeth and Joyce approach. Donna gives Joyce a hug. Elizabeth waves a hug away. ‘Hello, dear, no time for hugs. Did you bring the light?’

Donna holds up something that looks like a small pen.

‘What’s that for?’ asks Joyce.

‘Can you take the crisp packet out of your bag?’ asks Elizabeth.

Joyce knew it. There was no way Elizabeth was making her put an old crisp packet in her bag without a good reason. Joyce takes out the packet and hands it to Elizabeth. Elizabeth tears down the side of the packet, exposing the foil inside. She then flattens the foil on one of the steps. Joyce cocks her head, so Elizabeth explains.

‘Tradecraft, Joyce. If Douglas had wanted the locker to be empty it would have been empty, but it wasn’t.’

Donna shows Joyce the light. ‘This is an infra-red light. I used to use it when we found stolen bikes. Sometimes the owner would have invisibly marked them.’

‘And, of course, Donna doesn’t have to track down stolen bikes any more, thanks to us,’ says Elizabeth.

‘For which I’ve thanked you many times,’ says Donna.

‘Now she investigates murders,’ says Elizabeth.

‘Elizabeth, you think perhaps it’s a sign of my gratitude that I’m standing on the steps of the police station about to help two old ladies shine an infra-red light at a crisp packet?’

‘You know we appreciate you, dear. Now let’s get to it.’

‘Old ladies,’ giggles Joyce. ‘I always find that funny.’

Donna kneels and switches on the light. Joyce thinks about kneeling, but really, kneeling over the age of sixty-five is a pipedream, so she sits on the step above instead. Elizabeth kneels. Is there nothing she can’t do?

The red light plays across the foil and Joyce sees letters appear. There is clearly a sentence written on it.

‘What now, Douglas?’ says Elizabeth with a sigh.

Donna moves the light to the top right corner of the foil and starts to read words as she reveals them.

‘“Elizabeth, darling …”’

Elizabeth mutters, ‘I’ll darling you.’

‘“Elizabeth, darling, we both know that things are never in the first place you look. This was just an extra layer of security, in case somebody else found the letter. But you know where the diamonds are, don’t you? If you really think about it?”’ Donna stops reading and looks up at Elizabeth.

‘That’s it?’ asks Elizabeth.

‘Well, then it says “from your ever-loving Douglas” and three kisses,’ says Donna. ‘But I didn’t want to hear the tut if I read that out.’

Elizabeth gets back to her feet and reaches out a hand to help Joyce up too.

‘So we still don’t know if he’s alive or dead?’ says Joyce.

‘Afraid not,’ says Elizabeth.

‘But he says you know where the diamonds are?’ says Donna.

‘Well, if he says I know, then I know,’ says Elizabeth. ‘I have some thinking to do.’

Talking of thinking, something has been bothering Joyce, but she hasn’t mentioned it. She had never been a spy, so what did she know? It was probably silly. But the sun was out, and she was with two of her favourite people, so where was the harm?

‘Didn’t you think it was strange that the lock was damaged?’ she says.

‘Strange how?’ says Elizabeth.

‘Well, he gave you the key, so presumably it was working when he locked it up? And no one would have been there since. So how did the lock get damaged?’

‘That’s a good question,’ says Donna, and Joyce beams.

‘It’s a very good question,’ says Elizabeth.

Even better! What a lovely day Joyce is having.

‘Donna, there was CCTV in the locker room,’ says Elizabeth. ‘You don’t think you could possibly get hold of it? Just for the last week?’

‘I could get hold of it, but I’m not going to sit through a week of CCTV footage just because Joyce has a hunch. No offence, Joyce.’

‘Oh, I never take offence,’ says Joyce. ‘Such an effort.’

‘If you can get it, Donna, Ibrahim has plenty of time on his hands at the moment. And he loves to be useful.’

‘OK, I’ll see what I can do,’ says Donna. ‘But if there’s any way we can get involved in this case, then you promise you’ll let us?’

‘I think that sounds fair,’ says Elizabeth. ‘Any more news of Ryan Baird?’

‘Court case next week, I’ll let you know.’

‘Are you working on anything fun?’

‘Staking out a local drug dealer. Connie Johnson. Nasty piece of work.’

‘They often are,’ says Elizabeth. ‘And I believe we are seeing you later?’

‘Looking forward to it very much,’ says Donna.

‘Any intelligence you can give us on Patrice, before we meet her?’ asks Elizabeth.

‘She’s OK,’ says Donna. ‘Bit mumsy for me.’

Joyce looks at her watch. They still have an hour before they have to meet the minibus. Time for an almond-flour brownie and a cup of mint tea. Today was one of those days when everything was just falling into place. Perhaps she should buy a scratch card.

## 22

## Joyce

So I rang Poppy’s mum, and she could not have been nicer. She is called Siobhan, and, yes, I did just have to look up how to spell it. She must have been Irish at some point, but it doesn’t seem like she is now.

I filled her in on what had happened. I thought that must be what Poppy meant, because perhaps when you’re a spy you don’t always tell your mum everything that’s going on. Or perhaps that’s just daughters in general? I’m lucky if I find out Joanna has had a haircut, for example. She once had a week in Crete and the first I knew about it was from Facebook. I reminded her that we had once had a week in Crete when she was little, but apparently this was a very different part of Crete, which she took delight in telling me. So I have been in Siobhan’s shoes in some ways.

This is how it went. There were pleasantries, and I told her that Poppy had asked me to ring her, and that she was quite safe, but there had been an incident.

I actually said, ‘Don’t worry, no one has died,’ before I realized that, of course, somebody had.

It became apparent, and I suppose I shouldn’t have been surprised, that Siobhan wasn’t fully on top of what her daughter does for a living. The way she had been told it, Poppy worked for the Passport Office. They had done some checks on Siobhan when Poppy got the job, and she thought that unusual at the time, but hadn’t really questioned it. There’s always something with children, isn’t there? Dressing them up for World Book Day and the like.

Really, I should have broken things to her in stages, but in nursing you get the sense of when it’s better to come straight out with it. I said something along the lines of your daughter works for MI5 or MI6 and she’s looking after a man who used to be married to my friend Elizabeth, and who has been accused of stealing diamonds (her: ‘_MI5?_’ ‘_Elizabeth?_’ ‘_Diamonds?_’). An intruder had tried to shoot the man last night, and Poppy had shot the intruder. That was as short as I could get it.

Siobhan was taken aback, and I thought perhaps she thought it was a prank, so I added, ‘This isn’t a prank, it really happened, she really did shoot him, and I even saw the body.’

I told her that Poppy had given me her number, and she asked where Poppy was now, and I said I didn’t know, and that MI5 had taken her away, but that Elizabeth had said that was nothing to worry about, and that Poppy had done the right thing in the right way and had saved someone’s life.

Siobhan asked where it happened and I told her all about Coopers Chase. She said it sounded lovely and I said, ‘Well, why don’t you come and visit? Meet me and Elizabeth?’

Siobhan said she would like that, and then she started to cry, which was for the best in my opinion. Let it out. Imagine if your daughter had just shot a man and been taken away by MI5? You couldn’t help but feel emotional. I asked for her address, so I could pop a friendship bracelet straight in the post for her. I’ll get the money when I see her.

We had a nice chat after that. She apologized for crying and I said not at all, then I asked if she liked Poppy’s nose ring, and she thought for a while and said not really, she thought Poppy was prettier without it. I said Poppy was still very pretty with it, but I sympathized because Joanna once had three piercings in the same ear, one at the very top, and it was awful. You can still see a tiny scar there now, where it didn’t properly heal over. You wouldn’t notice it, but I always do. I think Siobhan and I are going to get along.

So Siobhan is going to come and see us, that’s the big news. I hope Elizabeth won’t mind. Poppy had slipped the phone number into my cardigan pocket, not Elizabeth’s, so perhaps she knew this wasn’t the done thing in these circumstances. Will Elizabeth object? Well, if she does, then that’s her problem and not mine.

She lives in Wadhurst, by the way. Siobhan. I’ve been through it on the train, but that’s about it. I’m sure it is very nice, if Poppy and her mum are anything to go by.

Just as I hung up, my door buzzer went, and it was Yvonne, my old neighbour, wanting a cup of tea and a chat. She was the first person I know to get a video recorder, I’ve never forgotten it. I remember they invited Joanna round to watch _ET_. Honestly, the look on Joanna’s face. Anyway, she lives in Tunbridge Wells now, of course she does, so I asked her to pop the bracelet through Siobhan’s letterbox on her way home. Saves a stamp, doesn’t it?

What else then? Ryan Baird, of course. Ron has really got the wind between his legs with that one. I am looking forward to hearing the plan. And Ibrahim should be home tomorrow. He told us not to visit him again, and that’s for the best as Elizabeth wants us to take a trip to Hove, for reasons she kept to herself.

I’m baking for Siobhan now. I have no idea what she likes, and I couldn’t find a place in our conversation to ask her. So I’m playing it very safe with a Victoria sponge, some brownies with no nuts and a coconut and raspberry slice in case she’s adventurous.

I do keep thinking about the diamonds. Twenty million pounds would turn most people’s heads, wouldn’t it? It would turn mine. On _Deal or No Deal_ they would say that £25,000 was ‘life-changing money’, but I don’t know about that, once you’d paid off your credit cards and been to Portugal, perhaps a couple of replacement windows. But twenty million? Someone is going to get their hands on it, I suppose, even if they have to murder a few people along the way.

I realize I didn’t mean that Ron has ‘really got the wind between his legs’ by the way. What’s the right expression? It’s something like that, isn’t it? I’ll leave it for now, though, because it actually rather suits Ron.

So, Hove with Elizabeth tomorrow, which will be fun. We’re getting the 2.30 bus into Brighton, and we’ll get out by the big M&S and walk into Hove. Elizabeth has said, ‘Strictly no shopping, Joyce,’ so we’re certainly on business of some sort.

What sort of business though? Diamonds? Murder? Perhaps a bit of both? That would be nice.

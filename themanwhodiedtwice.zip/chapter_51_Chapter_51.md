## 51

Ibrahim is propped up in bed. He has a cigar and a glass of brandy on his bedside table, and his laptop open in front of him. He clicks on the CCTV file Donna has sent him. You will go a long way to find someone else in Coopers Chase who knows as much as Ibrahim about IT. A long way.

‘Now, I need you to listen carefully,’ says Ibrahim. ‘Douglas and Poppy were murdered sometime before five p.m. on the twenty-sixth, so we only need to watch the footage from then until Elizabeth and Joyce check the locker on Thursday. Just the next three days or so.’

‘OK,’ says Kendrick, and leans his head on Ibrahim’s shoulder.

‘Why don’t I look through the twenty-sixth on my laptop, and you look through the twenty-seventh on your iPad?’

‘Brilliant,’ says Kendrick.

‘And if you see anyone trying to open locker 531 then just shout.’

‘OK,’ says Kendrick. ‘Well, I won’t shout, I’ll just tell you.’

‘That’s a good plan,’ agrees Ibrahim. ‘And let’s talk while we’re watching.’

‘So we don’t get bored!’ says Kendrick.

‘Exactly,’ says Ibrahim, and presses play on the CCTV footage. The fastest he can play it is at 8x speed. The facility opens at 7 a.m. and shuts at 7 p.m., so it will take him ninety minutes to get through the day. With Kendrick he can cover two days in that time. Perhaps it’s not the perfect job for an eight-year-old, but children were far too mollycoddled these days.

‘I’m watching mine now,’ says Kendrick. ‘What should we talk about?’

Ibrahim is looking at the black-and-white feed on his screen. The camera shows the whole aisle of lockers. Even at 8x speed, not a soul has come or gone yet. ‘How is school?’

‘Ummm, it’s OK,’ says Kendrick. ‘Do you know Romans?’

‘I do,’ says Ibrahim. A backpacker has just stuffed her bag in a locker further down the aisle.

‘Who’s your best?’ asks Kendrick.

‘My best Roman?’

‘Mine is Brutus. There was just a cleaner, but she didn’t steal anything.’

‘I think I like Seneca the Younger,’ says Ibrahim. ‘He was the greatest of the Stoic philosophers. He was very good on the theory of the whole thing, but also always looked to give practical advice. He believed philosophy was not a sacred text, but a medicine.’

‘Oh, great, we haven’t done him,’ says Kendrick. ‘What’s the best dinosaur? Stegosaurus?’

‘Yes, we agree there, Kendrick,’ says Ibrahim, and takes a swig of brandy.

‘Does it hurt where they kicked you?’ asks Kendrick, his eyes still clearly glued to the CCTV.

‘I tell the others it doesn’t,’ says Ibrahim. ‘But it does, very much.’

‘They probably know,’ says Kendrick.

‘They probably do,’ says Ibrahim. ‘But you’re the only person I’m telling for sure.’

‘Thanks, Uncle Ibrahim,’ says Kendrick. ‘Someone just took a box out of one of the other lockers, but just boring. Did you feel it when they kicked you? Were you frightened?’

‘Those are very good questions,’ says Ibrahim, as a man in a suit puts his briefcase in a locker, then takes off his tie and puts that in too. Lost his job and hasn’t told his wife yet. ‘I remember being very scared, and I remember feeling like I was in a washing machine. That’s silly, isn’t it?’

‘Not really,’ says Kendrick. ‘If that’s what you felt.’

‘And I knew I might die, I remember that. And I thought about that, and I thought it was OK, but perhaps unfair that this was how it was going to happen. And I thought, I wish I’d known.’

‘Uh huh,’ says Kendrick.

‘And I thought about your grandad, and I thought about Joyce and Elizabeth too, and I knew I would miss them, and I knew they would miss me, and I thought, I hope I don’t die, I hope this ends up OK.’

‘I’m happy that you didn’t die, because then we wouldn’t be doing this.’

Ibrahim lights his cigar.

‘If I was being killed I would think of Grandad too, and now I would think of you. And I would think about Cody at school, and Melissa and also Miss Warren. And I would think mainly about my mum. Wow, that’s a big cigarette! You shouldn’t smoke, did you know that?’

Ibrahim takes a puff. ‘Mostly I do what I’m told, life is easier that way. But sometimes I don’t do what I’m told.’

‘Like me,’ says Kendrick. ‘Sometimes I stay awake, but Mum doesn’t know.’

‘You wouldn’t think about your dad?’ asks Ibrahim. ‘If you were being killed?’

Kendrick considers this for a moment. ‘I think maybe he’d be angry about it.’

Ibrahim nods and tucks this away. ‘I didn’t think about my dad either.’

‘You don’t have a dad, Uncle Ibrahim. He would be a thousand.’

The boys settle to their work for a while. Ibrahim sees seven or eight people walking up the aisle, always to other lockers, and Kendrick sees about the same. No one has yet touched locker 531\. The occasional conversation is very easy, and Ibrahim discovers that Kendrick’s favourite number is thirteen, because he feels sorry for it, and Kendrick sets him a quiz about the planets. Biggest, Jupiter, best, Saturn. (‘Not Earth?’ ‘You can’t count _Earth_!’) The clock on the screen ticks on, eight times faster than the clock on his bedside table. Another cleaner comes in at the end of the day, and they are done.

‘That was so good,’ says Kendrick. ‘Can we do the other day together now?’

Ibrahim agrees that they can. He receives a text from Elizabeth – _Any news? –_ and he replies _Yes_. _I am concerned about Kendrick’s relationship with his father_. Elizabeth replies back with a rolling-eyes emoji. She has really taken to emojis.

After a toilet break, considerably quicker for Kendrick than for Ibrahim, they settle down for the footage from the day Elizabeth and Joyce opened the locker, and so they will stop as soon as they see them.

The fast-forwarded black-and-white images zoom by once again. Neither Ibrahim nor Kendrick tires, because who tires when they are having fun? Ibrahim asks if Kendrick likes books and Kendrick says he likes some of them but not others, and Kendrick asks if Ibrahim ever lived in another country, and Ibrahim replies Egypt, and Kendrick spells it for him.

Ibrahim is looking at the video when, around lunchtime, he sees Elizabeth and Joyce, and slows the footage down to normal speed. He can’t hear what they are saying, but you can always pretty much guess with those two. He sees them having trouble opening the locker, sees Joyce go into her bag, then sees Elizabeth try again, and the locker door pops open. The picture quality is not great, but you can make most things out. Elizabeth takes out the crisp packet, the one she showed Ibrahim this morning, then Joyce puts it in her bag, and they leave.

Kendrick wants to see the footage of Joyce and Elizabeth, and says, ‘Oh my goodness, it’s really them,’ when he does. But they find nothing else and admit defeat. So no one had visited the locker? No one had tried to open it until Elizabeth and Joyce arrived.

‘I wish we’d seen a baddie,’ says Kendrick.

‘Me too,’ says Ibrahim. ‘Elizabeth won’t be pleased.’

‘Let’s do the day before,’ says Kendrick. ‘Just for fun and in case?’

Ibrahim agrees, because the moment this task is over Kendrick will be heading back to his grandfather’s.

They watch the footage from the twenty-fifth, the day before Poppy and Douglas were murdered. Or just Poppy, if you believed Elizabeth. Had Douglas really faked his own death? Hmmm. They are a little quieter this time, both comfortable in the silence. Kendrick makes Ibrahim guess how fast a rocket is, but that’s about it.

As they are watching together, they both see the figure at the same time. Walking down the aisle like the hundred or so others they must have seen before. But this figure is wearing motorcycle leathers and a closed helmet. And this figure stops dead in front of locker 531.

‘What have we here, Kendrick?’ says Ibrahim.

‘Maybe a baddie?’ says Kendrick.

‘Maybe a baddie,’ agrees Ibrahim, and takes another puff on his cigar. Who needs the outside world?

## 66

‘Well, he’ll kill me,’ says Martin Lomax, as if talking to an idiot. ‘Chop my legs off, you know the mafia.’

‘Agreed,’ says Sue Reardon. ‘That’s why we’re here. To protect you.’

‘Good luck,’ says Lomax, and turns to Lance James standing by the window, looking out over the gardens. ‘Good luck, eh, Lance?’

‘If they want to kill you, they’ll kill you,’ says Lance. ‘We can probably delay them a bit. But you know the mafia.’

‘Don’t I just,’ says Lomax. ‘They don’t even take their shoes off when they come in.’

Lance has taken to visiting Martin Lomax every morning, at around eleven. Staking out a house was boring, especially as Lomax never left it. So they had come to an arrangement.

Lomax lets him charge his phone and use his Wi-Fi. And in return he would ask Lance questions about the Special Boat Service.

Nothing classified, obviously, but Lomax is a military history nut, and Lance has plenty of good stories. Lance had been based down in Poole for fifteen years with the SBS, been on operations that everyone had heard of, and he’d been on operations that nobody would ever hear of. Certainly not from him.

‘Frank Andrade will be landing on Monday, in a private jet, at Farnborough airfield,’ says Sue. ‘I’m guessing he’ll come straight here.’

‘What time does he land?’ Lomax asks.

‘Eleven twenty-five a.m.,’ says Lance.

‘Well, he’ll hit traffic,’ says Lomax. ‘The A3 will be snarled up.’

A lot of the work the Special Boat Service would do came through the Security Service, or the Special Intelligence Service, MI5 and MI6\. As he got older, Lance spent a bit less time chasing al-Qaeda and a bit more time at a desk. He would come up to London every now and again to give briefings. He would consult on operations. Before you knew it, he had been taken aside and asked to join MI5 permanently. Keeping his hand in on operations, of course. Overseeing the raid on Martin Lomax’s house, for example. That sort of thing. Lance could break into anything, and kill anyone. The builder who’d slept with his ex didn’t know how lucky he’d been.

‘We will have a team here on that morning,’ says Sue. ‘Commanded by Lance.’

‘SBS?’ asks Lomax.

‘I can’t say,’ says Sue.

‘But yes,’ confirms Lance.

He knows he is still seen as a foot soldier. Looked down on a bit by some of the public-school kids. And he knows he is in danger of getting stuck where he is unless he can make some sort of impact.

This case would be a good place to start. A nice calling-card.

‘We wouldn’t need all this fuss if you simply found the diamonds,’ says Lomax.

‘I guarantee that’s our plan,’ says Sue.

‘Well, it seems you only have a few days left,’ says Lomax.

‘I am confident we’ll find them,’ says Sue.

Lance doesn’t share her confidence. Perhaps Elizabeth Best will find them? That’s the only hope. But, either way, Martin Lomax will never see them again. That’s not how this will work.

How will it work? Lance supposes he will have to wait and see. But Martin Lomax is a dead man.

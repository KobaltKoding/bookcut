## 10

## Joyce

So I have joined Instagram, if you know it?

Joanna persuaded me. She said you can see all sorts of photos from all sorts of people. Nigella, Fiona Bruce, everyone.

I joined this morning. It asked me for a ‘username’ so I put in my name and it said ‘@JoyceMeadowcroft has already been taken’ and I thought ‘I should be so lucky’. Then I tried @JoyceMeadowcroft2, but that was gone as well.

Then I thought about nicknames, but really most people just call me Joyce. Then I remembered a nickname from back in my nursing days. There was one consultant who would always call me ‘Great Joy’. Whenever our paths crossed, he would say, ‘Ah, here she is, Great Joy, her beautiful smile spreading happiness.’ Which was lovely, but not when you’re changing a catheter.

Looking back, I realize he wanted to get into my apron, and I would have let him, had I caught on. The paths not taken.

So I tried ‘@GreatJoy’, but nothing doing. I added my year of birth so I was ‘@GreatJoy44’ but still no luck. Then I added Joanna’s year of birth and, bingo! So I’m all set up and registered as ‘@GreatJoy69’, and am looking forward to having lots of fun. I’ve already followed the Hairy Bikers and the National Trust.

It was a nice thing to do, to be honest, because today is Sunday, and I sometimes get blue on Sundays. Time seems to go a little slower. I think because lots of people are spending it with their families. The restaurant is always full of fidgeting nieces and disappointing sons-in-law. Also on Sunday the daytime TV is not as good, the _Bargain Hunts_ are always repeats, there’s no _Homes Under the Hammer_, nothing. Joanna says I can watch something on catch-up, and I’m sure she’s right, but that feels even lonelier somehow. I’d honestly rather she just came down for lunch with her mum. She does come sometimes, to be fair. She was here an awful lot more during the murders, and who can blame her? Not me.

In the absence of any more murders, though, I imagine a dog would be a draw. Though Joanna’s probably allergic. She never was as a child, but people seem to get allergic to all sorts as soon as they move to London.

Today I am going to get a taxi down to Fairhaven with Ron and Elizabeth to visit Ibrahim, so that will cheer me up at least. I love hospitals, they’re like airports.

I have bought Ibrahim a _Sunday Times_, because I once saw one at his place. Goodness me, it weighs a ton. To lighten the load I have taken out any sections I think won’t interest him, but that’s only fashion, and a special pull-out report about Estonia, so it has made very little difference. I have also bought him some flowers, a big Dairy Milk, and a can of Red Bull because of the adverts.

I know the others were shaken to see him bruised and bandaged, but I was grateful to see it was only that. I was certainly relieved to hear him talking. Relieved, and then a bit bored, because you know Ibrahim, but the boredom was a lovely feeling.

I have seen worse is all I’m saying. A great deal worse. I won’t go into details.

On our way there on Friday I was reassuring Ron and Elizabeth, nothing to worry about, he’s in good hands, they found him so quickly. But I had feared the worst. There are some injuries you don’t recover from. Ron and Elizabeth are no fools, of course, so they will have known I was just being reassuring, but that doesn’t make it any less important. At any given time, somebody has to be calm, and it was my turn.

When I got home I had a cry, and I’m sure they both did too. But when we were together, we were as good as gold.

I know I’m only talking about the immediate injuries, by the way. I realize there is an awful road ahead for Ibrahim when what has happened sinks in. He is very wise, but he is also very vulnerable. Perhaps he is wise because he is vulnerable? Because he lets everything in? Now I’m the one who sounds like a psychiatrist! I think I would talk too much to be a psychiatrist. You wouldn’t get your hour’s worth.

Is it psychiatrist or psychotherapist, by the way? I can’t remember which one Ibrahim calls himself. I’ll ask him today. I am looking forward to seeing him ever so much. One thing I know is that it will be important to have good friends around him when he gets home, and I can guarantee that.

Another thing I can guarantee? The boy who decided to steal my friend’s phone, and aim a kick at my friend’s head, and race off leaving him for dead? He will wish he was never born.

I don’t think psychiatrists really encourage revenge. I don’t know, but I imagine they might preach forgiveness, like Buddhists? There was a quote on Facebook about it. Either way, psychiatrists and I are going to have to disagree on this one.

Perhaps Ryan Baird has had a difficult upbringing? Perhaps his dad left or his mum left, or they both left, or he’s hooked on drugs, or he was bullied, or he didn’t fit in. Perhaps all of these things are true, and perhaps there are places Ryan Baird might find a sympathetic hearing. But he won’t find one with me, he won’t find one with Ron and he won’t find one with Elizabeth. Ryan is out of whatever luck he may ever have had.

I can’t tell you how tempted I am to have some of this Dairy Milk. I know Ibrahim will let me have some as soon as I hand it over, but you know what it’s like when it’s just staring you straight in the face? I should have bought him grapes, then I wouldn’t have been tempted.

I will have a bit of the chocolate now. Don’t you think? I’ll just nip up to the shop and buy him a new one before the taxi arrives. Then everyone’s happy, aren’t they?

I see that @GreatJoy69 has already had a few private messages on Instagram. That was quick! I will take a look at them when I get back. How very exciting!

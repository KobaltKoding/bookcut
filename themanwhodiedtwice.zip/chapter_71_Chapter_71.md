## 71

Connie Johnson has changed three times already this morning. The summer dress was too obvious, the jumpsuit was not obvious enough, and the trousers she’d bought from Whistles were perfect, but she hadn’t been able to comfortably hide her gun in them.

In the end she had a brainwave, and she is dressed in her Lycra gym kit. This sent a number of messages. Firstly, ‘Oh, this meeting is not a big deal, I’m just fitting it in on the way to the gym,’ but, more importantly, ‘Here you go, Bogdan, this is what’s on offer,’ but in a healthy, rather than a slutty way.

And her gun is in a handy bumbag.

There is a large bag of MDMA on her desk, which she tidies into a drawer, before checking her watch. They are due any minute. Bogdan had slipped a letter under the lock-up door – a letter, swoon. He was bringing a man called Vic Vincent with him to discuss some sort of deal. Vincent being some major player in London.

She had googled ‘Vic Vincent’, of course, and nothing had come up, which was all the reassurance she needed. She was dealing with a pro.

There is a baseball bat covered with barbed wire leaning up against the photocopier, and Connie nudges it out of sight. She checks her hair once again. Perhaps Bogdan will be wearing a singlet? Those glorious arms rippling, ready to –

There is a loud bang on the metal door. Here we go, Connie. As she gets to the door she notices a large bloodstain under one of the coat hooks. Too late to clean it up now, they’ll just have to take her as they find her.

She opens the door, and in walk Bogdan and Vic Vincent. They shake hands. Bogdan is not wearing a singlet, but he is wearing sunglasses, so she still has plenty to work with. Vic Vincent looks familiar, but she can’t place him. Have their paths crossed before? He looks the part, face admirably busted, but his suit is a little too tight, and is that a West Ham United tie?

Nobody wants coffee – ‘You mustn’t drink coffee before the gym,’ Bogdan says, and, yes, of course, she should have thought of that. They sit.

‘I’ve heard good things about you, Connie,’ says Vic Vincent. ‘From Bogdan here.’

He’s heard good things from Bogdan. Bogdan has been talking about her. ‘I see, and does Bogdan work for you?’

Vic Vincent laughs. ‘Bogdan don’t work for no one. But now and again I ask him to help out. He gets a job done with no fuss. You understand?’

‘I understand,’ says Connie. She looks over at Bogdan, sitting there silent in his sunglasses like Mr Darcy. She just bets he gets a job done with no fuss.

‘I’ve got something you might be able to help me with. You interested in diamonds?’ asks Vic Vincent.

Where does she know him from?

‘Not really,’ says Connie. ‘I’m interested in money, though? If that’s involved too?’

Vic Vincent nods. Bogdan is looking around the room. She is glad she tidied away the bag of MDMA and the baseball bat. You can tell he likes tidy.

‘You ever dealt with the mafia?’ asks Vic.

The mafia? Well this is getting interesting.

Connie shakes her head. ‘I tried to cancel Sky Sports once, that’s the closest I’ve got.’

‘A gentleman is coming down to Fairhaven on Monday, he’s called Frank Andrade. I want someone to meet him. We’ve got a room on the end of the pier. Manager’s office.’

Connie nods, she knows the room well. She once threatened to burn down the arcade. Perhaps Bogdan will be at the meeting? What will she wear then? The mafia _and_ Bogdan?

‘I need someone I can trust, and Bogdan says that’s you, to give Mr Andrade these.’

Vic Vincent hands her a blue velvet bag. She opens the drawstring. Diamonds, he wasn’t kidding.

‘What are they worth?’ Connie asks.

‘Let’s just say they’re worth doing the job properly,’ says Vic Vincent. The buttons on his shirt are straining. That face is so familiar. What’s going on here?

‘And why can’t you hand them over yourself?’

‘We don’t get on, I killed his brother.’

Connie nods. ‘Been there. And why at the end of a pier?’

‘A lot of people want these diamonds. I can’t tell you why, but they do. We need somewhere we can keep an eye on everyone who’s coming or going.’

‘And what’s in it for me?’ asks Connie.

‘There’ll be another geezer there. Called Lomax. Andrade trusts him. Sells a lot of coke in south London and looking for a new wholesaler.’

‘What happened to his old wholesaler?’

‘Accident with a cement mixer,’ says Vic.

‘Clumsy,’ says Connie.

‘So I told him to check you out. Buy fifty grand’s worth from you, check the quality, see if you might be what he’s looking for.’

Connie nods.

‘And for that introduction, you hand over the diamonds to Andrade for me. Sound fair?’

Vic Vincent gives her a little smile. Connie knows this guy, she swears. Knows his face. Talk about too good to be true. Is this the copper, Chris Hudson, setting her up?

Connie fiddles with her bumbag for a moment, and then pulls out her gun. She points it straight at Vic Vincent. If that was really his name. Vic and Bogdan both raise their eyebrows a little.

‘Sorry, mate, no offence, but I know you. I’ve seen you before.’ Connie keeps the gun pointing straight between Vic Vincent’s eyes. Vic scratches a tattoo on his arm. It says ‘Kendrick’. Without taking her eyes off him, she addresses Bogdan. ‘Who is he, Bogdan? Just tell me. Just tell me, and you boys can walk out and we’ll say no more about it.’ Can she kill Vic Vincent and still go for a drink with Bogdan? She doubts it, but she’ll have a good go.

‘He’s Vic Vincent,’ says Bogdan. ‘I worked for him a few times, never any trouble.’

‘Keep going,’ says Connie. Vic Vincent looks cool as you like. But a bead of sweat drops down his neck, across a faded West Ham tattoo.

‘He called me, few weeks ago, says, “Bogdan, you know anyone I can trust?” I said Connie, because I trust you.’

God, this is hard, thinks Connie. But focus.

‘He asks if you deal coke, and I say of course, everybody does. So he tells me, buy coke from her, let me see.’

‘That ten grand the other day?’ asks Connie.

‘That was Vic’s money.’

Connie starts to laugh, she puts down the gun and gives Vic Vincent a hug. He is sweatier than she expects.

‘That’s where I know your face from! I’ve got someone who follows everyone when they leave here. Checks they’re not cops, rivals, whatever, takes photos. Bogdan took the coke to you, by the pier.’

Connie opens a drawer and flicks through some photos. She pulls out one of Ron and Bogdan by Fairhaven pier.

‘Dressed as a plumber, I like it. I knew I knew your face. Sorry, Mr Vincent, I didn’t mean to point a gun at you.’

‘No problem,’ says Vic Vincent, and scratches his Kendrick tattoo again. ‘And bring that gun with you on Monday. Just in case.’

‘So, I’m in,’ says Connie. ‘Fifty grand of coke, and the diamonds.’

‘Monday, three p.m.,’ says Vic Vincent.

Connie looks at Bogdan. ‘And will you be there?’

Bogdan takes off his sunglasses and looks straight at her. ‘Yes, we can do it together.’

Jesus Christ, that was an intense look. ‘Maybe we could all go for a drink?’

‘You are going to the gym,’ says Bogdan, putting his sunglasses back on.

Damn!

‘I need one more favour, Connie,’ says Vic Vincent. ‘If you don’t mind. Nothing difficult.’

‘Go on,’ says Connie.

‘My wife’s niece lives down here, and she’s got a boy looking for an opportunity. Just thinking you might need a driver on the day, wondered if you’d give him a chance?’

‘I’ve got a driver,’ says Connie.

‘I’d rather have someone I know I could trust too,’ says Vic Vincent. ‘Family. He’s done a bit of work for you before, the way he tells it. He can drive the three of us to dinner afterwards, if you fancy?’

Connie does fancy.

‘Sure, what’s his name?’

‘Ryan Baird,’ says Vic Vincent, and slips a piece of paper over to Connie. ‘He’s up in Scotland at the moment; that’s the address. You think you could send someone up to bring him down for Monday?’

‘Of course,’ nods Connie, thinking about where to go for dinner.

Monday on the pier was going to be a lot of fun.

## 81

Bogdan stares at the chess board, but it makes no sense. He has just made a fatal error, and he never makes fatal errors.

Stephen’s lips are pursed. He has spotted the mistake. He looks up at Bogdan.

‘Goodness,’ he says. ‘Quite unlike you, quite unlike you.’

Stephen moves his bishop to capitalize on the error. Bogdan is doomed. He looks down at the board again, but the pieces start dancing, they won’t behave. He tries to blink it all away. Get everything back in its place. Everything in order.

‘Something on your mind?’ asks Stephen.

‘Nothing,’ says Bogdan. Which is usually true. But not today.

‘If you say so, then who am I to question?’ says Stephen. ‘You killed someone else, perhaps?’

Bogdan looks at the board. Looks at the pieces. He can’t see a way out. Stephen was going to win.

‘You love Elizabeth?’ says Bogdan.

‘Too small a word, that,’ says Stephen. ‘But yes. Where is she, by the way? She did tell me.’

‘Antwerp,’ says Bogdan.

‘Sounds like her,’ says Stephen. ‘Go on.’

‘When did you know you loved her?’ asks Bogdan. ‘Like, ages?’

‘Twenty seconds perhaps,’ says Stephen. ‘I recognized her the moment I met her. I just thought, Well, there you are, I’ve been waiting for you.’

Bogdan nods.

‘Do you have a little crush on someone?’ asks Stephen. ‘Is that it? You can resign the game if you want, by the way. No coming back now, surely?’

Bogdan looks at the board. Perhaps there is no way back? But he won’t resign just yet.

‘How do you know if someone likes you?’ asks Bogdan.

‘Well, everyone likes you, Bogdan,’ says Stephen. ‘But I imagine you mean romantically?’

Bogdan nods, and looks down at the board again, desperately searching for a way out.

‘A boy or a girl?’ asks Stephen. ‘I’ve never liked to ask.’

‘A girl,’ says Bogdan.

‘Well, then I owe Elizabeth twenty pounds,’ says Stephen. ‘The best thing to do is just ask. How about a drink? If she says yes, then there’s the answer.’

‘But what if she says no?’

‘Then she says no, dust yourself down, plenty more eggs in the omelette and so on.’

Bogdan thinks back to the parapet of the bridge. The rocks and the river below. The yellow jumper his mum had knitted. He looks down at the board and shakes his head. Sometimes the pieces weren’t where they were supposed to be. Sometimes you weren’t in control. And perhaps that was OK? He will ask her for a drink, and if she says no, she says no.

Bogdan holds his hand out to Stephen.

‘I resign.’

‘Good lad,’ says Stephen. ‘Who is she?’

‘She’s called Donna,’ says Bogdan. ‘Police officer.’

‘Just what you need,’ says Stephen. ‘Keep you on the straight and narrow. Just ask her for a drink, you ridiculous man.’

Bogdan hears the front door open. Elizabeth is back. She walks in with a bag full of files.

‘Hello, darling,’ says Stephen. ‘Where have you been?’

‘Antwerp, darling,’ says Elizabeth, and kisses him on the top of the head.

‘Sounds like you,’ says Stephen.

‘You boys having fun?’

‘Bogdan was asking when I knew I was in love with you.’

‘Oh, really. And when was it?’

‘The jury’s still out, I told him. Giving her the benefit of the doubt for now.’

‘And how did the subject of love come up?’

‘Darling, Bogdan and I must have our secrets, mustn’t we?’

‘You must,’ agrees Elizabeth.

Bogdan looks at the paperwork poking out of Elizabeth’s bag. ‘How was Antwerp? Everything good?’

‘Everything good, yes,’ says Elizabeth. ‘All taken care of.’

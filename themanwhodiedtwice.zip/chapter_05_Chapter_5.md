## 5

Ibrahim has just finished lunch with Ron. He had tried to persuade Ron to try hummus, but Ron was intractable. Ron would eat ham, eggs and chips every day if you let him. And to be fair, he was seventy-five and still going strong, so who’s to say he was wrong? Ibrahim pulls the car door shut and buckles his seatbelt.

Ron had been excited because his grandson, Kendrick, is coming to stay next week, and Ibrahim is excited too.

Ibrahim would have made a wonderful father, a wonderful grandfather, too. But it wasn’t to be, like so much else in his life. You silly old man, he thinks, as he turns the key in the ignition, you made the biggest mistake of them all. You forgot to live, you just hid away, safe and sound.

What good has it done him, though? Those decisions he had been too cautious to make? The loves he had been too timid to pursue? Ibrahim thinks of the many lives he has missed, somewhere along the way.

Ibrahim has always been good at ‘thinking things through’, but, now, he is choosing to take the proverbial bull by the horns. He has decided to live in the moment a little more. He is choosing to learn a lesson from Ron’s chaotic freedom, from Joyce’s joyful optimism and from the forensic wrecking ball that is Elizabeth.

_Don’t buy a dog, Joyce_. That’s what he had said. But of course she should. He will tell her when he gets back. Will she let him walk it? Surely she will. Terrific cardiovascular exercise. Everyone should buy dogs. Men should marry the women they loved, and not run away to England in fear. Ibrahim has had a lifetime to think about that decision. Has never even discussed it with his friends. Perhaps one day he should?

He turns left out of the gate of Coopers Chase. After checking, and then checking again, naturally.

There is a whole world out here, and, however frightened it makes him feel, he has decided he needs to get out of Coopers Chase every now and again. So here he is, out among the noise and the traffic and the people.

He has decided, once a week, to take Ron’s Daihatsu out for a spin and visit Fairhaven. He passes the town sign. It is quite a buzz. Just him, by himself. He’s going to do a bit of shopping, sit in a Starbucks with a coffee and read the paper. And while he’s here, he’s going to look and listen. What are people saying these days? Do they look unhappy?

Ibrahim is anxious that he won’t be able to find anywhere to park, but he finds a space easily. He worries that he won’t be able to work out how to pay for the parking, but that is a cinch too.

What sort of psychiatrist is frightened of life? All psychiatrists he supposes, I mean, that’s why they became psychiatrists. Even so, it wouldn’t do any harm to let the world in. A mind could calcify at Coopers Chase, if you let it. The same people, the same conversations, the same grumbles and gripes. Investigating the murders has done Ibrahim a world of good.

He quickly discovers both self-service checkouts and contactless payments. The absolute minimum of human interaction. You don’t have to nod hello to someone you have never met. To think he might have missed out on all this!

He finds a lovely independent bookshop where no one minds if you sit in an armchair and read for an hour. Of course, he buys the book he has been reading. It is called _You_, and is about a psychopath called Joe, for whom Ibrahim has a great deal of sympathy. He buys three other books too, because he wants the bookshop still to be here when he comes back next week. There was a sign behind the till saying ‘Your Local Bookshop – Use It Or Lose It’.

_Use It Or Lose It_. That was quite right. That is why he is here. Out in the noise, with cars speeding by, with teenagers shouting and builders swearing. He feels good. He feels less frightened. His brain feels alive. Use it or lose it.

He looks at his watch. Three hours have gone by in a rush and it is time to head home, his head full of adventure. After telling Joyce that she should get a dog, he will tell her all about contactless payments. She will know about them already, but perhaps she won’t have looked into the technology behind them, which he just has. Time flies when you are living it.

He has parked Ron’s Daihatsu near Fairhaven Police Station, because surely that’s the safest place to park. Perhaps one week he will pop in and see Chris and Donna. Are you allowed to visit police officers at work? He is sure they would be delighted to see him, but he wouldn’t want to hold up, say, an arson investigation while they felt they had to make small talk. But those worries were old Ibrahim. New Ibrahim would just take the chance. You want to see someone? Just go and see them. That’s what Ron would do. Though Ron would also go to the bathroom and leave the door open, so Ibrahim must remember there are limits.

He passes three teenagers on a corner near the police station, all on bikes, and all three with hoods up. He smells cannabis. A lot of people at Coopers Chase smoke cannabis. Supposedly to relieve glaucoma, but statistically not that many people can have glaucoma, surely? As a young man, Ibrahim had been persuaded by some of his richer friends to smoke opium. He had been too much of a coward ever to try it again, but perhaps that was another thing he should put on his list? He wonders where you can buy opium. Chris and Donna would know. It was very useful, knowing police officers.

These three youths are exactly the sort of people that Ibrahim should be scared of, he knows that. But they don’t frighten him at all. Young men had always hung around on street corners on bicycles, and they always would. In Fairhaven, in London, in Cairo.

Ibrahim sees the Daihatsu up ahead. He will take it through the car wash on the way back. Firstly, to say thank you to Ron, but also because he likes car washes. He takes out his phone. This was the first thing he learned today. You can pay for your parking on a mobile phone app, which is short for application. Perhaps it’s OK that everyone is looking at their phones? Perhaps if you have the entire history of human knowledge and achievement in your pocket it’s OK to spend your time looking at –

Ibrahim doesn’t hear the bicycle approach, but he feels it rushing past him, sees the hand grabbing his phone, ripping it from his grasp with a jerk that sends him tumbling to the ground.

Ibrahim lands on his side and rolls until he hits the kerb. The pain is immediate, in his arm, in his ribs. His jacket sleeve is torn. Will he be able to get it mended? He hopes so – it is a favourite jacket, but the rip looks bad, the white lining shining through like bone. He hears footsteps, running, and teenage laughter. As the footsteps reach him, he feels two kicks. One in the back and one to the back of the head. His head hits the kerb once more.

‘Ryan, come on!’

This is very bad, Ibrahim understands that. Something serious has happened. He wants to move, but he is unable to. The damp of the gutter is seeping through the wool of his trousers, and he tastes blood.

There are more footsteps running, but Ibrahim has no way of protecting himself. He feels the cold of the kerb against his face. The footsteps stop, but no kick this time, instead he feels hands on shoulders.

‘Mate? Mate? Jesus! Christine, call an ambulance.’

Yes, the adventure always ends with an ambulance, it doesn’t matter who you are. What was the damage here? Just broken bones? Bad enough at his age. Or worse? He had taken a kick to the back of the head. Whatever happened next he knew one thing was certain. He had made a mistake. He should have stayed safe. So now there will be no more trips to Fairhaven, no more sitting in the armchair in the bookshop. Where were his new books? In the street, getting wet? He is being shaken.

‘Mate, open your eyes, stay awake!’

But my eyes are open, thinks Ibrahim, before realizing they are not.

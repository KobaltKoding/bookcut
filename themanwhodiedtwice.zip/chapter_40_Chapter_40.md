## 40

Lance James yawns and scratches. To Sue Reardon, in her office, door open, it will look like he is working. Checking intelligence reports, cross-referencing aircraft manifests? The sort of thing they pay him to do. When he was in the Special Boat Service, life was more exciting. But he was also shot at more often, and these days he doesn’t really have the knees to be shot at every five minutes.

Lance is online, looking at houses he can’t afford. A country house in Wiltshire? Don’t mind if I do. You could convert that stable block into a games room. A penthouse apartment overlooking the Thames? Great views, but look at the floor plan. Where would you put the private cinema?

He is daydreaming. Unless. Unless.

The twenty million would change the picture, wouldn’t it? And it’s out there.

Lance supposes that even people with twenty million pounds in their hands still look at houses they’ll never be able to afford. A hollowed-out volcano, maybe. No one ever buys a house without secretly wanting one ten per cent more expensive.

Money is a trap, for sure. But, to Lance’s mind, there are worse traps you could find yourself in.

He looks over and sees Sue Reardon through her open door. She’s engrossed in something. Working? He doubts it. Who starts working before eleven these days?

She is frowning at her screen. Does she know something? Is she in there, cracking the case?

More likely she’ll be ordering shrubs, or arranging care for an elderly relative, or watching pornography. Nothing about anyone ever surprised Lance any more. Twenty years working with the security services and he has seen it all. Those two women in their seventies? What was the story there? The smaller one, the less scary one, had kept looking at him as if she had something to say. The other one, Elizabeth Best – Sue seemed respectful and wary around her. Was there some history?

Lances glances up at Sue again. She seems deep in thought. Though she’s probably just looking at that same house in Wiltshire and working out what she’d do with the stable block. Thinking about the twenty million.

Lance currently lives in a one-bedroom flat in Balham. There is an argument with his ex about buying her half of the property. He can’t afford to buy her out, he can’t afford to move, and she doesn’t much care. He was a poor boy who bought a flat with a rich girl, which was romantic and hopeful at first, but is less fun now their only contact is letters from her dad’s solicitor. For now he is paying rent to her. That’s the temporary compromise. Paying rent he can’t afford to someone who doesn’t need the money. To someone who, until six months ago, would tell him every day how much she loved him. Not so much of that in the solicitor’s letters. No arm across his chest and sleepy morning kisses from Roebuck Harrington & Lowe.

Had she fallen out of love with him, or had she never been in love? Either way she had slept with their builder, and was now dating an investment banker called Massimo.

Lance’s mum had loved her. Everybody loved her. And so now Lance doesn’t see his mum so much either. He bets they’re still in touch.

Balham was, at least, handy for Millbank, where Lance usually works. But it definitely wasn’t handy for this ridiculous set-up in Godalming where he was seconded until this investigation was over. It was all well and good to be investigating two assassinations. But not if you have to stand all the way on the 8.21 train from Waterloo to Godalming in order to do it.

And, to top it all, he is losing his hair. The superpower that had served him so well over the years, the hair that would dance over his eyes, that he would effortlessly run his hand through on dates, knowing that wherever it sprang back to it would look great. It was on its way out. It was thinning, it was greying, it was receding. Just when he was single again.

Sometimes, when they let Lance have a gun, he thinks about just shooting himself in the head.

He should probably do some work.

Lance shuts down the Rightmove property page and opens his emails. He has worked for both MI5 and 6, so he gets all sorts of rubbish. The emails were always a mix of security briefings and the results of the in-house bake-off competition held by the China desk.

Sue has emailed him. She’s ten feet away, through an open door, but OK. Can he check on the credentials of Doctor Carter from the mortuary the other night? Send her a report? Of course. Sue is stressed, he can see that. She is under pressure to get this whole mess cleared up.

Grey men have been ghosting in and out of her office for the last few days. About the same age as Sue, he guessed, early sixties perhaps, but more male and more senior. That was still the way it went, despite what all the glossy brochures told you. Lance is aware that he is about as unsuccessful as it is possible for a forty-two-year-old man to be in MI5\. But there was time to change that, and he should probably start now.

After reading that the competition to name the MI6 canteen has been won by Priya Ghelani from counter-terrorism, with the entry ‘Would You Like Spies With That?’, he sees an alert about a flight from Teterboro Airport in New Jersey. Lance clicks it open.

Sue Reardon’s reputation was high. If there was trouble, she found it, and then she would find the troublemakers making that trouble. She was hard, she could be brutal, that was what the job did to you. But this investigation had been a disaster. Two operatives shot dead in a safe house? Including the chief suspect in the original investigation? No doubt that’s why so many grey-haired men were in and out of Sue’s office.

A flight has been flagged. On the passenger list is the name Andre Richardson. The flight, on a Gulfstream G65R, takes off from Teterboro and is due to land at Farnborough Airfield on the morning of Monday the eight.

Lance closes the email, walks over to Sue’s door and knocks. She looks up and closes whatever it was she’d been looking at. ASOS? Paintings of horses?

‘Lance?’

‘Flight leaving New Jersey on Sunday week. Under the name “Andre Richardson”, a known alias of Frank Andrade Jr. Landing at Farnborough, not a million miles from here, not a million miles from Martin Lomax’s home.’

‘So the man whose diamonds have been stolen is visiting the man they were stolen from?’

‘Mmm,’ agrees Lance. He is wondering if Priya Ghelani is still single. He has to get back out there, hair or no hair. ‘Perhaps I should join the surveillance team for the next week, ma’am? Make sure we don’t miss a trick?’

‘Good idea, Lance. They’re stationed up in Andover. You OK to stay up there?’

A whole week away from the Balham flat. A week away from the commute, and from this office. Maybe some glory and some diamonds at the end of it?

‘Yes, ma’am,’ says Lance, then raises his hand to push it through his hair, before thinking better of it.

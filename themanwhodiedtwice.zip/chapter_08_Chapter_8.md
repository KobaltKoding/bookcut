## 8

Joyce is holding Ibrahim’s left hand. She squeezes it as he talks. Elizabeth is holding the other hand. Ron has propped himself against the far wall, putting as much distance as possible between him and his friend in the bed. But Ron has tears in his eyes, and Joyce has never seen that before, so he can stand where he wants.

Ibrahim has tubes in his nose, heavy bandages around his torso, a neck brace and a drip in his arm. He is entirely drained of colour. He looks broken. He looks frightened. He looks, Joyce realizes, old.

But he is conscious; he is sitting, propped up, and he is talking. Slowly and quietly, and clearly in pain, but talking.

Joyce leans in to catch what Ibrahim is saying.

‘You can pay for the parking on your phone, you see. It’s very convenient.’

‘Whatever next?’ asks Joyce, and squeezes his hand again.

‘Ibrahim?’ says Elizabeth, her voice as gentle as Joyce has ever heard it. ‘With respect, we don’t want to hear about the parking. We want to know who did this.’

Ibrahim nods as best he can and takes a shallow breath against the pain. He releases his hand from Elizabeth’s grasp and tries to raise a finger but gives up. ‘OK, but the app is really very clever. You just –’

The door flies open and Chris and Donna rush in, and make straight for the bed.

‘Ibrahim!’ cries Donna.

Joyce lets Donna take Ibrahim’s hand. They’ve all had a turn. Chris walks over to the other side of the bed and taps the headboard. He looks down at Ibrahim and attempts a smile.

‘You had us worried there for a moment.’

Ibrahim gives Chris a weak thumbs-up.

‘We should see the other guy, right?’ says Donna.

‘You should catch the other guy, certainly,’ says Elizabeth.

‘Yes, forgive us, Elizabeth,’ says Chris. ‘We haven’t managed to crack the case in the nine seconds we’ve been in the room.’

‘Don’t row,’ says Joyce. ‘Not in a hospital.’

‘Can you speak, Ibrahim?’ asks Donna, and Ibrahim nods. ‘Whoever did this, we’ll find them, and we’ll get them in a room with the cameras off and they’ll regret it.’

‘That’s my girl,’ says Elizabeth. ‘That’s a proper police officer.’

‘Hundred yards from your station,’ says Ron, jabbing a finger at Chris. ‘That’s what it’s come to. While you’re off arresting someone for putting the recycling in the wrong bin.’

‘All right, Ron,’ says Joyce.

‘I was at the gym,’ says Chris.

‘Well, that says it all,’ says Ron.

‘It doesn’t say anything, Ron,’ says Elizabeth. ‘So be quiet and let Chris and Donna do their job.’

Chris nods to Elizabeth, then perches on the bed and looks at Ibrahim. ‘Mate, if there’s anything you remember, anything at all, then it all helps us. I know it must have been a blur, but even a small detail.’

‘Only if you can,’ says Joyce.

Ibrahim nods again and begins to speak, slowly, with the occasional pause when the pain gets too much.

‘I don’t remember much, Chris. You know I’m normally good with details.’

‘Of course, mate, that’s fine. Just anything.’

‘There were three of them. Two white, one Asian – Bangladeshi, I would say.’

‘That’s great, Ibrahim,’ says Chris. ‘Anything else?’

‘All on bikes. One of the bicycles was a Carrera Vulcan, one was a Norco Storm 4, and I’m afraid I’m not quite certain of the make of the third, but probably a Voodoo Bantu.’

‘Right …’ says Chris.

‘All three wore hooded garments, one a burgundy Nike top with a white drawstring, and the other two in black Adidas. Their trainers were white Reebok, white Adidas, and I have forgotten the third.’ Ibrahim looks to Chris in apology.

‘Yes, I see,’ says Chris.

‘I do remember that one of the white boys had a watch with a beige strap and a blue face, and the other white boy had a tattoo of three stars on his left hand. The Bangladeshi boy had acne scars down the right side of his face. One of the other boys had a shaving rash, but that is moot, as I don’t imagine it will last longer than a day. One had a rip in his jeans, and on his thigh you could see the bottom of a tattoo, which looked to me like a football crest, Brighton and Hove Albion, I think, and I could make out the letters “r-e-v-e-r” which I took to be the end of the word “forever”, but of course I couldn’t swear to it. That’s all I remember, I’m afraid. It’s a bit of a haze.’

Joyce smiles. That’s her Ibrahim.

‘I mean, I’ll be honest,’ says Chris, ‘that was more than I expected. We’ll find them on CCTV somewhere, and then we’ll find those bikes. We’ll get them for you.’

‘Thank you,’ says Ibrahim. ‘And also, I know the first name of the one who attacked me, if that helps?’

‘You know his name?’

‘As I was lying there, they shouted, “Ryan, come on!”’

‘Come on, Ryan?’ says Donna.

‘There’s your man,’ says Ron. ‘Right there. Stop pillocking around and go and arrest Ryan.’

‘If I arrested every Ryan with a criminal record in Fairhaven, we’d need more cells,’ says Chris.

A nurse walks in and Joyce recognizes the look on her face. Joyce stands.

‘Time to go, everyone, let the nurses get on with their jobs.’

Ibrahim gets gentle hugs and kisses from everyone in turn, and they start to file out. Only Ron remains.

‘Come on, Ron,’ says Joyce. ‘Let’s get you home.’

Ron shuffles from foot to foot.

‘Um, I’m staying.’

‘You’re staying here?’

‘Yeah, I just … Well, they’re going to make me up a camp bed, and they said I could stay.’ Ron shrugs; he looks a little awkward. ‘Keep him company. Got my iPad, might watch a film.’

‘There is a Korean film I have been looking forward to,’ says Ibrahim.

‘Not that,’ says Ron.

Joyce walks over to Ron and gives him a hug, feeling his embarrassment as she does. ‘You look after our boy.’ Joyce then walks out of the door, letting it close behind her, and sees Chris and Donna in conference with Elizabeth.

‘The phone was just snatched, so there’ll be no forensics,’ says Chris, ‘and from what I’ve heard we don’t have witnesses. There’s no CCTV there either, they’ll have known that. We can find them for sure, with Ibrahim’s description, but they’ll laugh in our faces in an interview.’

‘And off they’ll trot, to do the same thing to someone else,’ says Donna.

‘You’re going to let them get away with this?’ says Elizabeth. ‘After doing that to Ibrahim?’

Chris looks around him, just to make sure he’s among friends. ‘Of course we’re not going to let them get away with it.’

‘Oh, good,’ says Joyce.

‘We’ll bring them in, I promise you that. We’ll waste a bit of their time. But other than that, there’s nothing me and Donna can do.’

Elizabeth looks at him. ‘Donna and I, Chris. How many times are we going to go through this?’

Chris ignores her. ‘But I know you well enough to reckon there’s probably something you could do, Elizabeth? You and Joyce and Ron?’

‘Go on,’ says Elizabeth. ‘I’m listening.’

Chris turns to Donna. ‘Who did it sound like Ibrahim was describing, Donna? From the name, to the clothes, right down to the tattoo.’

‘It sounded like Ryan Baird to me, sir.’

Chris nods, and turns to face Elizabeth. ‘It sounded like Ryan Baird to me, too.’

‘Ryan Baird,’ says Elizabeth. A statement, not a question. Locked into the vault, never to escape.

‘So we’ll nip off now and arrest him, and question him, and get a string of “no comments”, and then we’ll have to let him go, a little smirk on his face, knowing he’s got away with it again.’

‘Oh, he hasn’t got away with it this time,’ says Elizabeth. ‘No one gets away with hurting Ibrahim.’

‘I was hoping you’d say that,’ says Chris. ‘You know how much the four of you mean to us, don’t you?’

‘I do,’ says Elizabeth. ‘And I hope you both know the same.’

‘We do,’ says Donna. ‘Now let’s go and arrest Ryan Baird, and may God have mercy on his soul.’

‘I don’t think even God will be able to help him,’ says Joyce, as she sees a hospital porter wheeling a camp bed into Ibrahim’s room.

## 84

Sylvia Finch slips off her suede shoes, still dark from the puddles, and pulls her chair up to the empty desk.

She comes in for two days a week, and has done for around ten years now. Ever since she retired.

She has the odd week off, usually when the kids and grandkids come to visit. She doesn’t have her own desk, they just put her wherever they have space. Space is tight, and money is tight, and Sylvia is glad to just muck in. Glad to help the people who helped her.

Wherever they put her, she takes out the picture of Dennis and props it against her computer. To remind her why she’s there.

She logs into the online banking system. Today is just cross-checking the accounts. Making sure monies paid in have arrived, and making sure nothing unauthorized has gone out. There is usually the odd anomaly, a promised transfer which hasn’t gone through, or a staff member buying lunch on the wrong credit card. Never anything really sinister, but always best to check.

Today, however, as Sylvia clicks onto the main holding account, she spots an immediate error. The error is amusing, more than anything else, the sort of thing that, in happier days, she would tell Dennis about when she got home.

Sylvia rings the bank and gives her details. She runs through the error she has spotted, but is assured that it is not an error. Which is impossible. She asks the lady on the other end, Lisa, very friendly, to double-check, which she does. No error. So she asks for a few more details.

Sylvia thanks Lisa and puts down the phone.

The bigwigs are all in a meeting. Eight of them around a table that is far too small. The bottom half of the glass meeting-room wall is frosted, but in the clear pane above she can see the tops of people’s heads and, cramped into a corner, the chief executive standing by a flip chart, pointing out figures.

Sylvia has never interrupted a meeting before, would never dream of it, in fact. She has never liked to draw attention to herself, and she has always been glad that accountants very rarely need to interrupt meetings. But in this instance she probably should.

She checks and double-checks the screen. Then checks and double-checks the information she has written down. She takes a final look at the photograph of Dennis. Her husband, her love. Gone to dementia, then gone for ever. The man who died twice. Courage, Sylvia, Dennis is with you.

As she walks over to the meeting-room door, she hears the noise of the discussion, and begins to feel awkward. She pauses for a moment outside the door. What will she look like when she walks in? A silly, thin old woman? Sylvia, who says good morning, puts the picture of her husband on her desk, then doesn’t speak again until she says good evening? Sylvia, who silently holds up his flask every time someone offers her a cup of tea? Sylvia, who doesn’t know which jumper goes with which skirt? Well, she supposes she can’t change who she is, and this is important. Sylvia knocks.

There is a slight pause, then, ‘Yes, come in.’

Sylvia pushes open the door, and the faces around the table and the face at the flip chart all turn towards her. She feels giddy. The flip chart is branded with the logo of the charity. ‘Living With Dementia – Living With Love’. They had done all they could for her and Dennis, and she gives everything she can to them in return. She has no money to give, and so she gives her time. She sees they are waiting for her to speak. So here goes nothing.

‘I’m ever so sorry to interrupt,’ she says. ‘But I don’t suppose anyone here knows anything about twenty million pounds from Antwerp?’

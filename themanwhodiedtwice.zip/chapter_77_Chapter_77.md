## 77

Now it is Elizabeth who is staring down the barrel of Sue Reardon’s gun. How many gun barrels had she stared down in her career? Twenty? Thirty? None of them had killed her yet.

The basic rule is, if they don’t kill you immediately, they’re not going to kill you. There are always exceptions, but no point worrying about them for now.

The coroner’s van is heading towards Coopers Chase. How had Siobhan found the diamonds at Joyce’s? Someone had told her exactly where they were. Ibrahim? Stephen? Been _forced_ to tell her? Please no. She has to keep calm.

‘Can I tell you what I think happened?’ asks Elizabeth. ‘Just to pass the time. Or is that all a bit “James Bond” for you?’

‘Please do,’ says Sue. ‘I can’t tell you how delighted I was to fool you.’

‘Poppy found the letter,’ Elizabeth begins. ‘Just as Joyce said. But she didn’t go after the diamonds, and she didn’t give it to her mum. She gave it to you, because that’s what Poppy would do. She did her job. So you read the letter, you read Douglas’s confession. But the confession part wasn’t news to you, you’d known all along. You and Douglas had planned the whole thing together. Yes?’

‘A little retirement plan, yes,’ agrees Sue.

‘I had a brief, awful thought at one point that Douglas and Poppy were lovers,’ says Elizabeth. ‘But I was wrong, wasn’t I? You and Douglas were lovers.’

‘Ooh, yes,’ says Joyce. ‘I can see that.’

‘Have I got that right?’ asks Elizabeth.

‘You have,’ says Sue.

Joyce looks between the two of them. ‘He definitely had a type, didn’t he?’

‘I see the appeal, I promise,’ says Elizabeth. ‘I was almost ten years older than him, you ten years younger. He very neatly spanned our generations, didn’t he?’

‘He was very handsome,’ says Joyce. ‘Not my type at all, no offence to either of you, but very handsome.’

Elizabeth looks straight into Sue’s eyes. ‘So you were reading the letter, saw the key, the locker number and what have you. I assume he hadn’t told you where he’d hidden them?’

‘He told me they were safe,’ says Sue.

Elizabeth nods. ‘So, it was interesting information to you. Lucrative at the very least. But the big news came further down in the letter, didn’t it? When he said he still loved me? That he would wait for me if needs be. That must have been the moment you realized the two of you weren’t in this together? That you and Douglas weren’t about to head off into the sunset with the twenty million? That was the moment you realized you would have to kill him?’

Sue shrugs. The barrel of the gun shrugs with her.

‘He wanted it all for himself,’ says Elizabeth. ‘Or worse, he wanted it for him and me. Though you’re bright enough to know that would never happen. Originally the two of you were just going to see out the investigation, let it fizzle down to nothing and cash in. So now you needed a change of plan.’

‘Perfect so far,’ says Sue. ‘Too late, of course, but perfect.’

‘So you decide you want the money for yourself,’ says Elizabeth.

‘I don’t blame you one bit,’ says Joyce.

Joyce is still doing her word search. You had to hand it to Joyce sometimes. Even with a gun pointed at her best friend, Joyce trusts her to get out of this situation. Does Elizabeth trust herself? That’s a very good question. What is going to face them back at Coopers Chase? Is Stephen safe? Is Ibrahim safe?

Elizabeth keeps thinking as she talks. ‘So how to kill him? Well, first attempt, you tell Martin Lomax where Douglas is, which is as good as signing Douglas’s death warrant. Cowardly, but you need him out of the way if you’re going to escape with the money yourself, and you’re angry. Lomax sends his man, Andrew Hastings, to kill Douglas, but poor Poppy gets in the way and shoots Hastings. Douglas very much still alive, a bump in the road, but never mind. You are still determined, and that’s understandable. We all fall out of love, don’t we?’

‘We most certainly do,’ says Sue.

‘Not me,’ says Joyce.

‘Nonsense, Joyce, you’re in and out of love monthly,’ says Elizabeth, then returns to staring into Sue Reardon’s gun. ‘So you still need Douglas out of the picture, and you realize you are going to have to do it yourself. You know you can move Douglas and Poppy to Hove. To a house you have used before, a house you can access easily. So killing him yourself will be easy. But how to get away with it? That was your question.’

‘It was,’ agrees Sue Reardon. ‘I didn’t need to get away with it for long. Just until I found the diamonds.’

‘And perhaps,’ says Elizabeth, ‘you were worried that I might work things out?’

‘I was,’ says Sue. ‘I just needed you to find the diamonds before you worked out I was the killer. And you didn’t let me down.’

‘She worked it out eventually, to be fair,’ says Joyce.

‘But I still get to the diamonds,’ says Sue. ‘As soon as I’ve picked them up, I’ll be off. I can disappear easily, Elizabeth, as you’ll know. So that’s what I’ll do. Feel free to tell everyone what I did. They won’t find me.’

‘You’re not going to shoot us?’ says Joyce.

‘Not if you behave yourselves,’ says Sue.

‘Not really our speciality,’ says Joyce.

‘I knew you wouldn’t be able to resist a clever little mystery, Elizabeth,’ says Sue. ‘I knew I’d have you chasing your tail. You were having lunch with the killer, talking tactics, without even knowing. Isn’t that a hoot?’

Elizabeth nods. ‘Your plan forms, and you realize you are going to need help with it. So you call Siobhan. Now this is where I’m hazy. Who exactly is she? An old friend, I imagine? An old colleague who owed you a favour?’

‘Guess again,’ says Sue Reardon.

‘No matter,’ says Elizabeth. ‘She agrees to whatever terms you present her with. Help me with a double murder and … what?’

‘A million pounds,’ says Sue Reardon.

‘That would do it,’ says Elizabeth. ‘You come to Coopers Chase to take Andrew Hastings’s body away, and on your way out you slip a note into Joyce’s cardigan, simply saying “RING MY MUM”, with Siobhan’s phone number.’

‘Wait,’ says Joyce, ‘Siobhan isn’t Poppy’s mum?’

‘Keep up, Joyce,’ says Sue.

‘Don’t speak to Joyce like that,’ says Elizabeth.

‘Oh, I don’t mind,’ says Joyce.

Elizabeth feels the coroner’s van take a sharp left turn and slow down. It crosses a cattle grid. They are at Coopers Chase.

‘You send Siobhan to check the lockers for the diamonds. You’d been in before, I presume, to make sure there were security cameras?’

‘I had,’ says Sue.

‘Trusting that I would eventually check the recordings. And be led to Siobhan. And put two and two together?’

‘Which you were, and which you did,’ says Sue. ‘I knew you wouldn’t be able to resist it! The idea of Poppy faking the whole thing. So unlikely. I knew you were just clever enough to fall for it.’

Sirens go past them at speed. Sue pauses, then visibly relaxes. Ambulances, not police. Elizabeth goes cold. Driving at speed from Coopers Chase. Who was in the ambulances? Stephen?

‘You even thought Douglas had faked it at first, didn’t you?’ laughs Sue. ‘That was a delightful surprise. Not my plan at all, but I was happy enough to go along with you for a few days. You were my useful idiot, Elizabeth, if you don’t mind me saying?’

Elizabeth tries to take her mind off the ambulances, their sirens now faint in the distance. ‘Siobhan comes back to you, empty-handed. The next day you enter the safe house on St Albans Avenue. You shoot Poppy first, I’m guessing?’

‘Correct,’ says Sue. ‘A shame, but needs must sometimes. She’d seen the letter.’

‘And helpful in encouraging Douglas to let you know where the diamonds were? What did he tell you? Before you shot him? He obviously didn’t let on?’

‘He just said, “Stick close to Elizabeth, she’ll find them.” I thought that sounded true enough, and the best I was going to get, so I shot him.’

‘And you did stick close to me, I’ll give you that.’

‘And you did find them. So thank you,’ says Sue. ‘As I say, a useful idiot. I’ll be out of your hair very soon, I promise.’

The van pulls to a halt. Sue puts her gun hand into her handbag, but keeps the gun pointing at Elizabeth. The driver opens the back doors.

‘After you, ladies,’ says Sue, and the driver helps Elizabeth and Joyce climb down. Sue follows, needing no help.

‘We won’t be long,’ says Sue to the driver. ‘Just need to spend a penny.’

It is 5 p.m. The sky is darkening, and lights are coming on across Coopers Chase. The normal business of a normal day. Quizzes on the TV, books being read, grandchildren on the phone, a few tardy birds flying to their roosts. Elizabeth sees Colin Clemence taking in a garden chair from his patio. Miranda Scott from Wordsworth Court is posting a letter. She enters competitions, and last year won a lifetime’s supply of washing powder. Persil must have rubbed their hands with glee when they discovered she was ninety-two.

All is quiet in this happy place. Another day done, family safe and sound, curtains closed and heating on. Nothing you’ll ever see on the news, but something you should really pay more attention to, just the gentle hum of contentment.

Take a look out of the window, and there is nothing to see except two old women taking an evening stroll together. It’s Joyce and Elizabeth, isn’t it? Thick as thieves, those two. There is a younger woman walking a few steps behind. Heading over to Joyce’s, I think.

‘As soon as the shooting on the pier had finished, I was on the phone,’ says Sue. ‘Three men Martin Lomax put me in touch with a while ago. Men who could do a few jobs off the books. Ex-special forces, armed to the teeth. They were standing by, so I sent them straight here with Siobhan. I knew someone would know where the diamonds were. Your friend with the broken ribs, or that husband of yours, Elizabeth. Though from what I read you could tell him anything and he wouldn’t remember. Poor thing.’ She sees Elizabeth stiffen in front of her and she smiles.

‘My God, this was harder than it was supposed to be. “The perfect crime,” Douglas had said to me. No victims. How many deaths now? Five? Although we all heard the ambulances, so who knows? Maybe a couple more.’

Elizabeth’s phone starts ringing in her bag.

‘Don’t touch it,’ says Sue.

Elizabeth does as she is told. But she doesn’t need to touch it. She has recognized the personalized ringtone.

They reach the front door of Joyce’s building. Elizabeth looks up at her best friend’s window. The curtains are shut. They were not shut when she picked Joyce up this morning. Joyce keys in her security code and the three women enter the building.

The lift doors are directly in front of them. Elizabeth presses the button and the doors open. Sue Reardon smiles.

‘If you try anything in that lift, I’ve got three armed men upstairs.’

‘We’ve given up, Sue,’ says Elizabeth. ‘Don’t you get it? Just get your diamonds and go.’

The doors close and the lift jolts upwards. Sue stands behind Joyce and Elizabeth, the gun at their backs. As the lift doors open on the first floor, her view is obscured.

‘Joyce, hit the ground!’ shouts Elizabeth.

Elizabeth and Joyce throw themselves to the floor, giving Bogdan a clear shot. He hits Sue exactly where he aims, through the shoulder. Sue drops her bag and her gun, her eyes wide in surprise.

Bogdan kicks Sue’s gun away, then helps Joyce and Elizabeth to their feet.

‘Come in,’ says Bogdan. ‘I’ve put the kettle on.’

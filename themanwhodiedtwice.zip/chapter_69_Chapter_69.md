## 69

Chris could live without this. Two spies had been shot. Or one spy had been shot by another spy. Or no spies had been shot, and the whole thing was one big magic trick? But, whatever the truth of it, it wasn’t something he could get involved with. He could catch and handcuff the killer himself, but no one would ever get to hear about it. This was one for the Security Services.

It was interesting, sure, murder and diamonds, and if he was in a better place he could enjoy it. But all he can think about is Connie Johnson. Connie Johnson and Patrice. When Patrice’s doorbell rang last night, he had feared the worst. And had hid it badly from Donna. Perhaps Ron and Bogdan could work a miracle?

But here he is regardless. Out of politeness. In the Jigsaw Room, with the Thursday Murder Club in full flow.

Dominating the room are three huge boards, each covered in a sheet of perspex. Beneath the perspex sit half-finished jigsaws of _The Haywain_, Sydney Opera House at Sunset and a 2,000-piece puzzle of the wedding of Prince Charles and Lady Diana. So far only the borders of that jigsaw, and the eyes of the happy couple have been completed. During the opening pleasantries, Chris had been looking into Diana’s eyes. The future was there for all to see. Poor Diana, he thought, I hope you had a bit of fun along the way.

But now Elizabeth has dropped the bombshell, and she has Chris’s full attention.

‘So you have twenty million pounds’ worth of diamonds?’ asks Chris Hudson. ‘In your possession?’

‘Yes, give or take,’ says Elizabeth.

‘And where are they?’ asks Donna.

‘Never you mind where they are,’ says Elizabeth.

‘They’re in my kettle,’ says Joyce.

‘Do your spy friends know you’ve got them?’ asks Chris.

‘Not yet,’ says Elizabeth. ‘I’ll tell them, but I need a plan in place first. I thought you could help?’

‘If we help, can I see the diamonds?’ asks Donna.

‘Of course, dear, I’m not a monster,’ says Elizabeth.

‘What can Donna and me do?’ asks Chris.

‘Donna and I,’ says Elizabeth. ‘If I tell you, you have to promise not to get angry.’

‘Oh, here we go again,’ says Chris.

‘I want to organize a meeting with the mafia. In Fairhaven.’

‘Of course you do,’ says Chris. ‘Any reason? Or was bridge cancelled and you had a slot in your diary?’

‘You know I don’t like humour, Chris,’ says Elizabeth.

‘We want to drag Poppy out of hiding,’ says Joyce. ‘Get her to break cover.’

‘She’ll still be looking for the diamonds,’ says Elizabeth. ‘So she’ll be keeping track of me somehow. Or she’ll be keeping track of Sue Reardon, or Martin Lomax. So I want us all together in the same place, with the diamonds. Monday afternoon. Say threeish?’

‘I don’t understand what you need from Donna and I?’ says Chris.

‘From Donna and me, this time,’ says Elizabeth. ‘I need you outside, keeping those keen eyes peeled for Poppy.’

‘None of this is my business, Elizabeth,’ says Chris. ‘I can’t just suddenly get involved. Donna, back me up. It’s not our case.’

Donna agrees. ‘The killings are not our case, Martin Lomax isn’t our case, the mafia’s not our case. Unfortunately. I’d love it if the mafia was my case.’

‘And even if we were there,’ says Chris. ‘What’s your plan while we’re waiting outside? Give a load of diamonds to the mafia?’

‘I haven’t worked out that bit of my plan yet,’ says Elizabeth. ‘But I will.’

‘You can be sure she will,’ says Ibrahim.

‘Sorry,’ says Chris. ‘I’ve done all sorts for you, and I’ve always wondered where I’d draw the line. And I think that line might be keeping watch as you hand over twenty million pounds to the largest crime syndicate in the world.’

They are at an impasse. Until Ron clears his throat.

‘I’ve got a suggestion. A good one, if anyone’s interested?’

‘Ron, I love you dearly,’ says Elizabeth. ‘But are you _sure_ it’s a good one?’

‘I was just thinking,’ says Ron. ‘Seeing as it’s not Chris’s case. Why don’t we _make_ it Chris’s case?’

‘This does actually sound like it might be good,’ says Joyce to Elizabeth.

‘Chris,’ says Ron. ‘You and Donna have been chasing that drug dealer, haven’t you? The woman?’

‘Connie Johnson?’ says Donna.

‘Is that the one? Yeah, I don’t know nothing about her,’ says Ron. ‘But it’s your case, right?’

‘It is,’ says Chris.

‘Well, what about we get her involved? We tell her we’re some big gang, down from London. Tell her we’ve got a diamond trade set up with the mafia. We’ve got a meeting locally, and we’ve heard good things. Does she fancy getting involved?’

Chris could kiss Ron. He won’t but he could.

‘So Sue and Lance and that mob can swoop and catch Lomax and the mafia geezer. And you and Donna can catch the woman. Remind me of her name again?’

‘Connie Johnson, Ron,’ says Chris. Actually, he will kiss him. First chance he gets.

‘If you say so,’ says Ron. ‘What do you reckon?’

Chris looks at Donna. ‘If we got a tip-off that Connie Johnson was doing a deal. And we had a time and a place? We’d go and investigate, wouldn’t we?’

‘We’d pay it a visit, I reckon,’ says Donna.

‘Ron,’ says Elizabeth. ‘This isn’t bad at all. But how do we convince Connie Johnson that we’re a big London gang?’

Ron motions to himself, offended. ‘I just show up, don’t I? Whack on a suit. Tell ’em I’m Billy Baxter or Jimmy Jackson, down from Camden. Flash the tattoos, flash the diamonds.’

‘Hmmm,’ says Elizabeth.

‘I’m not sure that gangsters have Chairman Mao tattoos,’ says Joyce.

‘All right, I’ll take Bogdan with me,’ says Ron.

‘Well, this is beginning to feel like a plan,’ says Elizabeth. ‘We’ll go and pick up Frank Andrade from Farnborough airport on Monday morning, tell him the good news, we have the diamonds, do come with us. We’ll get Lance to bring Lomax down with him. Get them all over here to meet Connie Johnson. We’ll have Sue listening in a truck, and, no doubt, Poppy loitering nearby. Everybody gets arrested, everybody gets medals, and we’re home in time for _Eggheads_. Where should we have the meeting? I need somewhere we can control. Somewhere without escape routes?’

Donna pipes up. ‘There’s a manager’s office above the arcade at the end of the pier. I had to visit it once because of all the underage kids on the machines. The manager tried to bribe me with a grand in 10ps.’

‘The end of the pier sounds perfect,’ says Elizabeth. ‘Oh, and Ibrahim, I’m going to need you to drive us up to Farnborough and back.’

‘Not on Monday,’ says Ibrahim, shaking his head. ‘My ribs, and my eyesight. Maybe in a few weeks. I would love to, but I’m afraid I can’t.’

Donna looks at Ibrahim. ‘I think you probably can, though. Don’t you? Just a little mountain?’

Ibrahim thinks. Then shakes his head at her and mouths ‘sorry’. Chris looks at Donna. What was _that_ about?

‘Splendid,’ says Elizabeth. ‘Everyone has a job to do.’

‘Except Joyce,’ says Ibrahim.

Joyce smiles. ‘Oh, I have a job to do. A secret for now though. Ron, do you fancy walking me over to mine afterwards? I have an idea for you. And, Donna, why don’t you wander over with us too, and I can show you the diamonds before you head off?’

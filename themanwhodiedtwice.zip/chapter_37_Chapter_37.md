## 37

## Joyce

What a long day. We’ve just got back from seeing Martin Lomax and now there’s this meeting at Ibrahim’s to go to.

Luckily, I slept all the way back. I woke up with my head on Ron’s shoulder. He has a reassuring shoulder, though no one will hear that from me.

Lomax was not what you would expect at all. Or not what I would expect at all. If you met him in the street, you would think he was a solicitor, or a man who owns a dry cleaner’s, but doesn’t work in it. I would say I found him attractive, except he turned out to be a bit boring, and I can’t find boring men attractive. Believe me, I’ve tried. Wouldn’t it make life simpler?

Although perhaps he isn’t really boring, if everything you hear is true? Killings and gold, and helicopters and whatnot? Though if you need killings and gold and helicopters to make you interesting then I suppose you are still boring at heart. Gerry never needed a helicopter.

And, regardless, I wouldn’t date somebody who killed people.

But all I’m saying is that he looked a bit like Blake Carrington, so don’t blame a girl for looking.

Elizabeth was on to him in a heartbeat, of course. Oh, you must be Mr Lomax, what beautiful gardens, what a beautiful house, is that a pagoda, have you been to Japan, Mr Lomax, you must, you simply must. She is a terrible flirt.

Poor Martin Lomax looked half scared to death, though perhaps that was the point?

Ron was next up. He nodded to the house and said, ‘How much did that set you back?’ Lomax had no answer, and when Ron added, ‘You’ve got effing turrets, mate, effing turrets,’ Lomax pretended to see someone in the crowd and said he must be off.

Elizabeth linked her arm into his and said, ‘Well, let’s walk together, what a day, glorious,’ and Lomax tried, very politely, to shake her off. But no such luck for him.

Elizabeth wondered if she might ask him a few questions, and Lomax said everything she needed to know about the gardens was in the leaflet we’d picked up at the entrance. And Elizabeth said, ‘Well, I doubt very much the information I need to know is in the leaflet, I doubt that very much indeed, Mr Lomax.’

Slight worry crossed his face at this point. People really don’t buy that Elizabeth is a harmless old woman for very long. With me it lasts much longer, but Elizabeth doesn’t have that gift. So Lomax wrenched himself away and said he wished Elizabeth good day and he had plants to attend to.

Elizabeth let him get a couple of metres away before saying, quite quietly, ‘I just wondered, before you’re far enough away that I have to raise my voice, did you kill Douglas and Poppy yourself, or did you send someone else to do it again?’

Well, that got his attention all right. He turned – and honestly he really does look a bit like Blake Carrington – and he said, ‘Who are you?’ and Elizabeth said, ‘Wouldn’t you like to know?’ and told him they really should chat, because they were both looking for the same thing.

‘And what are you looking for?’ he asked, and Elizabeth said, ‘Let’s talk about that, shall we?’

So, arm in arm, she led Martin Lomax away from the crowds, and around to the side of the house, and introduced herself, and me and Ron. Bogdan had driven us, but he stayed in the car. He is learning Arabic from a tape.

Elizabeth asked Lomax if Douglas had told him where the diamonds were before he’d shot him, and Lomax said he had no idea what she was talking about, and Elizabeth rolled her eyes and said, ‘Look, let’s just be honest with each other, we’re both old hands.’

I felt I should say something. I don’t know why, it just seemed about time, so I said, ‘We were very fond of Poppy,’ and he said, ‘Who’s Poppy?’ and I said, ‘She shot your friend Andrew, remember? And then you shot her, yesterday.’

At this you could sort of see he gave up. Perhaps I don’t seem harmless any more? That will be annoying if it turns out to be the case.

He confronted Elizabeth and said I don’t know who sent you, and she said we sent ourselves, and he looked at us and said he could believe that. Then he said, ‘Cards on the table, can I trust you?’ and Elizabeth said, ‘Not really, but if you didn’t kill Douglas, and if you want your diamonds back, we’re probably the best bet you’ve got.’ And then he told his story.

Yes, the diamonds had been real, and yes, they had been stolen. I think we all knew and agreed on this point already. Yes, he had found out Douglas was responsible, and yes, he had threatened him. Ron said, ‘I would have done too, to be fair,’ and Lomax thanked him for that.

You could smell the last of the honeysuckle in the air; it climbs up the side of the house. A west-facing wall is best for it, I learned that on _Gardeners’ Question Time_. Gerry was the gardener in the family, not me, but I still listen to it because it reminds me of him.

Lomax then admitted that he had sent Andrew Hastings to Coopers Chase. The way he told it, he had just wanted to give Douglas a scare. To force Douglas to tell him where the diamonds were. Then Poppy stepped in, shot Andrew Hastings, and Lomax was left a man down and none the wiser.

Elizabeth asked how he knew they were at Coopers Chase, and Lomax said that MI5 were very leaky, and I asked Elizabeth if that was true and she said it certainly used to be.

Poppy and Douglas were then whisked away, and Martin Lomax said he had no idea where to, so had given up the chase. Elizabeth asked if he hadn’t tried MI5 again, and he said of course he had, but no information was forthcoming. Presumably far fewer people knew about the new safe house.

Lomax then asked if we knew where the diamonds were, and we confirmed that we didn’t. And then he said he was likely to be driven out to sea and shot dead if they didn’t turn up sharpish. And you could tell that was the truth.

This is my point about boring men and exciting men. Gerry would never be driven out to sea and shot, but he was a hundred times more exciting than this Lomax. And Gerry didn’t look like Blake Carrington, but perhaps if he had then he might not have ended up with me? Which is not a thought I’m comfortable entertaining. In certain lights he looked like Richard Briers though.

Ron asked if he could use the toilet, and Lomax said there was one in the stables, and Ron said couldn’t he use one in the house, and Lomax said no chance. Nice try, Ron. I don’t think he wanted to go snooping or anything, I think he just really needed the loo.

Elizabeth gave Martin Lomax her card (when did Elizabeth get a card? She kept that quiet) and told him that if what he said was true then we had a shared interest in finding the killer. Lomax agreed, and Elizabeth said to ring her if anything cropped up, and she would do the same in return.

I took my chance and went into my bag and pulled out a friendship bracelet. Lomax looked horrified, which I am getting used to, but I explained it was for charity, and Elizabeth assured him I wouldn’t leave until he’d bought one. I had one that was gold and green and I thought quickly and said the green was for the garden and the gold was for the sun. I was going to say that the sequins represented the diamonds, but I decided not to push my luck.

I asked him which charity he wanted his money to go to, and he shrugged, and I said to just pick a favourite charity. He said he didn’t have one, and asked who people normally gave the money to and, because I was standing with Elizabeth, I suggested Living With Dementia. Then he asked me how much they were and I told him that was up to him, and he didn’t seem to understand that, and I said, you just give what you can afford. I was looking at the house when I said that.

He nodded, reached into his jacket and pulled out a cheque book. A cheque book! Even I don’t use cheques any more, and I’m seventy-seven. He wrote his amount on the cheque, then folded it up. He handed me the folded cheque and I handed him the bracelet.

He seemed meek as a lamb at that point. But then he said, ‘Are you all finished?’ and when we said we were, he looked at each of us in turn, like a butcher sizing up a cow. It was quite unnerving.

‘I bet they all lap it up, don’t they?’ he said. ‘The three of you. Harmless little gang. The police, MI5, they buy this act?’ Elizabeth agreed that people do seem to buy it, yes, and Martin Lomax nodded and said, ‘Doesn’t work with me, I’m afraid. I don’t care if you’re eighteen or eighty. I’ll kill you regardless. You understand that, don’t you?’

It was quite frightening, if I’m being honest. I have to remind myself sometimes that this is not a game.

Elizabeth said that of course we understood, and that he was being ‘admirably unambiguous’.

Then Lomax said, ‘Charm doesn’t work on me,’ and Ron said, ‘More power to you,’ and then Lomax said, ‘If you find my diamonds, and you don’t bring them straight to me, I will kill you. If you even _suspect_ where they are without telling me, I will kill you.’

He doesn’t hold back, I will say that for him. In a way it’s refreshing, because at least we know where we stand.

Then he said he would kill us one by one. He pointed at Ron and said he would start with him. Ron gave us an ‘it’s always me’ gesture. And he’s right, it always is.

‘We’ll be sure to let you know then,’ Elizabeth said. ‘If we find them.’

And this is how it ended. Lomax said, ‘I don’t _want_ to kill you.’ Ron said, ‘Sure.’ Lomax said, ‘But I will, without a second thought,’ and Elizabeth said, ‘Message received and understood.’

By this time Ron really, really needed the toilet, so we said our goodbyes.

We did actually have a quick turn around the garden after that, because it was very lovely, and then Bogdan drove us home. I asked him to do some Arabic on us, which he did. Just one to ten.

Elizabeth believes Lomax, that he didn’t kill Douglas and Poppy. I told her I thought he was unconvincing and she said well, that was just the thing. Liars like Lomax always sound at their most unconvincing when they’re telling the truth. They’re simply not used to it.

So who did kill them? She has a theory, and she has invited Sue Reardon down to the village to test it out. I know not to ask by now.

By the way, earlier, when I said Elizabeth is a terrible flirt, I didn’t mean she’s a terrible flirt like I’m a terrible flirt. I mean that when she flirts she’s terrible at it. Really all over the place. I like to see things Elizabeth is bad at. There aren’t many, but at least it levels the playing field a bit for the rest of us.

As I say, we slept all the way home, so it wasn’t until I got in that I remembered the cheque, and got excited.

I opened it up and it said ‘five pounds only’. Well, thank you ever so much, Martin Lomax; lucky old Living With Dementia.

## 36

When Bogdan was ten years old, his friends had dared him to jump off a bridge. The drop was, perhaps, forty feet, straight into a fast-flowing, rocky river. A boy had died a few years before making the same jump. For a while the local authorities had put barbed wire along the parapet to stop anyone being quite so foolish again. But by this time the barbed wire had rusted and buckled and fallen into the river below. No one had thought to replace it, because money was tight and memories were short. Also, the boy’s mother had killed herself shortly afterwards, so it very quickly began to feel like the whole thing hadn’t happened at all.

Bogdan remembers looking over the side of the bridge, down to the furious white water and the jagged grey of the rocks. There were three main ways he could die if he jumped. The simple impact of his body on the water from this height might kill him instantly. He could easily avoid the rocks he could see, but there were plenty of rocks hidden just below the surface, and if he struck one of them he would die for certain. And if he avoided both of those deaths? Well, the current was fierce and unforgiving, and he would need strength and luck to make it to either bank.

His classmates were goading him, calling him _tchórz_, a polecat, which is what they called being chicken over here. But Bogdan wasn’t listening, he was staring at the drop. What would it feel like? Flying through the air? He bet it would feel pretty good.

Bogdan knew, even back then, that he was not an especially brave person, and he certainly wasn’t foolhardy. No one would ever accuse him of that. Bogdan is not a risk taker; he is never driven by testosterone or by insecurity. Nonetheless, he remembers taking off his sweater, one his mum had knitted him, and climbing onto the parapet, to the horror of his suddenly frightened friends.

It was a long way down.

‘Do I present the football?’ asks Ron from the back seat. Bogdan is suddenly brought back to the here and now. Driving Elizabeth, Joyce and Ron to visit an international criminal.

‘No,’ says Elizabeth.

They hadn’t been able to agree on a radio station, and so they were playing Twenty Questions, trying to guess the identity of famous people. Ron had guessed Joyce’s one, Noel Edmonds, after getting a ‘yes’ to the question ‘Do I shout at the TV when he comes on?’ They are currently at a dead end trying to guess Elizabeth’s.

‘Am I … who’s the man I’m thinking of, the actor?’ says Joyce.

‘No,’ says Elizabeth.

‘Can we give up?’ says Ron.

‘You’ll kick yourself,’ says Elizabeth.

‘Go on,’ says Ron.

‘I was the murdered Russian oligarch Boris Berezovsky,’ says Elizabeth.

‘Oh,’ says Ron.

‘Denzel Washington!’ says Joyce. ‘That’s who I was thinking of.’

Bogdan has a bag of sweets, and every twelve minutes he passes them round, because he knows it will keep everyone quiet. He also knows he won’t need to save any sweets for the journey home later, because these three will be fast asleep.

They had talked a little about the murders. Ron thinks that Douglas and Poppy were killed by the mafia. He asked Bogdan if he had ever seen _Goodfellas_ and Bogdan agreed that he had, and Ron said, ‘Well then.’ Joyce thinks that some doctor is involved somehow, and Joyce is usually right. Although, Bogdan thinks, looking down at the friendship bracelet on his wrist, she can’t knit.

What does Elizabeth think? Who knows? She will wait until she’s spoken to this Martin Lomax.

Bogdan would have driven much faster if it was just him. But the combination of Ron’s Daihatsu and Bogdan’s respect for his passengers meant he kept to a steady eighty miles an hour the whole way. Elizabeth would occasionally tell him to put his foot on it, and then Ron would say, ‘Slow down a bit, Bogdan, this isn’t Poland.’ Which suggested he had got it about right.

He sees the signs for Hambledon at around one thirty. As he knew he would. Not satnav either, he refuses to use them. Bogdan turns right or left when Bogdan chooses to turn left or right. You don’t need to tell Bogdan that he’s approaching a roundabout.

Hambledon is a pretty English village, though as they drive through Bogdan spots a few roofs that could do with a bit of attention.

‘This is where the first-ever game of cricket was played,’ says Elizabeth.

‘Probably still going on, knowing cricket,’ says Ron.

They pass a primary school, a pub called The Bat and Ball and even a sign to a vineyard before the first signs to Martin Lomax’s ‘Open Garden’ appear. Soon they reach a broad entrance off a small country lane, iron gates wide open, and welcome notices nailed to trees. Bogdan drives in and parks next to a hedge the size of a house.

As ever, it is taking his three passengers a while to ‘get their things together’.

‘I see you back here, OK?’ says Bogdan. ‘You take as long as you want.’

‘Thank you, dear,’ says Elizabeth. ‘It is very unlikely we’re about to be murdered, but if we’re not back in two hours then come looking for us, and kick up a fuss.’

‘Gotcha,’ says Bogdan, and checks his watch. Saying ‘Gotcha’ always makes him feel very English.

‘And the leaflet says there’s loos, if you need,’ says Joyce, zipping up an anorak and manoeuvring her way out of the car.

‘I won’t need the toilet,’ says Bogdan.

‘Lucky sod,’ says Ron.

And with that they are gone, and there is blessed silence.

Bogdan thinks back to the parapet and the raging river. His friends were begging him not to jump. The sweater his mother had made was yellow, and he sees it now, neatly folded up beside him. He was always good with creases.

He took one last look down. Three ways to die, sure, but we all die someday. To the screams of his friends, Bogdan jumped.

What a feeling, just magical.

He broke three ribs, but they soon healed. It was the right choice, as he had known it would be.

People love to sleep, and yet they are so frightened of death. Bogdan has never understood it.

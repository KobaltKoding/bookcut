## 15

Douglas Middlemiss is in bed, reading a book about Nazis, largely anti, when he hears the noise. It is the door to the flat opening, very slowly and very quietly. It isn’t Poppy; she came back an hour or so ago. Where had she been? Collared by Elizabeth, perhaps? That would be Elizabeth’s style, killing the new girl with kindness.

Speaking of killing, the door being opened quite so softly is bad news for Douglas. Only he and Poppy have keys, and the only other way to open a door that quietly is to be a professional. So what was this? A burglar or an assassin?

He would find out soon enough.

Douglas wishes he had a gun. In the old days he would have done. Once, in Jakarta, he accidentally shot a cultural attaché from the Japanese embassy through the arm during a bout of vigorous love-making. She was terrifically good about it. The National Gallery was persuaded to lend a Rembrandt to a Tokyo museum and nothing more was said about it. But from that day on he would tape his gun under the bed rather than leave it under the pillow.

He thought all this as he took off his reading glasses, did up the button fly on his pyjama bottoms and slipped out of bed. Poppy had a gun. She didn’t seem the type to ever use it, but she must have had the training, surely? Had she heard the front door open? Perhaps not. Douglas had grown alert to danger over the years, but Poppy would not have. Perhaps never would. He’d met Poppy’s type many times before, and she would be out of the Service and having babies before you knew it. Not that you’re allowed to say that these days. World gone mad etc.

As Douglas starts to straighten the bedclothes he hears the rattle of the padlock on his bedroom door. So, an assassin rather than a burglar? Douglas had suspected as much. Sent by Martin Lomax, perhaps? The Americans? The Colombians? It seemed ridiculous, really, but Douglas would prefer to be shot by someone British. English ideally, but beggars can’t be choosers.

Bolt cutters would get through the padlock within a minute. But not without making a noise. Not without waking Poppy. He just needs Poppy to reach the intruder before the intruder reaches him.

The bed is straightened, and it now looks untouched, as if no one has slept there, as if the occupant is still out enjoying the night air. Douglas walks quietly over to the wardrobe, opens the doors and steps in. This will probably buy him only ten or fifteen seconds, but that might be enough. He closes the wardrobe doors behind him and stands in the dark.

You always wonder, in this job, where it might end for you. Douglas might have died, variously, on a glacier in Norway, in a car boot on the Iran–Iraq border, or in a missile attack on an American base in Kinshasa. But perhaps it was all going to end in a tatty wardrobe, in his pyjamas, in an old people’s home? Douglas was interested to find out. Scared too, certainly, but still interested. Of all the things that were to happen to you in life, death was one of the very biggest. Douglas hears the padlock give way. Surely Poppy heard _that_?

Through the thin crack between the wardrobe doors, Douglas can make out a man walking into the room, gun raised and pointed at the bed. A pale light from a street lamp shines a single thin column through the curtains.

He watches the man turn and look around him, having seen the bed is empty. Douglas is not breathing. Might never breathe again, he realizes, as the man turns to face the wardrobe. If someone is hiding, then this is the only conceivable place. And anyone who can silently open a door without a key and cut through an MI5 padlock within a minute will know that.

The man takes two steps towards the wardrobe, gun still raised. White, Douglas thinks, maybe forty? So hard in this light. What was his name, Douglas wondered. It felt like that was information he should be allowed to know. Had they ever met? Passed on a street like future lovers?

Poppy wasn’t coming. How had she not heard? Unless? Oh, of course. Of course. Perhaps Poppy had not been with Elizabeth this evening at all. Perhaps there had been a briefing? Orders handed down. We want this problem to go away. Just turn a blind eye, no one’s to know. We’ll send in one of our men. Douglas doesn’t have any relatives, no kids to be asking questions. Poppy was junior enough to fall in line. She would be in her room now, cowering. When they found his body, would Elizabeth work out what had happened? A ridiculous thought, no one would find his body. A Special Ops group would be on hand to clear everything up. A military coroner would be waiting for him somewhere. All the paperwork done right. Probably a suicide. Elizabeth would never get close enough to know any different. Elizabeth really was looking good, Douglas had to admit it. He would have loved another crack at her. Will she find his other letter? Of course she will.

The man hooks an outstretched foot under one of the wardrobe doors and pulls them open. He smiles to himself as he sees Douglas standing there.

The man looks English. The gun isn’t Service issue, but sometimes they employed freelancers. ‘Worth a go,’ says Douglas, his hands indicating the inside of the wardrobe.

The man nods. Douglas waits for an epiphany, a sudden flash of clarity about his life. Something to take with him on whatever journey he is about to embark upon. But there is nothing. Just a man with a gun, and the label of his pyjama top itching against the back of his neck. What a way to go.

‘Where are the diamonds?’ asks the man. An English accent. That brings Douglas some peace.

‘Afraid not, old boy,’ says Douglas. ‘You’re going to kill me anyway, and I’d rather someone else ended up with the diamonds.’

‘I might not kill you,’ says the man.

Douglas smiles and raises a dubious eyebrow at the man with the gun. The man with the gun nods in concession.

‘This will sound ridiculous,’ says Douglas. ‘But let me solve one final mystery. I’d love to know who sent you?’

The man shakes his head and Douglas watches as he squeezes the trigger.

## 53

The gang are all crowded around Ibrahim’s bed. Elizabeth has brought a notebook, Joyce has brought chocolate fingers and Ron has brought a copy of _Rocky III_ (‘the best _Rocky_’) for Ibrahim to watch with him later.

But there is another film for them to watch first. Elizabeth is drumming her fingers and Ron is pacing as Ibrahim gets everything ready. He gets the footage up on his screen. Kendrick is on the balcony playing _Pokémon_.

‘So,’ says Ibrahim, ‘here is today’s question. Who is this?’

Ibrahim presses play, and they all watch as the figure in the motorcycle helmet walks down the row of lockers and stops in front of 531\. The figure inserts a key.

‘Looks like he’s having trouble with the lock too,’ says Joyce.

‘Or she,’ says Ron. Ibrahim notes that Ron is getting much sharper on his gender neutrality.

The figure has trouble with the lock but eventually it pops open. The camera angle doesn’t show the inside of the locker, but they know precisely what the figure is seeing. They watch as the biker takes the crisp packet out of the locker, then tosses it back in. The biker stares at the empty locker for quite some time before locking it back up and leaving.

Ibrahim stops the footage and it becomes a still image. ‘And there we have it,’ he says.

‘So this was the day _before_ Poppy and Douglas were shot?’ says Joyce.

‘Yes, we weren’t even going to check the day before. Kendrick suggested it.’

‘Kendrick?’ says Elizabeth.

‘Yes, Ron’s idea,’ says Ibrahim.

‘Thought he might enjoy it,’ says Ron.

‘If this was the day before, then how did somebody else know about locker 531?’ asks Elizabeth.

‘Douglas must have told somebody else,’ says Joyce.

‘Douglas probably told everyone,’ says Ron. ‘All his ex-wives. Stuck it on Facebook.’

‘Unless it _is_ Douglas,’ says Joyce. ‘I mean, it could be, couldn’t it?’

‘It could be anyone, Joyce,’ says Ron. ‘It could be Elizabeth, for all we know.’

‘Douglas was in protective custody the whole time, it couldn’t possibly be him,’ says Elizabeth. ‘And, besides, he was the one person who knew the locker was empty.’

‘But who else would he have told?’ asks Joyce.

They stare at the figure on the screen. Dark leathers, dark helmet, dark gloves.

‘What are we missing?’ asks Elizabeth. ‘Let’s watch again.’

They sit through the footage again. And again. And again. But nothing. Elizabeth slumps back.

‘We can’t tell the gender, we can’t tell the age, we can’t even tell the height because of the angle of the camera.’

Kendrick walks in from the balcony. ‘That was really good orange squash, Uncle Ibrahim. Did you all see the clue?’

‘The clue?’ asks Elizabeth.

‘Hello, Elizabeth,’ says Kendrick. ‘Yeah, did you see it? I bet you did.’

‘I mean, I read certain things into posture, and into stride patterns, if that’s –’

‘No, the clue. Did you see it, Joyce?’

‘I didn’t spot a thing,’ says Joyce.

‘We made cupcakes earlier, and I did the icing,’ says Kendrick. ‘Would you like one?’

‘No, you have mine,’ says Joyce.

‘OK,’ says Kendrick. ‘Grandad and Uncle Ibrahim, I bet you saw it?’

‘I saw it,’ says Ron. ‘But in case it’s not the same clue you saw, why don’t you say yours first?’

Kendrick leans forward into the screen. ‘OK, watch the bit where he’s opening the locker.’

Ibrahim speeds the footage through and pauses it. The four of them are all looking at each other. Ron shakes his head a little and shrugs.

‘You see when he reaches up to the lock?’ says Kendrick.

They do see.

‘And you see a little gap between his jacket and his glove?’

They lean forward. There _is_ a gap as the jacket slides down towards the elbow.

‘And there’s the clue!’

The short-sighted lean further forward, and the long-sighted lean further back.

‘What is it, dear?’ asks Elizabeth.

‘He’s wearing one of Joyce’s friendship bracelets.’

Coiled around the wrist of the figure opening locker 531 are some inexpertly woven strands of wool, studded with sequins.

Everyone in the room looks down at their wrists, and then at Joyce.

Joyce looks down at her bracelet, then back up at her friends. ‘Well, that narrows things down nicely.’

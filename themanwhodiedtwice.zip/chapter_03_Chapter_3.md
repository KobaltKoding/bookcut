## 3

## Joyce

I do wish something exciting would happen again. I don’t mind what.

Perhaps a fire, but where no one gets hurt? Just flames and fire engines. We can all stand around watching, with flasks, and Ron can shout advice to the firefighters. Or an affair, that would be fun. Preferably mine, but I’m not greedy, so long as there’s a bit of scandal, like a big age difference, or someone suddenly needing a replacement hip. Perhaps a gay affair? We haven’t had one of those at Coopers Chase yet, and I think everyone would enjoy it. Maybe someone’s grandson could go to prison? Or a flood that doesn’t affect us? You know the sort of thing I mean.

When you think of how many people have died around here recently, it is quite hard to just go back to pottering around the garden centre and watching old episodes of _Taggart_. Although I do like _Taggart_.

When I was a nurse, patients would die all the time. They were popping off left, right and centre. Don’t get the wrong idea, I never killed anyone, although it would have been very easy to. Easier than a doctor. They used to check up on doctors a lot. They probably check up on everyone these days, but I bet you could still do it if the mood took you.

Ibrahim doesn’t want me to get a dog, but I am sure I can change his mind. Before you know it, he’ll be dog this and dog that. You can bet he’ll be first in line to walk it, too. I wish I’d got my hands on Ibrahim thirty years ago.

There is an animal rescue centre just across the border in Sussex, and they have all sorts there. The usual cats and dogs, but then also donkeys and rabbits and guinea pigs. I’ve never thought that a guinea pig might need rescuing before, but I suppose they do. We all need it once in a while, and I don’t see why guinea pigs would be any different. They eat guinea pigs in Peru, did you know? It was on _MasterChef_ the other day. They just mentioned it, they didn’t actually eat one.

Lots of the dogs are from Romania; they save them and bring them over. I don’t know how they bring them over, that’s something I will ask. I don’t imagine they have a plane full of dogs. In a big van? They will have worked out a way. Ron says they will bark in a foreign accent, but that’s Ron.

We looked on the rescue centre website and you should see the dogs, honestly. There is one called Alan I have got my eye on. ‘Indeterminate terrier’, according to his profile. You and me both, I thought when I saw that. Alan is six years old, and they say you mustn’t change their names, because they get used to them, but I won’t call a dog Alan, whatever pressure I am put under.

Maybe I can persuade Ibrahim to drive me over next week. He’s gone car mad recently. He’s even driving into Fairhaven tomorrow. He has really come out of his shell since everyone started getting murdered. Driving here, there and everywhere like he’s Murray Walker.

I’m still wondering why Elizabeth was in a funny mood at lunch. Listening but not listening. Perhaps something is wrong with Stephen? You remember, her husband? Or perhaps she’s still not over Penny. Either way, she has something on her mind, and she walked away from lunch with a purpose. That’s always bad news for someone. Your only real hope is that it’s not you.

I am also knitting. I know, can you imagine?

I got talking to Deirdre at Knit & Natter. Her husband was French but died some time ago – I think he fell off a ladder, but it might have been cancer, I can’t remember. Deirdre has been knitting little friendship bracelets for charity and has given me the pattern. You make them in different colours, depending on who you make them for. People pay you whatever they choose and all the money goes to charity. I also put sequins on mine. The pattern doesn’t say to put sequins on, but I’ve had some in a drawer for ages.

I made a red, white and blue bracelet for Elizabeth. It was my first go and was rather ragged but she was very good about it. I asked her what charity she wanted the money to go to and she said Living With Dementia and that’s the closest we have got to talking about Stephen. I don’t think she can keep him to herself for much longer, though; dementia just ploughs on through the woods and never turns back. Poor Elizabeth. Poor Stephen as well, obviously.

I also made a friendship bracelet for Bogdan. It was yellow and blue, which I had mistakenly thought were the colours of the Polish flag. According to Bogdan, the colours of the Polish flag are red and white, and, to give him his due, he would know. He thought that perhaps I had been thinking of Sweden, and perhaps I had. Gerry would have put me right. Like all good husbands, Gerry knew all the flags.

I saw Bogdan wearing his bracelet the other day. He was on his way up to work at the building site at the top of the hill, and he gave me a little wave and there it was on his wrist, wrapped around his tattoos of goodness knows what. I know it’s silly, but I couldn’t stop smiling. The sequins were sparkling in the sunshine and so was I.

Elizabeth hasn’t worn hers yet, and I can’t say I blame her. I am getting better at it though, and, besides, Elizabeth and I don’t need a bracelet to show we are friends.

Last night I dreamt of the house Gerry and I lived in when we were first married. We opened a door and found a new room we hadn’t ever seen before, and we were full of schemes as to what to do with it.

I don’t know what age Gerry was, he was just Gerry, but I was me now. Two people who never met, touching and laughing and making plans. A pot plant here, a coffee table there. The stuff of love.

When I woke up, and realized Gerry had gone, my heart broke once again, and I sobbed and sobbed. I imagine if you could hear all the morning tears in this place it would sound like birdsong.

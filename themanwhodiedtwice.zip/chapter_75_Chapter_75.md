## 75

Elizabeth has been a fool, but at least she knows why.

It was all Marcus Carmichael’s fault, really.

Right from the very beginning. The dead man by the River Thames who never was. The unclaimed body collected from a London hospital and dressed up by her operatives. That reminder of the grand illusions of her trade. Making people believe exactly what you wanted them to believe. Making things _complicated_. Taking pains.

Elizabeth had been a master of it. Douglas had been a master too. Somewhere in a drawer is a photograph of their wedding day. Elizabeth and Douglas with smiles so broad you would swear it was the happiest day of their lives.

Nothing was ever how it seemed.

Except, Elizabeth realizes now, sometimes things are exactly how they seem. At least she has realized this in time.

She is sitting on bench seating in the back of the coroner’s van. They are heading to the morgue at Godalming. The same morgue where Douglas and Poppy’s bodies had been identified.

Next to her is Joyce. She is doing a word search on her phone. Elizabeth knows she should listen to Joyce more often. Of course, Poppy hadn’t done it. Poppy hadn’t murdered Douglas, then murdered some poor young woman and had the body identified as her own.

Poppy hadn’t hatched a plot with her mother to steal the diamonds. There was another explanation for Siobhan.

Who on earth would ever believe that Poppy had done it? Only someone very stupid. Or someone too clever by half.

Elizabeth is coming to understand that perhaps, just sometimes, things are exactly what they seem. When Ron gives her a hug, or Joyce bakes her a cake, or Ibrahim laminates a document for her, they are not playing a game. They don’t need anything in return other than her happiness and her friendship. They just _like_ her. It has taken Elizabeth a long time to accept the truth of that.

On the bench opposite her is Sue Reardon. Sue Reardon has a mind like hers. They had laughed about it. Peas in a pod. Elizabeth hadn’t realized the half of it.

Between the benches, along the length of the van lies the corpse of Martin Lomax. Frank Andrade’s is being dealt with by MI6\. His is in a different van, travelling down a different motorway.

Poppy and Douglas were both shot dead. There were no fake corpses, there was no grand cover-up. They were both shot dead by Sue Reardon. For a very obvious reason. And Sue Reardon had spun Elizabeth a line she knew she wouldn’t be able to resist.

How to prove it though?

Elizabeth looks over at Joyce, tongue sticking out as she circles words with her finger. Like butter wouldn’t melt. She is recording everything on her phone. Just as she has been told.

The first part of the journey had been the expected barrage of questions from Sue about the diamonds, and who on earth was Connie Johnson, and why did she have a bag full of cocaine with her? Elizabeth had answered all the queries as politely as she felt able. But now it was her turn to ask the questions.

‘So,’ she begins, leaning forward and smiling at Sue over the draped corpse of Martin Lomax. ‘We didn’t find Poppy then?’

‘No,’ says Sue. ‘Nowhere to be seen.’

‘Curious,’ says Elizabeth. ‘Perhaps she really is dead. Do you think, Sue?’

‘Perhaps,’ says Sue. ‘But we still can’t explain her mum looking for the diamonds.’

‘You nearly had me, you know?’ says Elizabeth.

‘I’m sure I don’t know what you’re talking about,’ says Sue.

‘You killed Douglas and Poppy. You knew where they were, you walked in, you shot them, and you walked straight out again.’

‘Sounds very simple,’ says Sue.

‘It was simple. But you knew simple wouldn’t be interesting enough for me. So you led me on a piece of string around all sorts of wonderful theories. Just to buy yourself a bit of time to find the diamonds. Or for me to find the diamonds for you. Keeping me interested.’

‘Well, now it sounds outlandish,’ says Sue. ‘What an imagination you have, Elizabeth.’

Elizabeth shakes her head. ‘My imagination was my downfall here, I’m afraid. As soon as I realized it was you who slipped Siobhan’s phone number into Joyce’s pocket, the whole thing fell into place.’

‘Oh, I wondered why you asked about that,’ says Joyce.

Sue Reardon’s phone buzzes. She opens a message and smiles.

‘Well, speak of the devil – there’s Poppy’s mum now. With some good news.’

‘Do tell,’ says Elizabeth.

‘I’m told we’ve found the diamonds. In Joyce’s microwave of all places. How pleasingly suburban. But I suppose the gloves are off at least.’

Sue Reardon presses an intercom button and talks to the driver. ‘A change of plan. Coopers Chase retirement village. It’s not far.’

An echoing electronic voice replies. ‘Postcode?’

Sue thinks for a moment, takes a gun from her bag and points it at Joyce. ‘Joyce, what’s the postcode?’

## 17

## Joyce

It is two in the morning, but I want to write this all down while it is still fresh.

My phone rang at midnight, and of course I thought Ibrahim had died. What else would you have thought, in the circumstances? Nobody rings at midnight. He had looked well when we left him, but I’ve seen all sorts. I must have reached the phone within two rings.

It was Elizabeth, and the first thing she said was, ‘It’s not Ibrahim,’ so that was a relief. She can be sensitive when she tries. She said she knew that it was midnight, but I was to throw on some clothes and meet her at 14 Ruskin Court as soon as I was able. I wondered if I needed to bring a flask, but I was told there was already a kettle, and just to bring myself. It would have been quick to fill a flask, but you try telling Elizabeth that at midnight.

I walked over to Ruskin, and it really is very pretty here in the dark. There are a few lamps lighting the paths, and you can hear the animals in the bushes. I could just imagine the foxes thinking, What’s this old woman up to? and I was thinking the same. It was cold, but I have just bought a cardigan from Marks, which was perfect for the job. They delivered a few bits yesterday. I didn’t mention it, because I don’t mention everything. For example, yesterday I was defrosting a lasagne and completely forgot about it. And that’s the first you’ve heard of it.

At the door I was buzzed upstairs, heart pounding if I’m honest, not knowing what I was going to see. I pushed the door open and saw poor Poppy sitting in an armchair, shaking. Opposite her was Elizabeth, in another armchair, but not shaking. That was the only furniture in the whole place. The flat was where Douglas was hiding, I worked that much out. ‘Put the kettle on, Joyce,’ Elizabeth said, ‘Poppy’s had a shock.’ She sounded bossy, but I know she didn’t mean it; she was just being professional.

You wouldn’t believe the kitchen, by the way. Two mugs, two plates, two glasses, two bowls, some Frosties, some white Mother’s Pride, then, in the fridge, some tofu and some almond milk. There was tea and coffee in one of the cupboards and I poked my head back round and Elizabeth and Poppy stopped their conversation, and I asked Poppy if she wanted milk and sugar and she said could she have a cardamom and lychee infusion and I nodded as if this was quite normal, which I understand it is these days, and ducked back into the kitchen. Goodness me, that was a long sentence to write. In a book they would tell me to put a full stop in there somewhere. After ‘infusion’?

I filled and boiled the kettle, anxious to get back to the living room and find out what was happening. If this was Douglas’s flat, then where was he? I poured the water over the teabag, which was made of grey cloth, but each to their own, and was just thinking about whether you’re supposed to leave the bag in or take it out with herbal tea? If I left it in then I could be out there quicker, but what if that wasn’t the right thing to do? Joanna, like all daughters, would know. Anyway, that’s when I heard the toilet flush, so, to hell with protocol, I left the bag in and went into the living room.

I knew it was Douglas straight away, you could just tell. Very handsome, if I do say so myself. I could see in an instant why Elizabeth had married him, and also why she had divorced him. I bet it was fun while it lasted though.

He was straight up to me and, ‘Oh you must be Joyce, I’ve heard all about you,’ and, really, I almost curtsied, and then I caught Elizabeth rolling her eyes, so I said, ‘Yes, and you must be Douglas,’ and he said, ‘I imagine you’ve heard all about me too,’ and I said, ‘Not really, no,’ and I could see that Elizabeth liked that.

I said let me go into the bedroom and find another chair but Elizabeth said to try Poppy’s room, as there was a dead body on Douglas’s floor.

Well, that was more like it.

I got a hard-backed chair from Poppy’s room and Elizabeth let Douglas tell me the story.

He had been hiding in a wardrobe, which wasn’t cowardly, but basic training, and some chap had a gun aimed at his head. He took some time over this bit of the story, discussing death and perspective, and man’s moral duty and a life well lived. I wished Ron had been there, he would have told him to wind his neck in, but it was me, so I listened politely. He was ready to meet his maker, that was the gist of it, but as the mystery man reached for the trigger, his head was blown clean off, and there was Poppy, like the cavalry, gun in hand, cool as you like.

Cool according to Douglas, but you could see she wasn’t cool at all, still shaking, still quiet, both hands around her tea. She had said nothing about the bag still being in, so maybe it’s OK? Though I don’t think she was really in any state to, so it wasn’t a proper test.

I went and sat on the arm of Poppy’s chair and put my arm around her, and she put her head on my shoulder and started to sob quietly. I don’t think Douglas or Elizabeth had put their arm around her, and that’s when I realized, of course, that was why Elizabeth had asked me there. Ron would have done just as well, but I bet Elizabeth isn’t ready for Ron to meet Douglas yet. Douglas is so obvious, Ron would have a field day.

I told Poppy she had been very brave, and Elizabeth told her she had been a terrific shot too, and Douglas said amen to that. But Poppy was having none of it, just silently weeping.

Elizabeth did her best to be comforting, saying it was hard to kill someone, but sometimes that was the job, and then Poppy finally spoke and said, ‘That’s not a job I want,’ and I had some sympathy with that. It must be fun doing all the training, I suppose, and creeping around with no one knowing, but blowing a man’s head off from four feet away probably doesn’t suit everyone. It wouldn’t suit me, and it doesn’t suit Poppy. Actually, perhaps it would suit me? You never know until you try, do you? I never thought I would like dark chocolate, for example.

I asked what was next, and had the police been called, and Elizabeth said, ‘Well, after a fashion.’ I was hoping Chris and Donna might make an appearance, but apparently in these cases, national security and so on, these things take a different route. So Elizabeth, Douglas and Poppy were waiting for some spies to come down from London and the case would be theirs. Which is a shame because Donna, in particular, would have enjoyed the whole scene.

Elizabeth asked if I would like to see the body, and even though I really wanted to, I felt I should stay with my arm around Poppy and so I said no, I was fine, but thank you.

We only had to wait twenty minutes or so until the door buzzed and a woman and a man arrived. Sue and Lance. MI5, according to Elizabeth. Sue was in charge.

They were both no-nonsense. Sue reminded me an awful lot of Elizabeth. The manner. She must be nearly sixty and would have been pretty if she wasn’t so angry. I know it doesn’t matter if she’s pretty or not, I’m just giving you an idea of her. Her hair was a lovely chestnut colour. Dyed, but very nicely. I kept trying to make conversation, but I got nowhere.

I could tell even Elizabeth was being respectful, so I followed her lead. They turned down my offer of a cup of tea, however. They both barged past me as I stood in the kitchen doorway. Not rude, as I say, they just had a job to do. Sue knew exactly what had gone on, and told Douglas and Poppy to pack whatever they needed. She was surly with them both, especially Douglas. I ended up feeling quite sorry for him.

Lance was dealing with the corpse. Taking photos and so on. He looked like someone you would see in a DIY show on TV. Rugged, and good with his hands, but never quite the star of the show. Just sawing some wood in the background. I asked if I could take a look at his camera, because I am thinking of getting one for Joanna for Christmas. He said he would show me when he was finished up, but in the end he didn’t.

Sue told Elizabeth they would need to speak to her in due course, and she said well naturally, but quiet as a mouse, not so much scared as knowing not to cause trouble. Sue looked at me at one point and said, ‘Is this Joyce?’ She told Elizabeth to ensure I told no one about the shooting and the body and so on. I said, ‘Sue, you’re safe with me,’ but she didn’t even look in my direction, just at Elizabeth. Elizabeth reassured Sue I wouldn’t tell a soul, and she nodded, unconvinced. To be honest, I think she had bigger fish to fry.

MI5 know who I am now though, so that’s one for the Christmas newsletter.

Presently there was another buzz at the door, and two men in overalls arrived with a stretcher. Paramedics wear green, of course, but these two were head to toe in black. They went into the bedroom and loaded the body onto the stretcher. Fortunately, I was able to get a quick peek before they zipped up the body bag and, yes, Poppy really had blown his head off. Or most of it at least. It took me right back to my days in A&E.

As Elizabeth and I were leading the stretcher down the corridor, a couple of doors opened, neighbours wondering about the noise, and Elizabeth was able to tell them not to worry. If you worried about every stretcher you saw at Coopers Chase you’d need one yourself soon enough.

As we got outside, into the open air, you could see a few lights on around the place, and a few curtains opened, but, again, they were used to seeing ambulances at the dead of night. I said to Elizabeth that I was surprised it was just a normal ambulance, and she said it wasn’t a normal ambulance, it just looked like one.

As we went back in, Sue and Lance were leading Poppy and Douglas out. They had to be questioned, Elizabeth explained. Even in MI5 you can’t just shoot someone without being asked a few questions about it. Elizabeth gave Poppy a hug, which was nice, and told her not to worry, she’d done everything right. Then I gave her a hug too, and told her not to worry. I very nearly asked about the teabag, but I will ask next time I see her instead.

I gave Sue and Lance a friendship bracelet each. Sue looked like I’d just given her a parking ticket, but Lance said, ‘Thank you, I could use a bit of friendship.’ I didn’t ask them for money.

Douglas came out next, with a book called _Megastructures of the Third Reich_ and a toothbrush.

Sue told Elizabeth to secure the flat and make sure no one could gain entry. Elizabeth just nodded back to Sue and told her to take care of Poppy.

Elizabeth then told me to go home and sleep, and so I went home, but I haven’t slept. Listen to this.

As soon as my door was shut, I took off my cardigan, to hang over the back of the chair. As I was taking it off I felt something in the pocket, and I fished out a folded piece of paper, which hadn’t been there when I put it on.

On the piece of paper was a message which simply said ‘RING MY MUM’ followed by a phone number.

Poppy must have slipped it into my pocket while we were hugging.

So Poppy wants her mum, poor love. I will ring her in the morning.

I’ve put the television on. On BBC2 they are showing normal programmes from the day, but with someone doing sign language in the corner. Isn’t that clever? I was just thinking it was unfair to make deaf people stay up so late, but then realized they could tape them. What a nice thing. I’m watching a programme about the coast of Britain called _Coast_. Someone is digging up whelks. No thanks, to be honest, but the lady doing the sign language has a lovely top.

I still haven’t quite worked out how my Instagram works, which is very frustrating, as @GreatJoy69 now has over two hundred private messages.

I wonder if anyone else is awake?

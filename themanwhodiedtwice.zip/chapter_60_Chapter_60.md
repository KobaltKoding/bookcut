## 60

Time is ticking on outside Maidstone Crown Court. Ron’s chips are long gone and Chris is starting to feel concerned. Why hasn’t the case been called yet?

His phone buzzes. A message from Donna. She was on a day off, but hadn’t wanted to come along. She’ll be doing a kick-boxing class or pressure-washing her patio.

He is about to open it when he sees Ryan Baird’s solicitor walking towards them. He is wearing a new suit, actually quite sharp. Donna’s fashion advice strikes again. As the solicitor reaches the table he shakes his head.

‘Sorry,’ says the solicitor.

‘Sorry, what?’ asks Chris, but he knows what’s coming.

‘Nowhere to be seen. Phone disconnected, your boys have been round to his flat. Nothing.’

‘He’s done a runner?’ asks Ron.

‘He has,’ replies Chris.

‘Or he may be lying injured somewhere,’ says the solicitor. Adding, after Chris’s dubious look, ‘I’m his solicitor, give me a break. Right, I’m going to follow your lead and have a McDonald’s.’

‘You let us know if he gets in touch,’ says Chris. ‘From the hospital?’

The solicitor shrugs apologetically and waddles off to eat chicken nuggets in his new suit.

‘Jesus Christ!’ says Chris. ‘What are we going to tell Ibrahim?’

‘We tell him nothing,’ says Ron. ‘Until you catch him.’

‘I don’t want to break your heart, Ron,’ says Chris. ‘But we won’t catch him. He’ll be up north, or in London. Somewhere he can stay quiet until this all gets forgotten.’

‘But this ain’t going to be forgotten,’ says Ron. ‘Is it? I’ve done my bit. Conning my way into someone’s flat, planting cocaine in their lavvy. Now you do your bit.’

‘I’ll do what I can, Ron. You know that.’

‘Chris will find him,’ says Bogdan to Ron. ‘And we will find a way to stop Connie Johnson for Chris. We are clever men.’

‘And if we can’t?’ asks Chris.

‘We will find a way,’ says Bogdan. ‘You have my guarantee.’

‘Right, who’s for a McDonald’s?’ says Ron.

‘You just had one,’ says Chris.

‘That was breakfast,’ says Ron.

Chris’s phone buzzes a reminder. The message from Donna.

_Get over to Coopers Chase as soon as you can. Something very weird. Hope they’ve banged Ryan Baird up._

‘Anyone interested in something very weird at Coopers Chase?’ says Chris.

Yes. Everyone is.

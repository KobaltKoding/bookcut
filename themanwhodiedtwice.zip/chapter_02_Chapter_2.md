## 2

‘We were watching _Antiques Roadshow_ the other night,’ says DCI Chris Hudson, drumming his fingers on the steering wheel. ‘And this woman comes on, and she’s got these jugs, and your mum leans over to me and says –’

PC Donna De Freitas slams her head against the dashboard. ‘Sir, I am begging you. I am literally begging you. Please stop talking about my mum for ten minutes.’

Chris Hudson is supposed to be mentoring her, smoothing her eventual path into CID, but you wouldn’t know it from the almost total disrespect with which they treat each other, or, indeed, from their friendship, which had blossomed the moment they met.

Donna had recently introduced Chris, her boss, to Patrice, her mum. She thought they might get along. As it turned out, they are getting along a little bit too well for her liking.

Stakeouts with Chris Hudson used to be more fun. There would be crisps, there would be quizzes, there would be gossip about the new DS who’d just started at Fairhaven and had accidentally sent a picture of his penis to a local shopkeeper who was asking for advice on security grilles.

They’d laugh, they’d eat, they’d put the world to rights.

But now? Sitting in Chris’s Ford Focus on a late-autumn evening, keeping a watchful eye on Connie Johnson’s lock-up? Now Chris has a Tupperware container filled with olives, carrot batons and hummus. The Tupperware container bought by her mum, the hummus made by her mum and the carrot batons sliced by her mum. When Donna had suggested buying a KitKat he’d looked at her and said ‘empty calories’.

Connie Johnson was their friendly local drug dealer. Well, Connie was more a drug _wholesaler_ these days. The two Antonio brothers from St Leonards had controlled the local drug trade for some years, but they had gone missing around a year ago and Connie Johnson had stepped into the breach. Whether she was just a drug wholesaler, or whether she was a murderer too, was open to question, but, either way, that’s why they were spending their week sitting in a Ford Focus, training binoculars on a Fairhaven lock-up.

Chris has lost a bit of weight, he has had a nice haircut, and is now wearing a pair of age-appropriate trainers – everything Donna had ever told him to do. She had used all the tricks in the book to encourage him, to convince him, to cajole him into looking after himself. But it turned out that, all along, the only real motivation he needed to change was to start having sex with her mum. You have to be so careful what you wish for.

Donna sinks back into her seat and puffs out her cheeks. She would kill for a KitKat.

‘Fair enough, fair enough,’ says Chris. ‘OK, I spy, with my little eye, something beginning with Y.’

Donna looks out of the window. Far below she sees the line of lock-up garages, one of which belongs to Connie Johnson, the new drugs kingpin of Fairhaven. Queenpin? Beyond the lock-ups is the sea. The English Channel, inky black, moonlight picking out gentle waves. There is a light on the horizon, far out to sea.

‘Yacht?’ says Donna.

‘Nope,’ says Chris, shaking his head.

Donna stretches and looks back towards the row of garages. A hooded figure on a BMX bike rides up to Connie’s lock-up and bangs on the door. They can hear the faint metallic thunder even up on the hill.

‘Youth on bicycle?’ says Donna.

‘Nope,’ says Chris.

Donna watches as the door opens and the boy walks inside. All day, every day, this was happening. Couriers in and out. Leaving with coke, Es and hash, coming back with cash. It was non-stop. Donna knows they could raid the place right now and find a nice little haul of drugs, a bored middleman sitting at a table and a youth on a bicycle. But, instead, the team were biding their time, taking photographs of whoever walked in or out, following them wherever they were going, trying to build up a full picture of Connie Johnson’s operation. Gathering enough evidence to take the whole thing down in one go. With any luck there would be a series of dawn raids. With a bit more luck they would have a tactical support group armed with pneumatic battering rams to smash a few doors down and one of the tactical support officers would be single.

‘Yellow jacket?’ says Donna, seeing a woman walking along the high path towards the car park.

‘Nope,’ says Chris.

The big prize was Connie Johnson herself. That’s why she and Chris were there. Had Connie murdered two rivals and got away with it?

Occasionally, among the youths on bicycles they would see more familiar faces. Senior figures from the Fairhaven drug scene. Every name was noted. If Connie had murdered the Antonio brothers, then she hadn’t done it by herself. She was no fool. Sooner or later, in fact, she would notice she was being watched. Then things would become less blatant, harder to track. So they were getting all their evidence lined up while they could.

Donna jumps as a knuckle raps on her side window. She turns and sees the yellow jacket of the woman who had been walking along the path. A smiling face appears at the window and holds up two cups of coffee. Donna registers the shock of blonde hair and the smear of red lipstick. She winds down her window.

The woman crouches, then smiles. ‘Now, we haven’t been introduced, but I think you’re Donna and Chris. I bought you coffees from the garage.’

She hands the coffees over, and Donna and Chris look at each other and take them.

‘I’m Connie Johnson, but I think you know that,’ says the woman. She pats the pockets of her jacket. ‘I also bought sausage rolls, if you’d like one?’

‘No, thank you,’ says Chris.

‘Yes, please,’ says Donna.

Connie hands Donna a sausage roll in a paper bag. ‘I’m afraid I didn’t buy anything for the policewoman hiding behind the bins, taking all the photographs.’

‘She’s vegan anyway,’ says Donna. ‘From Brighton.’

‘Anyway, just wanted to introduce myself,’ says Connie. ‘Feel free to arrest me any time.’

‘We will,’ says Chris.

‘What’s your eye-shadow?’ Connie asks Donna.

‘Pat McGrath, Gold Standard,’ says Donna.

‘It’s lush,’ says Connie. ‘Anyway, business all done for today if you wanted to go home. And you haven’t seen anything I didn’t want you to see for the last two weeks.’

Chris sips his coffee. ‘Is this really from the garage? It’s very good.’

‘They’ve got a new machine,’ says Connie. She reaches into an inside pocket, takes out an envelope and hands it to Donna. ‘You can have these. There’s photographs of you in there, photographs of all the other officers you’ve had crawling around, too. Two can play at that game. Bet you didn’t see anyone take them, eh? Followed a few of you home too. They took a nice one of you on a date the other day, Donna. You can do better, that’s my opinion.’

‘Yep,’ says Donna.

‘I’ll be on my way, but nice to finally say hello in person. I’ve been dying to meet you.’ Connie blows them a kiss. ‘Don’t be strangers.’

Connie straightens up and walks away from the Ford Focus. Behind them a Range Rover appears. The passenger door is opened and Connie climbs in and is driven away.

‘Well,’ says Chris.

‘Well,’ agrees Donna. ‘What now?’

Chris shrugs.

‘Great plan, boss,’ says Donna. ‘What was your I spy? Something beginning with Y?’

Chris turns his key in the ignition and puts on his seatbelt. ‘It was your mother’s beautiful face. I see it every time I close my eyes.’

‘Oh, Christ,’ says Donna. ‘I’m asking for a transfer.’

‘Good idea,’ says Chris. ‘Not until we’ve nicked Connie Johnson though, eh?’

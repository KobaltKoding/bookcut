## 82

## Joyce

So Alan will be with me next week!

The rescue centre have to come and visit the flat, just to check that I’m a fit and proper person. I certainly think I am, but it will be nice to have it confirmed.

I am glad they didn’t come round last week. Sue had bled all over the kitchen floor, there were millions of pounds’ worth of diamonds on the kitchen table and Bogdan was storing three guns under the spare-room duvet. I don’t know what the rules are for ‘fit and proper’, but I imagine I would have been breaking one or two of them there.

And, by the way, yes, it is Alan, not Rusty. They let us take him for a walk around the grounds, and Ibrahim read the riot act to me. And it does suit him, to be honest.

We got on like a house on fire. Ibrahim tried to make him sit, but Alan was having none of it, just happily chasing his tail instead. A dog after my own heart.

I took a picture of him while we were there, to show Elizabeth and Ron. They both said he looked like trouble, which I know they both meant as a great compliment.

Anyway, that photo is @GreatJoy69’s Instagram profile picture now, so people can judge Alan for themselves. And, by the by, Joanna solved the mystery of my private messages. She went into my account and searched all of them for me. She told me that if I didn’t want to be sent an endless tide of photographs of men’s genitals, I should really change my username.

Needless to say, I haven’t changed it.

I know I said I wanted something to happen. Do you remember? And it has been fun, for the most part.

Except for Poppy.

We met her real mum yesterday, she actually is called Siobhan, which I suppose was all part of the plan. Elizabeth and I sat with her and talked about Poppy and she and I cried. She had to identify the body, which had already been identified. The scars on the back of her leg had actually come from a car accident when she was very young. Siobhan had lots of photographs, and we looked through them together.

Elizabeth gave Siobhan the poetry book, which had been on Poppy’s bedside table in Hove. The bookmark was left where it was, on a poem called ‘An Arundel Tomb’.

Arundel is not too far from Brighton. Gerry and I once went antiquing there. This was before there were Starbucks, but we went to a nice tea room.

Poppy’s funeral is next week, and we will all be there. Ron is taking flowers for the real Siobhan. Ever the optimist. Ibrahim is driving us.

Elizabeth got a bit upset that Douglas had told Sue to stick close to her if she wanted to find the diamonds. Not that it was any sort of big deal, Elizabeth said, but she couldn’t help feeling a bit betrayed. I laughed and asked her if she had not worked it out? Douglas told Sue to stick close to her, because he knew Elizabeth would eventually catch her out. She took my point and cheered up a little.

Maybe a bit of peace and quiet would be nice now. Just for a bit? Joanna is popping down at the weekend. She’s bringing the football chairman down with her, and I am making lunch. I have invited Ron over too, because he will know what to talk about.

I asked Ron what football chairmen ate, and he said ham, egg and chips. Luckily I know Ron’s games, so I am doing a roast.

I will tell them everything that’s been going on, except what happened to the diamonds. That’s just between Elizabeth, Ibrahim, Ron and me. We decided together, and it’s our little secret. We all need secrets, don’t we?

Speaking of which, I have one more secret, which you mustn’t tell anyone. I haven’t even told Elizabeth. I went down to Fairhaven last Wednesday, and there’s a little place near the pier. We must have been close to it when everyone was being shot. I’d booked an appointment. I didn’t know if you had to, especially on a Wednesday.

It took the lady a few hours, and it still hurts a bit now, but it was worth it. I never wear sleeveless dresses, not with my arms, so no one will ever see it. Unless I get lucky. It’s at the top of my left arm, and ever so pretty.

Just a small tattoo of a poppy.

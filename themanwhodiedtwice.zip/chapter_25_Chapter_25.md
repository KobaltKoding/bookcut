## 25

Elizabeth and Joyce are on St Albans Avenue. It is a road full of small hotels and retirement homes. You could walk the whole length of it without once feeling the need to look up from your phone, and that was perfect. They reach number 38\. Blinds drawn in all the rooms facing the street, and a four-year-old ‘Vote Lib Dem’ poster in the front window. Absolutely textbook.

There is a Virgin Media van parked across the road and Elizabeth knocks on the window. She is expected.

The driver folds her newspaper, lowers her window and raises an eyebrow.

Elizabeth repeats exactly what she has been told to say. ‘My reception is on the blink and I don’t want to miss _Love Island_.’ Someone in MI5 will have enjoyed thinking that one up for her.

The driver replies, as expected. ‘You number 42?’

Elizabeth nods.

‘That’s Sky, not Virgin.’

‘Sorry to trouble you,’ says Elizabeth, and reaches in to shake the driver’s hand. As they shake, she feels the key being pressed into her hand. The driver raises her window again and returns to her paper. A very boring job. Elizabeth sympathizes. At least the driver has a paper. There were times in eastern Europe, on twelve-hour watches, where Elizabeth would have killed for a _Daily Telegraph_. Even a _Daily Mirror_.

They cross the road towards the house.

‘Was that spy talk?’ asks Joyce. ‘Code?’

‘Very basic code, yes. Just an identifier.’

‘Joanna watches _Love Island_. She says I’d love it. Men, and what have you.’

There is a ‘No Junk Mail’ sticker on the front door. The door looks normal from the outside, but Elizabeth knows it will have steel reinforcements behind it, should anyone get any ideas. The key looks perfectly normal, but is electronic, and the moment it is slipped into the lock there are a series of noises from inside the house, faint enough that they wouldn’t be heard from the street.

The door opens and Elizabeth looks at her watch: 5.25\. Ron should have picked up the package by now.

Douglas had said to meet them at five, but it wouldn’t do any harm for Douglas to be kept waiting every now and again. Quite what she was doing there was a mystery. It was odd enough that Douglas had chosen to hide at Coopers Chase. Odder still that he wanted to see Elizabeth again, now that Coopers Chase was no longer an option.

Elizabeth could have said no, but something was going on here, and she wouldn’t at all mind finding out what it was. It was one of Douglas’s games, no doubt, but sometimes Douglas’s games had been fun. Certainly worth seeing if he had one good one left in him.

Especially with twenty million pounds at the end of the rainbow. Think what you could do with twenty million pounds? But Elizabeth doesn’t need to think. She knows exactly what she would do with it.

They walk over the threshold.

‘I like their hall carpet,’ says Joyce. Her voice echoes around the silent house. ‘We nearly had similar.’

It shouldn’t be silent, of course, with two people living here. Were they both sleeping? At 5.25? Unlikely.

Elizabeth feels a breeze. A breeze in a house where every door and window is shut. Bolted and sealed shut.

‘Douglas?’ calls Elizabeth. ‘Poppy?’

Elizabeth steps into the kitchen. It is neat. There is a small table and two wooden chairs. There are two bowls and two mugs by the sink. An old calendar on the wall, British castles.

There is a back door, which leads onto a courtyard garden. Barbed wire atop a brick back wall.

The back door is wide open.

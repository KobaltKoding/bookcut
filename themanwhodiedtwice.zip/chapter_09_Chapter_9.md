## 9

Elizabeth is finding it hard to focus. After seeing Ibrahim in the bed yesterday evening, hooked up to tubes, just as Penny had been. She doesn’t want to lose anyone else.

She has to keep her wits about her though. She is walking through the woods, high above Coopers Chase, with Douglas Middlemiss. Her ex-husband and her new responsibility. A job she never asked for. People died around Douglas. Too many people.

Why had she married him? Well, he had asked at around about the time she felt she ought to get married. And, dangerous though he was, he could also be kind. Pretend to be, at least. And it wasn’t as if she hadn’t killed a few people in her time, too. If Ryan Baird were in front of her now she would probably add another one to her list.

Trailing quite happily behind them is Poppy, headphones on. That had been the compromise. Poppy would need to keep Douglas in her sight, but Douglas would be able to speak freely to Elizabeth.

‘It was as routine as these things can be,’ says Douglas. ‘We took our photos, broke into whatever we could break into, and off we toddled. Couldn’t have been in Lomax’s house more than half an hour. He rarely goes out, so we had to be quick.’

Elizabeth stops for a moment to take in the view, Coopers Chase below her, the buildings, the lakes, the rolling fields. Above her, the cemetery where the nuns, who had previously called this place home for centuries, were buried. Still behind them, Poppy halts too and takes in the same view.

‘And you messed up somehow?’

‘I don’t know about messed up exactly, but two days later we get a message, through certain channels. Martin Lomax has been in touch.’

‘Has he now?’ says Elizabeth, as they resume their walk. ‘Do go on.’

‘Effing and blinding, they say. You broke into my property, human rights, flagrant disregard, the whole shooting match. Guts for garters, you know the routine.’

‘And how did he know it was MI5?’

‘Well, a hundred ways, I suppose. You never really leave things exactly where you found them, do you? If someone knows what they’re looking for. And who breaks in without stealing anything? Only us, dear, in this day and age.’

There is construction noise from further up the hill, where the final part of the Coopers Chase development is being built. Douglas stops by an old oak with a hollow pocket in its trunk. He pats it.

‘Perfect dead-letter drop, this, eh?’ he says.

Elizabeth looks at the oak and agrees. She has had dead-letter drops all over the world. Behind loose bricks in low walls, hooks under park benches, obscure books in old shops, anywhere one agent could hide something completely, and another could pick it up without suspicion. This tree would be perfect, were it in Warsaw or Beirut.

‘You remember the tree we used in East Berlin? In the park?’ asks Douglas.

‘West Berlin, but yes, I remember,’ says Elizabeth. Almost ten years older, but memory sharper, she would take that victory.

They stop admiring the tree and Douglas continues.

‘So Lomax is shouting the odds, and he’s got us buggered all ways to Wednesday because we shouldn’t have been in there, and he knows that and we know that, and then he drops the bomb.’

‘The bomb?’

‘The bomb.’

‘And this bomb is why you’re here?’

Douglas nods. ‘There he is, Martin Lomax, firing both barrels and reloading, and then he says, “Where are my diamonds?”’

‘Diamonds?’

‘Stop just repeating what I said last, Elizabeth, it’s a terrible habit of yours. That and adultery.’

‘So these diamonds, Douglas?’ says Elizabeth, not breaking stride.

‘Says he had twenty million pounds’ worth of diamonds in the house. Uncut. Down payment from a businessman in New York to a Colombian cartel.’

‘And they disappeared after your visit?’

‘Thin air, says our man. Accusing us of I don’t know what, seeking reparation, yelling the ceilings off. So I get hauled in – quite right too, protocol, no complaint from me – and I take them through the operation, me and another chap, Lance, Special Boat Service, trustworthy, MI5 likes him. Poppy outside on lookout duty, waiting for the hunters to emerge. No diamonds seen, no diamonds taken, chap must be bluffing.’

‘And they believed you?’

‘No reason not to. We could all see the game he was playing. Getting a bit of leverage over us. So back they go to Martin Lomax, sorry we broke in, just doing our job, but come off it with the diamonds old boy, and let’s find a way to be friends.’

‘And he is unamenable to this?’

‘The definition of it. Swears this is no bluff, tells us he’s got Colombians ready to break this leg and that leg if they don’t get their diamonds back, and what are we going to do about it?’

‘And what did you do?’

‘Nothing we can do. They kept at me and the rest of the team for a couple of days, just to make sure we were telling the truth, then they report back and tell Martin Lomax, look, friend, if the diamonds ever existed at all, which frankly we doubt, then someone else has them. There’s a bit of back and forth, and then he drops another bomb.’

‘Goodness me, Douglas,’ says Elizabeth. ‘Two bombs.’

‘Martin Lomax says, “I’m sending over a photograph,” and through it comes, CCTV, a shot from the side of his house, it’s yours truly, full face, clear as a bell, mask off.’

‘You took your mask off?’

‘I was hot, it was itchy, you know me, Elizabeth, and the balaclavas are synthetic these days. Whatever happened to wool is something I would like to know. So there’s my face, and he’s done his research, knows who I am, and under the photograph he writes “Tell Douglas Middlemiss he has two weeks to return my diamonds. If the diamonds haven’t been returned within two weeks then I will tell the Americans and the Colombians that he has them.” Kind regards, and so on.’

‘And when was this?’

Douglas stops, looks around and nods to himself. He then looks at Elizabeth.

‘Well, this was two weeks ago.’

Elizabeth purses her lips. They have broken through the cover of the trees now, and find themselves by the path leading to the nuns’ cemetery. She motions to a bench up ahead.

‘Shall we?’

Elizabeth and Douglas walk over to the bench and take a seat.

‘So you are now being hunted by the New York mafia and by a Colombian drug cartel?’

‘Never rains but it pours, eh, darling?’

‘And the Service have sent you here to keep you safe?’

‘Well, if I may be honest, that was my bright idea. I’d been reading about you, about your recent escapades, and about this place, Coopers Chase, and it struck me as the perfect place to hide.’

‘Well, depends what you’re hiding,’ says Elizabeth, looking up at the cemetery. ‘But yes.’

‘So you’ll help look after me? Mobilize some of the troops around here? Keep them alert to stranger danger, but don’t tell them why? I’ll only be here until this sorts itself out.’

‘Douglas, you have no incentive to give me an honest answer to this, but, just so I’ve asked, did you steal the diamonds?’

‘Of course I did, darling. They were just sitting there. Couldn’t resist.’

Elizabeth nods.

‘And I need you to keep me safe long enough so I can pick them up, take them to Antwerp and cash them in. Thought I’d stumbled across the perfect crime, didn’t I? If I hadn’t taken that stupid mask off I’d be in Bermuda already, I assure you.’

‘I see,’ says Elizabeth. ‘And where are the diamonds now, Douglas?’

‘Keep me alive, my darling, and I’ll tell you,’ says Douglas. ‘Ah, here’s our friend Hermione Granger.’

Poppy has reached the bench. She motions to her headphones, asking if it’s safe to take them off. Elizabeth gives her a nod.

‘I hope you enjoyed the walk, dear?’ asks Elizabeth.

‘Very much,’ says Poppy. ‘We used to do hiking at uni.’

‘What were you listening to? Grime music?’

‘A podcast about bees,’ says Poppy. ‘If they die, we’re doomed, I’m afraid.’

‘Then I shall be more careful in future,’ says Elizabeth. ‘Now, Poppy, Douglas has persuaded me to accept the position you are offering. I imagine I can be helpful.’

‘Oh, terrific,’ says Poppy. ‘That’s a relief.’

‘I have two caveats, however. Firstly, this task, keeping an eye out and so on, will be so much easier to perform with my three friends to help me.’

‘That’s impossible, I’m afraid,’ says Poppy.

‘Oh, my dear, as you get older you’ll realize very few things are impossible. Certainly not this.’

‘And the second thing?’ asks Douglas.

‘Well, the second thing is very important. More important than diamonds, and more important than Douglas. If I’m to accept this job, then I need a favour from MI5\. A simple favour, but one that will mean a great deal to me.’

‘Go on?’ says Poppy.

‘I need all the information you have on a teenager from Fairhaven named Ryan Baird.’

‘Ryan Baird?’ says Douglas.

‘Oh, Douglas, stop repeating what I last said, it’s a terrible habit of yours. That and adultery.’

Elizabeth stands and crooks an elbow so Poppy can take her arm.

‘Could you do that for me, dear?’

‘I mean I suppose I _could_,’ says Poppy. ‘Can I ask what it’s for?’

‘I’m afraid not, no,’ says Elizabeth.

‘Then can you promise me this Ryan Baird won’t come to any harm?’

‘Oh “promise” is such a big word, isn’t it? Let’s all have a nice walk home. I don’t want you to be late for your lunch shift.’

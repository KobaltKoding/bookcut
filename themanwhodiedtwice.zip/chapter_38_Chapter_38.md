## 38

Ibrahim had suggested they hold the evening at his place. He feels pressured at the moment to get out of the flat. To do things. Ron has suggested they go for ‘a walk’ sometime. Ron! They are worried about him, and Ibrahim isn’t enjoying the feeling. Ibrahim likes to be no trouble. Ibrahim feels like he is beginning to melt away and, right now, that’s fine by him.

‘Do you know I have a theory?’ says Elizabeth, already three glasses of wine to the good.

‘You surprise me, Elizabeth,’ says Sue Reardon. Sue has a glass of wine too, despite this, officially speaking, being business for her. Perhaps she is oiling the wheels? She will be no match for Elizabeth, regardless.

‘Some people in life, Sue, are weather forecasters, whereas other people are the weather itself.’

Elizabeth had rung Sue on the way back from Hambledon, and wondered if she might be free to pop over for a chat? Sue had been delighted to, and had driven straight down. Ibrahim had ordered in Domino’s pizza.

‘My favourite weather forecaster is Carol Kirkwood on the BBC,’ says Joyce. ‘I always think we’d get on.’

Joyce had popped round half an hour before the rest, and she and Ibrahim had looked at dogs on the internet. Joyce is on Instagram now too, and was trying to engage him in that. He was losing interest, but then Joyce showed him some videos of a woman solving cryptic crosswords.

‘The weather forecasters,’ continues Elizabeth, ‘and here that’s me and Ibrahim, we always have our fingers in the air trying to feel which way the wind is blowing. We never want to be surprised or caught out.’

True, thinks Ibrahim.

‘You’ll feel the way my wind is blowing in a minute,’ says Ron, lounging back on one of Ibrahim’s armchairs, finishing a slice of pizza before dunking a chocolate digestive into his red wine.

‘Whereas Joyce and Ron, you are the weather,’ says Elizabeth. ‘You move as you choose, you act as you feel. You make things happen without fannying around worrying about what those things might be.’

‘You can’t predict things,’ says Ron. ‘Why try?’

‘But you can predict things,’ says Ibrahim. ‘The tides, the seasons, nightfall, daybreak. Earthquakes.’

‘None of that is people, though, mate,’ says Ron. ‘You can’t predict people. Like you can guess what they’ll say next, but that’s about it.’

Ibrahim is back in the gutter for a moment, tasting blood. He tries to shake it off.

‘There’s no point overthinking anything,’ says Joyce. ‘I agree with Ron.’

‘Well, of course you agree with Ron,’ says Elizabeth, finishing her glass. ‘The two of you are peas in a pod.’

‘How many times do you ring me, Elizabeth, first thing in the morning, and say, “Joyce, we’re going to Folkestone,” or, “Joyce, we’re going to an MI5 safe house”? “Joyce, pack a flask, we’re going to London”?’

‘A lot,’ admits Elizabeth.

‘And do I ever ask why?’

‘Well, there’s no point, darling, I would never tell you.’

‘So I just pack my bits and bobs, look up the train times and off we go. I always know it’s going to be fun. No overthinking.’

‘Yes, but it’s always fun because I plan it,’ says Elizabeth. ‘You just have to worry about whether to put on a big coat.’

Ibrahim sees Sue risk a peek at her watch. When are they going to get to the good stuff? That’s what she’s thinking. What does Elizabeth know? Does she know where the diamonds are? That’s why Sue had driven down through the dusk. Good luck to you, Sue.

‘Let me tell you this,’ says Elizabeth to the room, clearly not planning to talk about diamonds any time soon. ‘The first trip I ever went on with Stephen was to Venice. He wanted to look at the art and the churches for a weekend, and I wanted to look at him for a weekend.’

‘That’s romantic,’ says Joyce.

‘Looking at a man you love isn’t romantic, Joyce,’ says Elizabeth. ‘It’s just the sensible thing to do. Like watching a television programme you like.’

Ibrahim nods.

‘Anyway, on the way over Stephen had said, let’s do the whole weekend without guide books, let’s just wander, let’s get lost, let’s turn a corner and see magic we didn’t know was there.’

‘OK, well, _that_ is romantic,’ says Joyce.

‘No, that’s not romantic either, that’s deeply inefficient,’ says Elizabeth.

‘Agreed,’ says Ibrahim. Look where spontaneity has got him.

‘I know Stephen. I know Stephen won’t be happy unless he sees Tintoretto’s _Golden Calf_, and Bellini’s altarpiece at the San Zaccaria. Unless he finds a beautiful hidden bar serving cicchetti and spritzers to locals. He doesn’t want to turn left and find a local government office, or turn right and find an alleyway full of heroin addicts who steal his watch.’

‘I’m sure that wouldn’t happen,’ says Joyce.

‘Well, of course it wouldn’t happen,’ says Elizabeth. ‘Because I’d spent the previous two weeks studying every guide book under the sun. So off we strolled, arm in arm, wandering aimlessly, me with a perfect map in my head, and we were lucky enough to stumble across the San Francesco della Vigna, what a pleasant surprise! And then we were fortunate to pass in front of a beautiful little bar I’d seen Rick Stein in on BBC2 …’

‘Ooh, I like Rick Stein,’ says Joyce. ‘I don’t like sea-food, but I do like him.’

‘And then, lo and behold, we turned a corner and found ourselves in the Madonna dell’Orto, and we’re up to our ears in Tintorettos and Bellinis. It was the perfect trip and, as far as Stephen was concerned, the whole weekend was one magical accident. And that’s because he is the weather, and I am the weather forecaster. He believes in fate, while I _am_ fate.’

‘Gerry and I never used to plan our weekends away,’ says Joyce. ‘And we always had a wonderful time.’

‘That’s because Gerry planned them and never told you,’ says Elizabeth. ‘Because things are more fun for you when they’re not planned, and they were more fun for him when they were planned. It’s best to have one of each in every relationship.’

‘That’s not true,’ says Ron. ‘Marlee and me were both weather.’

‘You got divorced twenty years ago, Ron,’ says Ibrahim.

‘True,’ says Ron, raising his glass a touch.

‘I don’t wish to be a party pooper,’ says Sue Reardon. ‘But are you going somewhere with this, Elizabeth?’

She is trying to hurry things along a bit, thinks Ibrahim. But Elizabeth will go at her own pace.

‘Why would I be going somewhere with it?’ asks Elizabeth.

‘Because you asked me down here this evening. And now you’ve taken me by the hand, you’ve led me left and right. And I just wondered, where are we going? What’s around the next corner? Why do I feel I’m being led into an alleyway full of heroin addicts?’

‘Well, you’re not,’ says Elizabeth. ‘You’re eating pizza in a room full of doddery pensioners, what harm could possibly come to you? I was only making conversation.’

Joyce snorts, and she and Ron roll their eyes at each other.

‘Out with it,’ says Sue.

‘Well, it really is nothing, except, we went to see Martin Lomax today.’

‘Did you now?’

‘I’m afraid so, yes,’ says Elizabeth. ‘And we are minded to think he didn’t kill Douglas and Poppy.’

‘I see,’ says Sue.

‘Although I wasn’t there,’ says Ibrahim. ‘On account of my bruising. I would love to have been otherwise.’

You liar. He didn’t want to go out. He didn’t want to stay in. What was left for him? He was enjoying this evening, at least.

‘And it all started me thinking about Douglas in a little more detail. I don’t know if you knew him all that well?’

‘Well enough,’ says Sue.

Elizabeth nods. ‘Well, you would think he was the weather, wouldn’t you? The way he just blows through people’s lives. Having affairs and divorcing people, left, right and centre. But he’s not. Douglas was a weather forecaster. Douglas planned everything. If Douglas sent me a message saying he had something to show me, then he had something to show me. And if he was going to show me it at five, he’d be damned sure he was still alive at five. Douglas was very, very careful with words.’

‘What are you saying?’ says Sue.

‘I’m saying, what if Douglas showed me exactly what he wanted to show me? He wanted me to see his dead body?’

‘Just like Marcus Carmichael,’ says Joyce.

‘Who’s Marcus Carmichael?’ asks Ibrahim.

‘Well, quite,’ says Elizabeth, wiping orange fingers on a white serviette. ‘Sue, can I ask you something? I imagine you’ll have thought of it already, but regardless?’

‘Anything you like,’ says Sue. ‘Who is Marcus Carmichael?’

‘Look him up, there’ll be a file,’ says Elizabeth. ‘How was Douglas’s body identified?’

‘Oh, here we go,’ says Ron, and takes a swig of his red. ‘I knew you had something up your sleeve.’

‘Meaning, was the body definitely Douglas?’ asks Sue.

‘Meaning precisely that,’ says Elizabeth.

‘You think he faked the whole thing, and took off with the diamonds?’ says Ron.

‘I think it’s a possibility,’ says Elizabeth.

‘You must have faked some deaths over the years, Sue?’ says Joyce.

‘One or two,’ agrees Sue. ‘Douglas was wearing the clothes he was last seen in, he had his wallet, all his cards and so on, but of course he would.’

‘Of course,’ says Elizabeth.

‘But these days it’s all done on DNA matches if there’s no next of kin. The doctor took a swab, the lab matched it to his file. It was Douglas.’

Elizabeth drinks and thinks. Eventually she nods. ‘Those two statements don’t follow, Sue, you know that. If Douglas had a plan, he had a plan. If he needed the DNA to match then it would.’

‘True,’ agrees Sue.

‘So who there could have tampered with the DNA? Anyone?’

Sue thinks. ‘I could have done, Lance could have done, at a push, the doctor could have done – she wasn’t our usual, but she’s very experienced. I suppose someone in the lab? We do it all on-site now.’

‘Forty years of nursing teaches you it’s always the doctor,’ says Joyce, reaching for the white wine to top up her glass.

‘So it’s possible it’s not Douglas?’ asks Elizabeth.

‘It’s possible, yes. It would take an unlikely chain of events, but it’s possible,’ says Sue.

‘But that’s what good plans are, isn’t it?’ says Elizabeth. ‘A trail of events so unlikely it throws you off the scent. Who would go to all that trouble? That’s how I would get away with something, that’s how you would get away with something, and that’s how Douglas would get away with something. Make it … complicated.’

‘He was probably having an affair with the doctor,’ says Joyce. ‘He had affairs with everyone, Sue. No offence, Elizabeth.’

Sue drums her fingers. ‘OK, let’s say for a moment that you’re right, Elizabeth.’

‘That usually saves time,’ says Ron.

‘Why would Douglas want you to see the whole thing? To see his body? If I was faking my own death, I’d keep you as far away from the scene as I could.’

‘I agree with Sue here,’ says Ibrahim. ‘You would be the first to work it out.’

‘Something to do with the diamonds?’ asks Sue. ‘He needed your help with them?’

‘Who knows?’ shrugs Elizabeth. ‘Although if I’m right that he is still alive, then he didn’t _need_ my help, he _needs_ my help.’

Sue nods.

‘Joanna has bought me Netflix,’ says Joyce, finishing her last slice of pizza. Where does she put it all, Ibrahim wonders. ‘There’s all sorts on it, but I can’t work out what’s on when. It doesn’t have the times anywhere.’

‘And will you help him?’ Sue asks Elizabeth.

‘No,’ says Elizabeth. ‘I will try to find the diamonds, of course, but Douglas is on his own, I’m afraid. Don’t you agree? If he’s done what I think he’s done? If he killed poor Poppy, and faked his own death?’

‘That’s a big “if”,’ says Ron.

‘I do agree,’ says Sue. ‘So, if you’re right, then what? He’s left you a clue? I know you wanted to look inside that locket we gave you. But something less obvious than the locket? Some_where_ less obvious?’

‘I mean, who knows?’ says Elizabeth. ‘But, yes, I am working on that assumption. I wanted to make sure you didn’t think my theory was too outlandish first.’

‘It’s outlandish,’ says Sue. ‘But there’s no such thing as too outlandish in this job. I’m going to head straight back and have a quiet look into the process, without ringing any alarm bells. I can keep the investigation ticking along for a few days, while we have a think about all this.’

‘I think Douglas has hidden the diamonds somewhere,’ says Elizabeth. ‘And I know at some point he has told me exactly where. I just have to remember how and when he told me.’

‘Then we both have a job to do,’ says Sue. ‘I can probably buy you about three days.’

‘I still say the mafia and Lomax did it,’ says Ron. ‘Size of that geezer’s house.’

‘I still say the doctor,’ says Joyce.

‘Do you know,’ says Sue, ‘if you’d told me three months ago I’d be working with Elizabeth Best, I would never have believed you. And now here we are.’

Joyce reaches for a bottle and refills Sue’s glass. ‘Welcome to the Thursday Murder Club!’

They clink glasses. The rest of the evening passes very pleasantly. A few war stories are told, Sue changing names and dates where necessary and Elizabeth not bothering to. Sue is wearing the friendship bracelet Joyce had given her – always good to curry favour when you’re looking for information, Ibrahim supposes. Joyce gives Sue an envelope to give to Lance. Eventually, Sue yawns the yawn of someone looking to leave.

‘You’ll tell me if something occurs to you?’ asks Sue.

Elizabeth nods vigorously. ‘You’ll be the first to know when I do. He might want me to help him, but, on the whole, I would rather catch him.’

Douglas faking his death? Ibrahim likes the theory. He can see that Sue does too. It was implausible, but possible. The perfect combination.

‘Right, I’ll be making tracks,’ Sue says. ‘You know where I am.’

‘And look into the doctor, please,’ says Joyce.

‘I will,’ says Sue.

As Sue leaves, the four friends settle again. Wine glasses are refilled. Ron nips to the loo.

‘Talking to Sue was a good thing to do,’ says Ibrahim to Elizabeth. ‘I know you usually like to keep these things close to your chest.’

‘I needed to hear about the identification process,’ says Elizabeth. ‘See if it was watertight. And it wasn’t.’

‘Ooh, she reminds me of you,’ says Joyce. ‘Twenty years younger, no offence.’

‘None taken,’ says Elizabeth. ‘She reminds me of me, too. Not _as_ good, but not bad.’

‘So you think she’ll be able to work out where Douglas left his clue?’ says Ibrahim.

‘Oh, I know where he left it,’ says Elizabeth. ‘I realized this morning.’

Ibrahim nods. But of course.

‘I knew you were hiding something,’ says Ron, coming back into the room. ‘Poor Sue.’

‘I didn’t want to bother her with it,’ says Elizabeth.

‘Elizabeth, you are wicked sometimes,’ says Joyce with a smile.

‘And besides,’ says Elizabeth. ‘What if my hunch is wrong? Wouldn’t I look a fool then?’

‘When are your hunches ever wrong?’ says Ron.

‘Actually, quite often,’ says Joyce. ‘She just says them with confidence. She’s like a consultant.’

‘Absolutely, Joyce,’ says Elizabeth. ‘Could be right, could be wrong. But I wonder if anyone fancies a walk in the woods to find out for sure?’

‘Oh, here we go,’ says Ron, rubbing his hands.

‘Right now?’ asks Joyce. ‘Yes, please.’

‘You can’t go into the woods in your flip-flops, Ron,’ says Ibrahim.

‘Oh, stop being such a weather forecaster,’ says Ron, putting on his coat. ‘Off to the woods we go, old friends.’

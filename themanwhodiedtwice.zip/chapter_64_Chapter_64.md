![Penguin walking logo](./images/00005.jpeg) 


## 64

## Joyce

Well, guess who has just been on the Eurostar? Yours truly, Joyce Meadowcroft.

I tried to get Ibrahim to drive us to Ashford International, but he wasn’t having it. He blamed his ribs, but you can tell they’re a lot better. I saw him get a teapot from a high shelf yesterday. I’ll tempt him out at some point though, you see if I don’t.

There is a theory afoot, Elizabeth’s theory, but everyone seems to have bought into it, that Poppy is behind the murders. She found out that Douglas had stolen the diamonds and she wanted them for herself. So she hatched an elaborate plan, too elaborate if you want my opinion, to get them for herself.

It doesn’t seem right to me. Poppy was so gentle. Have I really got that wrong? Perhaps I have, I am quite trusting. There was a nurse at the hospital once who kept stealing morphine. And she wouldn’t say boo to a goose. Also there’s an actor in _Emmerdale_ who I love. I follow him on Instagram, and there are always pictures of his wife and his baby and his dog, and I always like them. Anyway, Jason was on _Celebrity Tipping Point_ with him, and said he was a nasty piece of work. He didn’t go into details but he said he knew one when he saw one, and that’s true with Jason, so I took his word for it. I still follow him on Instagram, but it’s not the same. He really does have a gorgeous kitchen though.

So maybe I was wrong about Poppy too. Maybe she did it. Twenty million pounds is a lot of money after all.

The idea is that she got Siobhan involved. Got her mum to identify the wrong body, and throw us off the scent. Which is possible. If Joanna asked me to pretend a dead body was hers I probably would. When it’s your child, you act first and ask questions later, don’t you? She once asked me to tell a boyfriend of hers that she’d moved to Guernsey, so I have some form. He was one of my favourites too. I follow him on Instagram now, and he has two lovely kids with a doctor. I think they are in Norwich, but don’t quote me. Also, don’t tell Joanna I follow him.

Where was I?

Eurostar! Yes. The seats are very comfortable, there is free tea, and you can plug your phone in. When we were in the Channel Tunnel I texted Joanna and said _Guess where your mum is?_, but she didn’t reply until this evening, and by that time I was in the taxi home from Robertsbridge station.

Have you ever been to Antwerp? I doubt it, but you never know. It is very pleasant. It has a cathedral, and we must have walked past eight or nine Starbucks. We had an appointment at two, with a man called Franco. Franco is a diamond dealer, and his workshop is in a long row of houses beside a canal, with steps leading up to them. There are small brass plaques by the doors. I thought there would be windows and windows full of diamonds, but no such luck. There was a cat in one window, but nothing more exciting than that.

Franco was gorgeous. I don’t think I really had an idea what Belgian people looked like before today, but if Franco is anything to go by I will keep my eye out in future. White-haired, tanned, blue eyes and half-moon glasses. I asked him if his wife worked with him and he said he was a widower. I put my hand on his, purely for comfort, and Elizabeth rolled her eyes.

Perhaps Poppy was murdered, perhaps Douglas was murdered, perhaps they both were? No one knows for sure, and that’s the point. But this is where the killer would have come to cash the diamonds in. Either to Franco, or to someone Franco knew.

He offered us both a glass of milk. I said yes, because I don’t remember the last time I had a glass of milk. Do you? As I drank it I was thinking, well, this might be the last glass of milk I ever drink, mightn’t it? I can’t see another situation where I will be offered one. Unless I were to marry a handsome Belgian. Which I am refusing to rule out.

Imagine if I married Franco? Imagine the ring! Imagine Joanna’s face. She is currently dating the chairman of a football club. He is always in the gym, and she has a spring in her step. I would walk down to the market and buy food for tea. Franco would be sitting there, glass of milk in hand, and I would ask how many diamonds he’d sold today (or something more technical once I’d got used to it all) and he would look down over those glasses and say something in Belgian. Yes, please. I wouldn’t mind that one bit.

I was glad I was wearing my new green coat from ASOS.

I’m waffling on, aren’t I? Though you would be too if you’d met him. Elizabeth asked him if Douglas had been to visit him, and Franco said he’d had a call about a month ago, telling him to expect a visit, but he hadn’t heard from him since. They are all obviously old pals from some escapade or other.

Then Elizabeth asked if anyone else had been to see him, with twenty million pounds’ worth of diamonds. He said no again.

To be on the safe side we described everyone we could think of. We described Poppy, we described Siobhan, we described Sue and Lance, we described Martin Lomax, we mentioned the mafia and the Colombian cartel, but nothing doing. No one like that had come to see him in the last two weeks.

I had another glass of milk, just to eke things out, but eventually we had to say goodbye. Franco kissed me three times, and I thought well, here we go, but then he kissed Elizabeth three times too, so that must just be what they do in Belgium.

We had to head back to the station, but, on the way, I bought some chocolate for Ibrahim and some beer for Ron. The shop even wrapped them nicely.

I thought we might sleep on the train back, but honestly we were talking. If Poppy was behind all this, then she would have come to Franco. There are very few places in Europe where you can cash in twenty million in diamonds with no questions asked. If Poppy has the diamonds, then perhaps she is lying low? And if she doesn’t have the diamonds, then she will still be looking for them. But where are they? Somewhere in Douglas’s letter is the answer. But we’ve read the letter, and Poppy has read the letter. Who will be the first to work it out?

It was quite a long journey back, so somewhere in northern France I unwrapped Ibrahim’s chocolates and we ate them, and then I unwrapped Ron’s beers and we drank them.

So, we need to find Poppy before she finds the diamonds. Elizabeth says she has a plan to flush her out.

I can see in the distance that her light is still on. That means she is thinking about Poppy.

May your light always be on, Elizabeth.

We are not telling Ibrahim for now that Ryan Baird has disappeared. We’re just saying the case is delayed. I hate to lie, but I can see the point.

Ron says Chris is in love with Patrice. Well, I should think so, too. I predict a happy ending there.

I am going to bed now. I know I should be thinking about Poppy and the diamonds. But instead I’m going to think about a big house by a canal, with stone steps, and brass plaques by the door.

You have to keep dreaming. Elizabeth knows that. Douglas knew it, too. Ibrahim has forgotten, but I’m here to remind him when the time is right.

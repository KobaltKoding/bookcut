## 19

Ron has skipped breakfast for this, and is even more furious than usual. He has spent some time looking at the large bloodstain on the bedroom carpet, and he now inspects the bullet hole in the bedroom wall.

‘I’ve seen liberties taken,’ says Ron. ‘God knows, they’ve all tried it on with me over the years, but this takes the whassname. When did you find the body? Half eleven? I was probably still up. I could have slipped on my shoes and been straight over. I swear, it’s not often I’m speechless, but I’m speechless. I wish I could speak, I wish I had words.’

Ron has had all the fun he’s going to have with the bullet hole, and starts pacing.

‘Ron, don’t pace over the bloodstains, please,’ says Elizabeth.

‘But no, who gets the call? Joyce. Of course, Joyce. Everybody loves Joyce.’

‘I don’t know about that,’ calls Joyce from the living room.

‘Including you, Ron,’ says Elizabeth.

‘I haven’t interrupted the two of you, so don’t interrupt me,’ says Ron. ‘There’s a dead body. A dead body, geezer shot in the head, and what do you do? You ring Joyce. You don’t ring Ron, dear me, no. Why would you ring Ron? He wouldn’t want to see a corpse, would he? Old Ron? Last thing he’d want to see. A bloodstain and a bullet hole will be enough for Ron. I’ve heard it all now.’

‘Are you finished?’ says Elizabeth, looking into her bag.

‘Take a guess, Elizabeth? Take a guess if I’m finished. Use those powers of deduction. No, I’m not finished. I would have loved it. _Loved_ it.’

‘Come with me,’ says Elizabeth.

Elizabeth walks into the living room and takes the armchair opposite Joyce. Ron follows her through. Elizabeth takes a folder from her bag and places it on her lap. Ron has a speech to make.

‘Here’s my promise to you,’ he begins. ‘With Joyce as my witness – and it’s not a promise friends should have to make – if I _ever_ find someone shot, I will call you. I will call you because you’re my mate, and that’s what mates do. Two in the morning, I don’t care, I find a corpse, I pick up the phone, “Elizabeth, there’s a corpse on the landing, on the bowls lawn, doesn’t matter where, slip on a pair of shoes and come and take a look.” I am absolutely _fuming_.’

‘Are you finished _now_, Ron?’ asks Elizabeth. ‘I’ve got something I need to talk to you about.’

‘Oh yeah? Well, what if I’ve got something to talk to you about? About friendship?’

‘As you wish,’ says Elizabeth. ‘But we don’t have an awful lot of time. We have a job to do.’

‘I’ve made you both a cup of tea,’ says Joyce. ‘Don’t be angry, but it’s herbal.’

Ron hasn’t finished though. ‘No apology, no “Sorry, Ron, spur of the moment, I panicked.” You think I see corpses every day of the week? Is that it? I’ve been in the hospital three nights, I get home, and this is my reward. You see a dead body, Joyce sees a dead body and I’m sat at home, watching some documentary with Portillo on a train. That is insult to injury, I’m sorry but it is. I thought we were friends.’

Elizabeth sighs. ‘Ron, I like you. It is a huge surprise to me, but I do. I respect you, too, in a number of areas. But listen to me, dear. I was in an operational situation. I had a man who had been seconds from death, a young girl who had just shot someone for the first time, I had a crime scene, and I had MI5 arriving any time. So I felt I needed another pair of hands. I knew that both of you would want to see the corpse, that was a given. So I was left with a simple choice between a woman with forty years of nursing experience and a man in a football top who would bang on about Michael Foot the moment MI5 arrived. Granted, thirty-odd years ago the job would still have gone to the man, but times change and I rang Joyce. Now, what can we do to calm you down?’

‘I’m already calm,’ shouts Ron.

‘My mistake,’ says Elizabeth.

‘Drink your tea,’ says Joyce.

Ron stops for a moment. ‘What do you mean, we’ve got a job to do?’

‘That’s better,’ says Elizabeth. ‘Ron, I took a folder out of my bag. Midway through your rant.’

‘It wasn’t a rant, but let me ring the Queen and get you a medal for taking a folder out of a bag.’

‘I did it quite slowly and deliberately. A buff-coloured folder, not the sort of thing I would normally carry in my bag. I thought you might notice.’

‘Joyce noticed, I suppose?’ says Ron. ‘Clever old Joyce?’

‘Well, yes she did, but the point is moot. Joyce hasn’t seen this folder yet. It’s just for me and you.’

‘Joyce hasn’t seen it?’ asks Ron.

‘Not yet, she can see it eventually,’ says Elizabeth. ‘But you and I have a job to do first.’

‘I’m not sure about this,’ says Joyce.

‘Oh, don’t you start,’ says Elizabeth. ‘I’m placating Ron.’

Ron nods. ‘OK. Sorry if I lost my rag there.’

‘You didn’t at all, dear. You voiced your frustrations, perfectly understandable.’

‘So what’s the job? What’s in the file?’

‘Don’t think it’s gone unnoticed that you stayed by Ibrahim’s side when he needed you,’ says Elizabeth. ‘And I think this is the reward you’ve earned.’

Elizabeth holds out the file and Ron reaches over and takes it.

‘It has Ryan Baird’s address, mobile telephone number, anything else you might need.’

Ron flicks through it, nodding. ‘So we’re going after him?’ he asks. ‘Straight away?’

‘You’re going after him, yes.’

‘I’m going after him?’

Joyce beams. ‘Wonderful.’

‘Yes, I thought you’d like to?’ says Elizabeth.

‘I would like to, yes,’ says Ron. ‘You got a plan?’

‘I do. I just need to see Bogdan about something first. Then you’ll get your instructions.’

Ron nods. He taps the file against one of his big hands. ‘Poppy get you this, did she?’

Elizabeth nods.

‘What’s going to happen to her? After blowing this geezer’s head off?’

‘She’ll be fine,’ says Elizabeth. ‘She did the right thing in the right way. They’ll question her today, get everything straight, then probably back to work.’

‘Will they let her see her mum, do you think?’ asks Joyce.

‘Goodness no,’ says Elizabeth. ‘Why would they let her see her mother?’

‘I think I’d want to see my mum if I’d just shot someone, wouldn’t you?’

‘It’s not kindergarten, Joyce; you’re always so sentimental,’ says Elizabeth.

Ron, still leafing through the file, looks up. ‘And your ex-husband? Dougie boy? What’ll happen to him?’

‘Much the same thing. They’ve had to move him out of here, of course. It’s compromised.’

‘So we’re done with the whole thing?’

‘We’re done with it. Our babysitting days are officially over.’

‘We can still look for the diamonds, though?’

‘Of course.’

‘Good. You want to know what I think, by the way?’ says Ron.

‘Not really, Ron,’ replies Elizabeth.

‘I think you could easily have made two phone calls last night, could have had me and Joyce both here. But I think you didn’t want me to meet your ex-husband.’

Joyce nods as Elizabeth responds.

‘Well, I’ve always wished I’d never met him, so I like to extend the same courtesy to my friends.’

‘Handsome, Joyce says?’

‘Very,’ agrees Joyce.

Elizabeth shrugs. ‘What is it with men and handsome? Wouldn’t you rather be kind and clever and funny and brave than handsome?’

‘No,’ says Ron.

‘Can I ask you both something?’ says Joyce.

Her friends both nod.

‘In your teas, I’ve left one bag in and one bag out. Could you try them both and let me know which you prefer?’

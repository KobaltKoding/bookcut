## 49

Strictly speaking, it is not a date.

She and a DCI from London had been on surveillance all evening, keeping an eye on Connie Johnson’s lock-up. Donna would rather have been on the stakeout with Chris, and now her mum has gone back to south London she’ll get her wish soon enough.

There was nothing to report at the lock-up: a few lads on bikes, coming and going. No new faces, no Connie. Donna had half-expected to see Ryan Baird cycling up to the door at some point, but perhaps he is lying low until his court appearance?

Connie had their number, that was for sure. But if she and Chris could find a way of nailing her, then medals and promotions would surely follow.

The DCI was one of a crew down from London for a couple of weeks. Connie Johnson was being taken seriously, and reinforcements had been brought in. He is currently sitting opposite her drinking beer from the bottle (‘I don’t need a glass, it’s already in glass’). He was the only single man in the whole bunch, if Donna’s extensive Facebook investigations were to be believed.

The DCI is called Jordan, or maybe Jayden. With desserts on the way it was probably too late to ask which now. She has just been calling him ‘sir’ all evening and he doesn’t seem to mind. So far she has found out that he has never watched _Bake Off_ because it is ‘mind-numbing rubbish’ but, nevertheless, he thinks that 5G phone-masts are a government conspiracy, and something to do with cancer. Something we should be keeping an eye on, at the very least.

He must be thirty-five or forty, it’s so hard to tell with men at that age. He looks like he has strong arms, and that was enough for Donna to agree to dinner at Le Pont Noir after their shift. God, she is lonely.

She is nearly thirty, with friends pairing off and disappearing. Carl, her ex, was engaged already, he’d wasted no time. And this a man who ‘needed space’ and ‘wasn’t ready for commitment, babe’. His fiancée is a shoe influencer, rather than a police officer, and they are getting married in Dubai.

So Donna is the new girl in a new town. A black girl in a seaside town, where she feels unwelcome or a novelty, and has no interest in feeling either. ‘Where are you from then?’ ‘South London.’ ‘No, where are you _really_ from?’ ‘Oh, I see, I’m really from Streatham.’

A town where Boots doesn’t have your shade of foundation, and the nearest person you can trust with your hair is in Brighton. None of this will kill her, but none of it helps her feel any less lonely.

But you have to make the best of things. And you also have to hang out with people under fifty every now and again. Hence this too-obvious man, whatever he might actually be called. Best foot forward, Donna.

‘I can’t believe you haven’t caught her yet,’ says the DCI with the possibly strong arms.

‘Connie’s smart,’ says Donna.

‘Smart for a small town, I suppose,’ says the DCI. ‘Not smart for London. Lucky for you lot, me and the cavalry have arrived.’

‘You haven’t caught her either,’ says Donna. Not unreasonably, she thinks.

‘London has different rhythms, love. A different heartbeat.’

‘I know,’ says Donna. ‘I’m from London.’

‘You have to live it, really. You breathe it in. The big, bad city.’

‘As I say, I was born there. Where are you from?’

‘High Wycombe,’ says the DCI.

‘The mean streets,’ says Donna.

‘Is that a joke?’ asks the DCI.

‘No, it’s just conversation,’ says Donna. ‘You can join in.’

Does he have nice eyes? Well, they’re a nice colour. That’s something.

‘I’m staying at the Travelodge, by the way,’ says the DCI, looking at his watch, a fake Rolex, no doubt ‘borrowed’ from an evidence store.

Donna nods. So she is going to have to have sex in a Travelodge this evening if she doesn’t want to be alone? So be it. Let’s get the bill, get a bottle of wine on the way and get it over with. A bit of oblivion, while her mum and her boss are falling in love.

‘Your guv’nor, then?’ says the DCI. ‘Chris Hudson? He seems a bit hopeless?’

‘I wouldn’t underestimate him if I were you,’ says Donna. Be very careful now, Jordan or Jayden.

‘He wouldn’t last a second in London,’ says the DCI.

‘Would he not?’ asks Donna.

‘Nah, he couldn’t catch Covid, that one.’

Well, there it was. Donna wasn’t going to have to have disappointing sex in a Travelodge this evening after all. Wasn’t going to have to boost the ego of this nondescript man. What was she even doing here? What was she looking for? The waiter brings over the bill and the mediocre DCI, who just made the mistake of insulting her best friend, takes a look.

‘You OK going halves?’ asks the DCI. ‘Also, you had wine, so …?’

‘Of course, sir,’ says Donna, reaching for her bag. She is going to have to do something about her life. In fact, she knows just the man she should talk to. Ibrahim.

She’s just sent him the CCTV from the station. Would he mind if she came to see him sometime?

Donna doesn’t need therapy, but she wouldn’t mind a nice long chat with a friend who happens to be a therapist.

Her phone pings. It’s a message from Chris.

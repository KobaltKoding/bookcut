## 56

The three men sit around a concrete table outside Maidstone Crown Court. The building itself looks like a 1980s Travelodge at a motorway service station.

It is Chris Hudson’s duty to be here, but he would have come to watch Ryan Baird in court anyway for sheer pleasure.

Chris has seen quite enough of Maidstone Crown Court over the years. His very first case here had involved a local councillor who had exposed himself on a train, and blamed his hay-fever medication. That councillor was now their local MP. His most recent case was a Paralympian who had been caught stealing rare birds’ eggs. She wore her bronze medal in court but was convicted nonetheless.

But he wouldn’t miss this for the world. Ryan Baird. The case was deeply unsafe, of course. The cocaine and the bank card found in the cistern of his toilet? The anonymous tip-off? But needs must, sometimes. Chris has never done anything like this before. The Thursday Murder Club leads him further astray almost daily.

Revenge for Ibrahim, that was the only goal. Last time Chris had seen Ibrahim, he had been battered and bruised, and the fact he was so stoic and uncomplaining had just made it worse. Ryan Baird behind bars would do no one any great harm.

So the trial will be a pleasure, but Chris has another, far less happy, reason for being here.

Connie Johnson. What was she capable of? Would she really harm Patrice? It was unthinkable.

What could he do to stop her? Who could help him?

He couldn’t call Elizabeth. Elizabeth would tell him to tell Patrice, and he wasn’t going to do that. Although it was almost certainly the right thing to do, the brave thing to do, he simply couldn’t. You didn’t get to be a fifty-one-year-old man by tackling things head-on.

And so he called Ron.

A pigeon is currently trying to steal Ron’s chips. He had insisted on a trip to McDonald’s on the way to court. Ron shoos the bird away, but it just stands its ground on the table, staring at him, then staring at his chips, waiting for him to drop his guard.

‘Don’t even think about it, mate,’ says Ron to the pigeon, then turns to Chris. ‘I reckon all pigeons are Tory.’

‘That’s a theory,’ says Chris.

‘She sounds like a nasty piece of work, then?’ says Ron. ‘This Connie Johnson?’

Bogdan, the third man around the table, nods.

‘Fit, though, I heard?’ asks Ron.

‘English fit, maybe,’ shrugs Bogdan. ‘Not Polish fit.’

Bogdan had been Chris’s next call. During their surveillance of Connie Johnson’s lock-up, they had seen Bogdan pay Connie a visit and leave with a package. Chris had decided he would need to confront Bogdan at some point, ask him a few questions. But after the package had been found in Ryan Baird’s cistern, all his questions had been answered. Bogdan clearly knew Connie Johnson, though, and that could be useful, so Chris had invited him along – ‘Meet me in Maidstone, bit of fun, don’t tell Elizabeth.’

‘It’s probably nothing,’ says Chris. ‘It’s just intimidation, don’t you think? She won’t do anything to Patrice?’

Bogdan grimaces. ‘I don’t know. She’s done worse things than that.’

‘Worse than killing the woman I love?’ says Chris.

‘She killed the Antonio brothers, you know that? Did it herself, too, sliced them in two in front of each …’

‘Jesus,’ says Chris. ‘By the way, if you have any evidence of that, you know what I do for a living.’

Bogdan laughs. ‘You must never talk to the police. It’s the law.’

‘That’s a vote of confidence,’ says Chris. ‘Thank you, Bogdan.’

‘We will fix it,’ says Bogdan. ‘Ron? We will fix it, yes?’

Ron nods.

‘It’s a diabolical liberty,’ says Ron. ‘I won’t have a diabolical liberty taken.’

‘Don’t do anything illegal, though,’ says Chris.

‘Well, define illegal,’ says Ron.

‘Against the law,’ says Chris. ‘It’s pretty simple.’

‘Chris, my old son,’ says Ron shaking his head. ‘You couldn’t be more wrong. Legal, illegal. It’s a fine line. It’s nineteen eighty-four, and we’re protesting outside Manton Colliery in Nottinghamshire. Fighting to protect the jobs of fifteen hundred men, fighting to save an industry.’

‘You had coal mines in England?’ says Bogdan.

‘The government, Thatcher, passes emergency legislation, saying you can’t picket outside someone else’s pit. But we do it anyway, we stand our ground. Matter of principle. The police come at us with batons and shields, but we don’t move. We don’t fight back, but we don’t move. Each and every one of us carted off to some nick or other, a good beating in the back of the van for our troubles. Next morning we’re in court, breach of the peace, two hundred quid. Criminal record and concussion for weeks. Now, forgive an old lefty, but I don’t think what I did was illegal, I think it was right.’

‘Well, different times, Ron,’ says Chris.

‘Now, a week later,’ continues Ron, ‘one of the boys goes to the library and finds the address of the Chief Constable of Nottinghamshire. He was made Lord something or other shortly after this. Anyway, he gets the address, and the next day some brother-in-law of someone’s brother-in-law goes round with a bulldozer and drives it into his extension. Now that, I grant you, was illegal. So there’s your fine line.’

‘Hmmm.’

‘And when Jason was on _Celebrity Bargain Hunt_,’ continues Ron, ‘he found out where the auction was going to be and got two of his mates to bid against each other for everything he bought. Gary Sansom, you won’t know him, he’s an armed robber, but from up north, he ends up paying a hundred and sixty quid for a silver cigarette lighter Jason bought for a tenner, and he won the whole show. Is that illegal? When all the money went to Multiple Sclerosis?’

‘Well …’ says Chris.

‘What we’re saying,’ says Bogdan, ‘is you’re in safe hands.’

Chris nods. ‘Look, just don’t kill anyone. But if you can find a way to stop her, you know, all help gratefully received.’

The men nod. Even the pigeon seems to nod, and Ron gives it a chip.

‘And not a word to Donna, and not a word to Elizabeth?’ says Chris.

‘Elizabeth will know already,’ says Bogdan. ‘There will be a bug under the table.’

‘I’m going to have to tell Joyce something though,’ says Ron.

‘Nothing to _anyone_, Ron,’ says Chris. ‘The conversation stays here.’

‘Sorry, old son,’ says Ron. ‘Joyce reckons you’re in love with Patrice, and I said, no, they’re just banging, and who wouldn’t, with respect, she’s a beautiful woman.’

‘Thank you, Ron,’ says Chris.

‘So I’m going to have to tell her.’

‘Tell her what?’ says Chris.

‘I’ll just say we were having a chat, something about the police, I don’t know, and Chris called Patrice “the woman I love”. She’ll be tickled pink.’

‘I don’t think I did say that, Ron,’ says Chris. Had he said that?

‘You did,’ says Ron.

‘Yeah, you did,’ says Bogdan. ‘Elizabeth will have it all on the tape.’

Well, thinks Chris. Sitting at a concrete table with two friends, a pigeon enjoying a McDonald’s, and being in love. That was something to protect, wasn’t it?

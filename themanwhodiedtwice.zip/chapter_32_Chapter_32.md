## 32

## Joyce

Have I ever spoken about Maureen Gilks? I suspect not, no offence to her. She lives in Ruskin Court. Her husband was in motorbikes, and she sometimes comes collecting for the British Heart Foundation shop.

I once gave her a blouse and when I was next in Fairhaven I saw it in the shop, which was a thrill. I sent a photo to Joanna but she just replied, ‘Well what did you think they were going to do with it, Mum?’ Anyway, next time I went down there it was gone, which was also lovely, though I had nothing to take a photo of that time.

Well, Maureen Gilks has a nephew called Daniel or David, and he is an actor. The way Maureen tells it, he is doing very well, though I haven’t seen him in anything. Not even a _Morse_.

A couple of years ago now, this nephew had a hair transplant. Have you heard of them? I saw Doctor Ranj talking about them on _This Morning_ once. They take hair from the back of your head and put it on the top of your head and hey presto, you’re not going bald any more.

Apparently it worked an absolute treat and Daniel looks ten years younger, and there’s no way you would ever know. This is all according to Maureen, by the way, so don’t take my word for it.

Actually this is probably not where I should have started this diary entry, so let me backtrack a moment. I’m quite tired.

Douglas and Poppy are dead.

Elizabeth and I went to Hove, which, I have to say, was busier than I’d expected for a Tuesday. Does nobody go to work any more? Douglas had wanted to show Elizabeth something. We walked into a house on St Albans Avenue (near the King Alfred swimming pool?) and there they were, shot dead.

Douglas is fair game I think, but how awful about Poppy? I’m afraid it has left me very sad, even though I try not to get too sad these days.

She was in my living room three days ago. How unfair to die in your twenties with all that fun ahead of you. The kisses and the boat rides and the flowers and the new coats. Those poems she will never read to a new lover? You will go completely mad waiting for life to be fair, but whoever killed Poppy took something beautiful.

Poppy’s mum, Siobhan, was supposed to visit today, and I was very worried that I was the one who was going to have to tell her about the murder. But as she’s Poppy’s next of kin she was told straight away, and is going down to identify the body, poor woman.

She sent me a message, and the message ended with emojis of a poppy and a daisy, which was very moving. I sent one back, telling her we would still like to see her, and I tried to add a poppy and a daisy to that too, but I pressed the wrong thing and sent a poppy and a Christmas tree instead. I hope she will understand.

So we have two murders on our hands. Three if you count Andrew Hastings, but we already know who did that.

Every time I walk into a bedroom these days someone has been shot. I was going to plump up the pillows in the spare room earlier, but got cold feet.

I don’t think we will be able to have fun with Sue and Lance the way we have fun with Chris and Donna and the Fairhaven police. It’s a shame. I’m sure we’ll try our best though. We often wear people down in the end.

Speaking of Lance, that’s why I was talking about Maureen Gilks and her nephew! You can see that Lance’s hair is thinning, and I kept thinking that I should mention hair transplants to him. You could tell he was exactly the sort of man whose hair was very important to him. I kept waiting for a lull in the conversation, or a bit of small talk, but the right moment didn’t come. Every time there was a pause and I thought, Well, here goes, Sue would mention something about Poppy’s gunshot wounds, or the blood, splattered behind Douglas’s head. I simply didn’t get the chance.

So I do hope I see Lance again, because it is best to catch these things as early as possible. That’s what Maureen Gilks said. Let me quickly google her nephew.

OK, I’m back. Nothing. I tried _Daniel Gilks actor_ and _David Gilks actor_ and he was nowhere to be seen. So maybe I have his first name wrong. Also, he may not be a Gilks? So I don’t know his first name or his surname, and I’m not good enough at Google to overcome that.

By the way, I messaged Nigella on Instagram about her sausages in black treacle. She has yet to reply, but I know she’s here, there and everywhere, so she’s forgiven. I also posted my first photo, just of the post box, and someone called @sparklyrockgirl replied ‘nice pic’ and followed me. So now I have a follower. We all have to start somewhere.

I wonder if Elizabeth is sad about Douglas? I’ve never had an ex-husband so I wouldn’t know. I could see she didn’t much like him, though Elizabeth doesn’t much like most people, but she doesn’t go around marrying them all. Douglas still loved her, you could see that. And he had her locket in his jacket, which was very touching.

So she must be sad. And she can’t talk to Stephen about things any more, least of all this. At least I have Joanna to talk to. I will text her in the morning to tell her I’ve seen three corpses and been blindfolded and interrogated by MI5\. Recently my gossip has been ‘so and so has cataracts’ or ‘a fox got into the hen-house’. I hear her drifting, and I don’t blame her.

I won’t tell her about the twenty million, though. I don’t know why. Well, I do know why – she will have an opinion, and I’m not in the mood for Joanna’s opinions.

Imagine if we found the diamonds? I’m not saying that we will, I’m just saying imagine. Martin Lomax will probably find them, probably already has. Or MI5 will find them. Or the mafia.

But let’s say, for one moment, that Elizabeth, Ron, Ibrahim and I find them. You never know with us.

That would be five million each.

What would I do with five million pounds, I wonder?

I need new patio doors, they’re about fifteen thousand, though Ron knows someone who could do it for eight.

I could buy £14.99 wine instead of £8.99 wine, but would I notice the difference?

Give some money to Joanna? She already has plenty. I used to give her £20 when she went out with friends and her eyes would light up. I loved that. Would they light up the same way for a million pounds? Probably not. She’d probably put it in an ISA or something.

So I probably don’t really need five million pounds, but, nonetheless, I’m sure I shall dream about it tonight. You would too, wouldn’t you?

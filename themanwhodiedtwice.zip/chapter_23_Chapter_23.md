## 23

Elizabeth looks at her watch and sighs. She speeds up a touch.

They are about twenty minutes behind schedule, because Joyce had insisted on stopping for a coffee. Joyce loves to sit in coffee shops and look out of the window at the people passing by. She would sit there all day if you let her, saying, ‘Ooh, umbrellas are going up,’ or, ‘Do you think I would suit that coat, Elizabeth?’ She doesn’t even particularly like coffee, she just feels too awkward asking for tea in a coffee shop.

Douglas has asked to see her, and it’s the least she can do in the circumstances. He was very nearly killed on her watch. She hadn’t officially started looking after him, but even so.

They are on their way to the new safe house in Hove. Number 38 St Albans Avenue, one of many parallel streets leading down from the cafés of Church Road to the ice-cream parlours of the seafront.

‘Isn’t the sea air lovely?’ says Joyce.

‘A tonic,’ agrees Elizabeth, as a large lorry drives past them.

Something wasn’t right with Joyce. Elizabeth has learned to read her pretty well by now, and she is definitely being over-jolly. That was Joyce’s trick. It worked on everybody else, but it didn’t work on Elizabeth. Elizabeth stops outside the Nando’s on Church Road, and puts her hand on Joyce’s arm.

‘Before we see Douglas and Poppy, why don’t you let me know what you’re hiding?’

Joyce looks up at her, those bright eyes so innocent, that halo of snow-white hair.

‘I’m sure I don’t know what you mean?’

‘Joyce, you’ve held us up for twenty minutes already. I really don’t want to stand here for another twenty minutes trying to get it out of you.’

‘Sometimes, Elizabeth, you act as if you’re my boss. And you’re not.’

Elizabeth sighs. ‘Please, I’m begging of you, don’t be tiresome. Just tell me.’

Joyce looks at the Nando’s. ‘Do you know, I’ve never been to a Nando’s?’

‘You’re clearly keeping something from me. Is it to do with Douglas, perhaps?’

‘I might bring Ibrahim. He’d like a Nando’s, don’t you think? And we need to make sure he gets out.’

‘Something to do with Poppy, then?’

‘Sometimes, Elizabeth, you just have to accept that you don’t know everything. And there it is, I’m afraid.’

Elizabeth stares into Joyce’s eyes and nods. ‘So, it _is_ something to do with Poppy? You’re good, Joyce, but you’re not that good.’

Joyce smiles. ‘This is just making us later, dear. We’ll look rude. I haven’t even brought anything for them. Do we have time to pick up some fudge?’

Elizabeth is thinking. ‘Well, we know it’s Poppy, that’s written all over your face. Perhaps Poppy asked you something? But you weren’t alone with her, were you?’

‘I’m afraid you’re barking up the wrong tree. There’s a lovely bookshop further up, City Books? I could pick up a John Grisham for Douglas?’

‘So Poppy gave you something? Is that it? On her way out, she slipped you something?’

‘I think someone’s slipped _you_ something, Elizabeth. I’m right about Ibrahim, aren’t I? We need to make sure he gets out. He won’t want to. I think Nando’s is mainly chicken, but they must do puddings and things.’

‘What could she possibly have given you? And why you and not me?’

‘I was thinking of going to the dog rescue centre. I might ask Ibrahim to drive me as soon as he’s back.’

‘A message, perhaps? Did Poppy give you a message? Slipped it into your hand as she was leaving?’ Elizabeth looks long and hard at Joyce.

‘He’ll object, you know Ibrahim. But we’ll talk him round. And dogs are very healing. I’m not telling you anything you don’t already know, but his mental injuries will last far longer than his physical injuries.’

‘Something personal.’ Elizabeth steps aside as a group of youths barrels into the Nando’s. ‘That’s why she chose you. An errand. Something she knew she could trust you with?’

‘I checked on the website. Alan is still there. That’s the dog. Though I’m going to call him Rusty; you’re the first person I’ve told that. I wrote it in my diary, but I haven’t said it out loud.’

‘You were wearing your new cardigan, of course. Which suits you a great deal, by the way. So perhaps she just slipped it into your pocket?’

‘Thank you about the cardigan. When I was a child the neighbours had a dog called Rusty, you see.’

‘I wonder, Joyce, if she wanted you to contact someone for her? Just to let them know she was all right? That’s the sort of thing I would absolutely trust you with.’

‘He was a retriever, I think, though I get them mixed up with Labradors. We’re all a bit of everything, though, aren’t we? When you start looking into it?’

‘Who does Poppy trust?’ asks Elizabeth. ‘That’s the question.’

‘Everyone loves John Grisham, don’t they? He’s a safe bet.’

Elizabeth puts her hands on Joyce’s shoulders, nods and looks her directly in the eye.

‘I wonder, Joyce. Did Poppy give you her mother’s phone number?’

Joyce throws her hands up. ‘Oh, for goodness’ sake, Elizabeth. I can’t have anything, can I?’

‘You held out longer than most. Did you ring her?’

Joyce nods. ‘Is that OK?’

‘It’s fine, I’m not surprised someone would want to talk to their mum the first time they killed someone. I mean, I didn’t, but I’m me.’

‘She seems lovely. I’ve invited her down, I’m afraid.’

‘That’s a nice idea. Now, shall we get on?’

Joyce smiles and the two friends walk towards St Albans Avenue.

‘You’re not cross?’ asks Joyce.

‘Not a bit,’ says Elizabeth. ‘Although I will say this: They don’t like you to change the names of the dogs.’

‘I know, but _Alan_,’ says Joyce.

‘Well, why don’t you let Ibrahim decide? That’s the sort of thing he’s good at.’

‘I can’t wait to have him back, can you?’

Elizabeth slips her arm through Joyce’s and they continue walking.

‘Where was Ron off to, by the way?’ asks Joyce. ‘I saw him driving off before we left. He never drives these days.’

Elizabeth looks at her watch. ‘Ron has a plumbing job. He was very keen to get to it.’

‘A plumbing job?’

‘You know Ron, he can turn his hand to anything.’

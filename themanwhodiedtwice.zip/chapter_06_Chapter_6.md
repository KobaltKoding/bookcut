## 6

Elizabeth is sipping her second Malbec, and listening to her ex-husband, Douglas Middlemiss, talking about international money laundering. Explaining the story of why a man of his age might need babysitting.

‘We’d been looking at him for a while, this chap Martin Lomax, lovely big old house, plenty of money, but with the paperwork to prove where everything came from. The financial boys couldn’t touch him. But when you know, you know, don’t you?’

‘You do,’ agrees Elizabeth.

‘There would be all sorts turning up at his house, at all hours. Russians, Serbians, the Turkish mafia. All coming to this secluded house outside a sleepy village. Hambledon, if you know it? They invented cricket there.’

‘I’m sorry to hear that,’ says Elizabeth.

‘Range Rovers, Bentleys, up and down the country lanes. Arabs in helicopters, the full works. An Irish Republican commander once parachuted out of a light aircraft and landed in his garden.’

‘What’s his business?’ asks Elizabeth. ‘Unofficially?’

‘Insurance,’ says Poppy.

‘Insurance?’

‘He acts as a bank for major crime gangs,’ says Douglas, leaning forward. ‘Say the Turks are buying a hundred million pounds’ worth of heroin from the Afghans. They won’t pay the full amount.’

‘Just as you don’t have to pay the full amount for a freezer until it’s delivered,’ says Poppy.

‘Thank you, Poppy,’ says Elizabeth. ‘I’d be lost without you.’

‘So they’ll give a security deposit of, say, ten million to a trusted middleman,’ says Douglas. ‘As a gesture of good faith.’

‘And Martin Lomax is the middleman?’

‘Well, they all trust him. You’d trust him if you met him. He’s a peculiar fellow, quite evil, but solid. It is hard to find evil people who are also reliable. As you know.’

Elizabeth nods. ‘So he has a house stuffed with cash?’

‘Sometimes cash, sometimes far more exotic things. Priceless paintings, gold, diamonds,’ says Douglas.

‘An Uzbek drug dealer once brought in a first edition of _The Canterbury Tales_,’ adds Poppy.

‘Anything with a value,’ says Douglas. ‘And these things sit in a strongroom at our chap’s house. If all goes well with a deal, he returns the down payment, often to be used again. And if things go wrong, then the down payment is paid in compensation.’

‘So this strongroom is quite the place?’ asks Elizabeth.

‘I suspect at any one time you might find half a billion in cash, the same again in gold and stones, stolen Rembrandts, Chinese jade worth millions. Just sitting there, a few miles from Winchester if you please.’

‘And how do you know all of this?’

‘We’ve been in the house a number of times,’ says Poppy. ‘We have microphones drilled into walls, cameras in light switches.’

‘All the tricks you’d know,’ says Douglas.

‘Even in the strongroom?’

Poppy shakes her head. ‘We’ve never made it into the strongroom.’

‘But there’s plenty enough just lying about elsewhere,’ says Douglas. ‘When I broke in, there was a Van Eyck on a pool table.’

‘When you broke in?’

‘I had help, naturally. Poppy and one of the boys from the Special Boat Service.’

‘You’re a housebreaker, too, Poppy?’ says Elizabeth to the young woman sitting on the windowsill, legs dangling.

‘I just dressed in black and did what I was told,’ says Poppy, shifting to get comfortable.

‘Well, that sums up a career in the security services,’ says Elizabeth. ‘So the two of you and some interested friends break into this house, stuffed to the gills with treasure?’

‘Precisely,’ says Douglas. ‘Just for a little look around, you know? Scope it out, take a few piccies, dash off with no one any the wiser. Nothing you and I haven’t done a hundred times before.’

‘I see, and does this have anything to do with why you’re in a flat with two armchairs and a padlocked bedroom, looking for your very happily ex-wife to babysit you?’

‘It’s fair to say it’s where my little problem began, yes. Are you ready?’

‘Fire away, Douglas,’ says Elizabeth, looking straight at him. That twinkle in his eye was undimmed. The twinkle that gave an entirely undeserved suggestion of wisdom and charm. The twinkle that could make you walk down the aisle with a man almost ten years your junior, and regret it within months. The twinkle you soon realize is actually the beam of a lighthouse, warning you off the rocks.

‘Can I ask you a question first?’ says Poppy from the windowsill. ‘Before we tell you everything?’

‘Of course, dear,’ says Elizabeth.

‘How much do they know about you around here? Quite a lot, I suppose, given what’s in the file?’

‘They know a thing or two about me, yes,’ says Elizabeth. ‘My close friends.’

‘And your close friends would be Joyce Meadowcroft, Ron Ritchie and Ibrahim Arif?’

‘They would. That’s quite a file you have, Poppy. Joyce will be thrilled when I tell her she’s in a file.’

‘Could I ask – I’ve been asked to ask – before we go any further. Have you at any point in the last four months broken the Official Secrets Act?’

Elizabeth laughs. ‘Oh, goodness me, yes. Over and over.’

‘OK, I’ll make a note of that. It’s very important that none of your friends learn about Douglas or me. Can you guarantee that at least?’

‘Certainly not. I shall tell them the moment I’m out of the door.’

‘I’m afraid I can’t allow that.’

‘I don’t see that you have a choice, Poppy.’

‘You will understand, ma’am, better than most people, that I have orders.’

‘Poppy – firstly, call me Elizabeth. Secondly, I haven’t seen you get an order right in two weeks, so why change now? Now, let’s hear this story, and I’ll tell you if I accept the job. And then I’ll tell my friends, but you mustn’t worry yourself.’

Douglas is chuckling. ‘So your friends know everything about you?’

‘Everything they need to, yes,’ says Elizabeth.

‘Do they know that you’re Dame Elizabeth?’

‘Of course not.’

‘So not everything?’

‘Not everything.’

‘When was the last time you used your title, Elizabeth?’

‘When I needed to borrow a motorcycle to get out of Kosovo in a hurry. When was the last time you used yours, Sir Douglas?’

‘When I tried to get tickets for _Hamilton_.’

Elizabeth’s phone rings. Which is rare. She looks down. Joyce is calling her. Which is rarer still.

‘Forgive me, I have to take this.’

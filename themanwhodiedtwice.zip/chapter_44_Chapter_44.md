## 44

‘They were both shot in the face, so it was a terrible mess,’ says Joyce. ‘More Battenberg, Patrice?’

‘Nowhere left to put it,’ says Patrice, holding up her palm. ‘I’m half Battenberg already.’

‘Murder suicide?’ asks Chris. ‘Or double murder?’

‘Double murder,’ says Ron. ‘No gun left lying around, eh? Some geezer’s walked in –’

‘Or woman,’ says Donna, and gets an approving nod from her mum.

‘Some geezer, or some bird, granted, has just walked in, and opened up, kablammo. Heads blown off. You wouldn’t wish it on anyone.’

‘More women are murdering people these days,’ says Joyce. ‘If you ignore the context, it is a real sign of progress.’

Donna tucks her feet up beneath her. How was this all going then? Upside: the look on Elizabeth’s face when she realized that Patrice and Donna were mother and daughter. That she had managed to keep it secret. Elizabeth hated other people having secrets. Downside: having to watch her mum and Chris putting on a show for the Thursday Murder Club. Sitting knees together on the sofa. Touching, kissing, cooing. Donna wants them both to be happy, but she doesn’t need to watch them being happy. She doesn’t even particularly want to hear about them being happy. So long as they _are_ happy, that’s all she needs. And they do _look_ happy, don’t they? What if this relationship was actually going to work? What if Donna had performed a miracle?

‘And they’d tried before? They’d tried here?’ asks Chris.

‘Someone tried to kill Douglas, yes,’ says Elizabeth. ‘Made a rotten job of it and Poppy took his head off. May she rest in peace.’

‘I was hoping you and Donna might come and investigate,’ says Joyce. ‘But they sent Sue and Lance from MI5 instead.’

‘Not that we would ever reveal the names of MI5 officers, Joyce,’ says Elizabeth.

‘Oh, I’m only telling Chris,’ says Joyce. ‘Don’t be a fusspot.’

‘I’ll just check the Official Secrets Act, Joyce, and see if that’s in there.’

‘Anyway, they’re not a patch on you two,’ says Joyce. ‘Sue is a bit of a cold fish. Like Elizabeth, but without the warmth. But you can see she respects her.’

‘Senior, were you, Lizzie?’ asks Ron.

‘And then there was Lance. Balding but quite handsome, and there was no wedding ring. Anyway, I could get his number for you, Donna?’

‘A date with a balding spy? Well, that sounds a treat,’ says Donna. She had been on a date on Monday. His profile had said he was a diving instructor, which had sounded suitably alpha to Donna. Of course, she had misread the profile, and so had ended up having very disappointing sex with a driving instructor. She had also made the mistake of telling her mum and Chris about it, and they had a field day. Mum had made a number of jokes about his gearstick, and Chris had said, ‘Did he look in his mirror before pulling out?’ Donna downs her glass of wine.

‘Would you like to see photographs of the crime scene?’ asks Elizabeth.

‘Yes, please,’ says Chris.

‘I’ll need something in return,’ says Elizabeth.

‘Here we go,’ says Chris.

‘We just want to know the following. One, how long have you two been dating?’

‘None of your business,’ says Chris.

‘These photos are from every possible angle. Entry wounds, exit wounds, items disturbed in the room.’

‘Six weeks,’ says Patrice.

‘Thank you,’ says Elizabeth. ‘Two, where do you think this is going to go? I think I speak for all of us when I say that you seem an adorable couple.’

Donna mimes being sick as Joyce and Ron nod.

Patrice smiles. ‘Well, let’s take it one day at a time, shall we? I enjoyed yesterday, I’m having fun today, and I’m looking forward to tomorrow.’

She had given the same answer to Ibrahim, when she, Donna and Chris had visited him in his sick bed before coming over. He was intently playing _Minecraft_ with Ron’s grandson, but had looked up long enough to say, ‘Theoretically, I know a thing or two about love. And that sounds like a very healthy answer.’

‘Any gossip from you four in return?’ asks Donna, keen to change the subject. ‘Apart from three people being shot?’

‘Well, Joyce had Gordon Playfair around for lunch one day last week,’ says Elizabeth.

‘He was rebooting my Wi-Fi,’ says Joyce.

‘I’ll bet he was,’ says Ron, another glass of wine down now.

‘Photos?’ reminds Chris.

Elizabeth holds up her finger, then fishes into her bag. ‘I lost my phone, briefly, but Bogdan found it for me.’ She scrolls through her photos and passes it to Chris. ‘Here, you two lovebirds can take a look.’

Chris holds the phone in front of him, and angles it slightly towards Patrice. He flicks through a couple of photos, pinching the screen occasionally to enlarge details.

‘Professional job,’ says Patrice.

‘I was about to say that!’ says Chris.

‘Great minds think alike,’ says Patrice and kisses Chris on the lips. Donna rolls her eyes and mutters ‘get a room’ loud enough for only Joyce to hear. Joyce giggles. Donna gives her a discreet high-five.

‘What a mess, though,’ says Chris.

‘Let me look,’ says Donna, and holds out her hand.

‘She was always impatient,’ says Patrice. ‘Wouldn’t ride a bike with stabilizers, wouldn’t wear armbands in the pool. We were in and out of A&E.’

Donna takes the phone from her mum and begins to scroll through the photos. As she stares at the two bodies, the young woman and the old man, she zones out of the conversation around her. Joyce is asking about Donna as a child, Ron is asking for more wine, her mum is asking about Gordon Playfair. Was all as it seemed in these photos? Something wasn’t right. On her date with the driving instructor, he had shown her a tattoo in Chinese script on his upper arm, and she had asked him what it meant. He had had no idea, he had just liked the look of it. To try and make conversation before they had sex again and she could finally ask him to leave, Donna had taken a photo of it and put it through a translation app. It turned out that the tattoo read ‘Sample Text – Your Message Goes Here’.

Sometimes things were just for show, they only looked right. Until you changed the way you looked at them. Donna puts down the phone.

‘I know you’ll have thought about this, but are you absolutely _sure_ this is Douglas?’

‘Yes,’ says Elizabeth. ‘I have thought of that. Now, where are we with that CCTV?’

‘What CCTV?’ asks Chris.

There is a buzz. Somebody is at Joyce’s door.

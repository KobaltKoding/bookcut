## 67

Elizabeth and Joyce are in the minibus, on their way down to Fairhaven. Joyce has flapjacks and Elizabeth has news. Joyce intends to share the flapjacks, but Elizabeth is keeping the news to herself.

‘Just tell me,’ says Joyce.

‘In good time,’ says Elizabeth.

‘You’re such a bully,’ says Joyce.

‘Nonsense,’ says Elizabeth. ‘Are you getting a dog, by the way? Stephen wanted to know.’

‘None of your business,’ says Joyce. She is beginning to think she might not offer Elizabeth a flapjack, but she has made them with coconut oil, and is desperate for someone to try them. So she is in a bind.

Elizabeth had sent her a message first thing.

_We are going to Fairhaven this morning. Wear something that goes well with diamonds_.

However, she has been no more forthcoming than that. Joyce is wearing another new cardigan. Navy blue. It had better be worth it.

‘What are we going to do about Ryan Baird?’ asks Elizabeth.

‘You tell me,’ says Joyce. ‘You always have the answers.’

‘Are we having a row, Joyce?’ asks Elizabeth. ‘How novel.’

‘Friends don’t keep secrets,’ says Joyce.

‘It’s a good secret though, so don’t get crotchety,’ says Elizabeth. ‘I just want to surprise you.’

The minibus pulls up outside the Ryman’s in Fairhaven and Carlito bids them all farewell. He is vaping, and Elizabeth tells him to smoke a proper cigarette for goodness’ sake.

‘So where are we going?’ asks Joyce.

‘You know where we’re going,’ says Elizabeth, and sets off towards the seafront.

‘You’re so infuriating,’ says Joyce, setting off behind her.

‘I know,’ says Elizabeth. ‘I honestly can’t help it. I have tried.’

The shops peter out, and they find themselves on a familiar route. They pass the rows and rows of lock-up garages. They pass Le Pont Noir. Elizabeth striding, Joyce hurrying to keep up.

‘Are we going back to the train station?’ asks Joyce.

‘By George, I think she’s got it,’ says Elizabeth.

‘Why are we going to the station?’ But Elizabeth is hurrying ahead.

The walk continues, until they find themselves inside Fairhaven train station. No need to follow the signs this time. They stop at the Left Luggage Office and the receptionist takes off her headphones and smiles.

‘Welcome back!’

‘Thank you,’ says Elizabeth.

‘Do you need anything?’

‘No, thank you, dear,’ says Elizabeth, and holds up the key to locker 531.

Elizabeth and Joyce enter the rows of lockers, and Elizabeth stops by the first one.

She takes something out of her handbag, and passes it to Joyce. It is the locket that Douglas gave her.

‘You found something in the locket?’ asks Joyce. ‘Is that why we’re back here?’

Elizabeth holds up a finger to stop her. ‘Joyce, you solved this for me.’

‘Oh, good,’ says Joyce.

‘Well, you and Bogdan.’

‘I don’t mind sharing with Bogdan,’ says Joyce.

‘You worked out that Poppy overheard my conversation with Douglas. Which made me really think about the conversation. I’ve told you, there’s never a word out of place with Douglas. He is meticulous. Even in our wedding vows I noticed he put the slightest question mark after “I do”.’

‘Ooh,’ says Joyce.

‘When we were by the tree, he reminded me of a dead-letter drop we had had in East Berlin, only, you see, the dead-letter drop was in West Berlin. I put it down to old age. It hits men harder, as we know.’

‘But it wasn’t old age?’

‘Open the locket, and what do you see?’

Joyce opens the locket. ‘Nothing, just the mirror.’

‘Just the mirror, precisely. The worthless mirror that Douglas was so keen to give me. But what does a mirror do? It turns East Berlin into West Berlin. It turns NIKE into EKIN. And?’ Elizabeth holds up the key.

Joyce almost squeals. ‘It turns 531 into 135!’

Elizabeth nods, and motions along the line of lockers. ‘Would you like to do the honours?’

Joyce follows behind her. ‘No, you.’

They reach locker 135, and Elizabeth slides the key into the lock. It is a perfect fit. She turns it, and the door swings open. Inside is a blue velvet bag, with a drawstring around the top. Elizabeth motions for Joyce to take it. Joyce lifts the bag and loosens the drawstring.

Diamonds sparkle inside. Thirty or so. Big ones.

She was wearing exactly the right cardigan.

‘You’re holding twenty million pounds, Joyce,’ says Elizabeth. ‘Slip it into your bag, will you? And promise not to get mugged on the way back to the minibus.’

Elizabeth reaches into the locker again and pulls out a note. It is from Douglas. She reads it, then shows it to Joyce.

> _Darling Elizabeth,_
> 
> _So you found them? Sorry for the wild goose chase, but it was fun, no? Did you get it from East Berlin, or did you need the mirror? Belt and braces, I know. I didn’t want to make it too easy, but I wanted to make sure you would get there eventually. I hope you didn’t go down to the cottage in Rye? They built a bypass through it years ago._
> 
> _In any event, congratulations. Aren’t they beautiful? What will you do with them? You really should keep them. Go on, you know you want to?_
> 
> _On a slightly more sombre note, it goes without saying that if you’ve found this note then I am dead. So it is swings and roundabouts, isn’t it? Though life is always swings and roundabouts, so I don’t see why death should be any different._
> 
> _I wonder if I’ll be heading upstairs? I doubt it, don’t you?_
> 
> _I will love you always,_
> 
> _Douglas_

Joyce hands the letter back to Elizabeth. Elizabeth folds it up and returns it to the locker. Joyce looks down into her bag, at the diamonds. They are tucked away under a Kate Atkinson.

‘So what are we going to do with the diamonds?’ she asks. ‘I don’t suppose we could just keep them?’

Elizabeth slips her arm through the arm of her friend. ‘We’re going to use them as bait to catch Poppy and Siobhan.’

Joyce nods. ‘It will be nice to see Poppy again, even if she murdered Douglas.’

‘And maybe bait for a few more people who deserve catching, too,’ says Elizabeth.

‘Perhaps we could just keep one or two of the diamonds?’ says Joyce. ‘I don’t think anyone would notice?’

‘I think,’ says Elizabeth, ‘that we need to convene an emergency meeting of the Thursday Murder Club.’

‘Wonderful,’ says Joyce. ‘I’m sorry I was angry earlier.’

‘Don’t mention it,’ says Elizabeth. ‘I’m infuriating.’

Joyce smiles. ‘You certainly are. Would you like a flapjack?’

‘Finally,’ says Elizabeth.

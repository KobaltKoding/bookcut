## 70

## Joyce

I didn’t want to say I had found Ryan Baird in front of everyone. Least of all Ibrahim, who doesn’t even know he’s missing.

I had the file that Poppy had given us, all of Ryan Baird’s information, big photo, and lots of details, and I had been looking through it, trying to find a bit of inspiration.

Can I say, by the way, that Poppy had put a Post-it note on the front of the file, and had put a little kiss and a smiley face on that Post-it note? And I just wonder if that’s really the sort of thing a murderer would do?

Perhaps cold-blooded murderers are endlessly drawing smiley faces on Post-it notes? I was going to say I don’t really know any murderers, but of course I do these days.

I know we can all pretend to be all sorts of things. Gerry once pretended to be Dutch when we were camping in the Dordogne. He did the accent and everything. That was just for a bit of fun, to make me laugh, he wasn’t planning on shooting anyone.

I _think_ it’s a fact that Poppy must have found the letter in the tree? Nothing else makes sense otherwise. And I know it’s a fact that Poppy’s mum opened locker 531, and that, the next day, someone shot someone in the safe house on St Albans Avenue. So all fingers point to Poppy.

But still I come back to the smiley face and the little kiss on the Post-it note.

So, yes, the file.

I had looked up Ryan Baird on Instagram before, of course. There were twelve of them, but only one in Kent. BigBairdWolf2003\. But the account was private, and I am not a computer hacker, and I don’t know any computer hackers, so I didn’t take it any further. Someone from BT came round to fix my broadband last week, and I asked her if she knew how to hack into private Instagram accounts, but she didn’t.

I still don’t know how to get into my @GreatJoy69 private messages. There are now over a thousand. How frustrating.

Anyway, then I had a bright idea, even if I say so myself. In Poppy’s file is a list of Ryan Baird’s friends and family members, and so I started looking them up on Instagram too. I thought, Well, he’s gone _somewhere_, hasn’t he? If I was ever on the run, there’s a woman I used to work with – Sandra Nugent? – who retired to the Isle of Wight, and I would probably go and stay with her. She says it’s the middle of nowhere, but you can still get a Tesco delivery, so that would suit me down to the ground. Sandra can get a bit much sometimes, but if you’re on the run you can’t be too picky.

Ryan Baird’s mum is in Littlehampton, but I couldn’t find her on Instagram. I couldn’t even find her on Facebook, so she may very well be dead. He has an older sister, Leanne, and I think I found her, but she never posts anything except rainbows in support of various different things. Good for her, but no help to me.

Then we got on to cousins, of which there were plenty. This was a long job, by the way. I’m making it sound quick, but it wasn’t. There were so many people to check, and I also kept getting distracted by new posts from people I follow. I watched Joe Wicks do a new workout, for example.

The file got on to Steven Baird. Born in Paisley, which I know is in Scotland, so I had a little search, and there are lots of Bairds in Scotland, and lots of Stevens too. So I scrolled through a few. Then I stumbled across StevieBlunterRangers4Eva.

He had a look of Ryan Baird about him, something unfortunate around the eyes, so I thought I would explore a little. It didn’t take long. Two days ago Stevie Blunter had posted a series of pictures of a party. It was in a small, messy flat, and, even in photographs, it looked loud.

Then I found the photograph I was looking for. The caption read:

_Bluntin of ma nut wi ma cuz Pablo_

I couldn’t really make head nor tail of it, but the photo showed Steven Baird, arms around Ryan Baird, both smoking roll-up cigarettes. Clear as day. So there he is. In Scotland.

After the Thursday Murder Club meeting I asked Donna and Ron to come over.

First things first, I showed Donna the diamonds. She held the biggest one on her ring finger and walked up and down like a model. Then she made Ron do the same and they were both laughing. I took the opportunity of an empty kettle to make us all a cup of tea.

I showed them both the photo, and they both said I’d done a wonderful job. Ron hugged me. I will say this for Ron, he is not my type, but he is a very good hugger. He will make a very specific type of woman a very good husband one day.

It is a shame about Siobhan, because she might even have been that woman. I wonder who she actually is?

Donna translated the Instagram caption for me. It means ‘smoking cannabis with my cousin Pablo’. Pablo must be Ryan Baird’s nickname.

Donna said she would get straight on to Strathclyde Police and have him tracked down and arrested. But then I told her my plan instead. She and Ron both listened, and then agreed that my plan was much more fun.

They’ve just gone, the two of them, and the diamonds are back in the kettle where they belong.

Ron is off to see Connie Johnson tomorrow. I’d like to be a fly on the wall, I really would. You can see he feels ten feet tall at the moment, and I have every faith in him.

I can see the Post-it note in front of me still. Poppy’s smiley face. I don’t know at all, I really don’t.

Perhaps she’ll turn up on Fairhaven pier on Monday, or perhaps she really is dead, and this is a wild goose chase.

But I suspect that Elizabeth is right in one thing. If we get everybody together at the end of the pier, diamonds out in the open, then surely we’ll find out exactly who shot who and why.

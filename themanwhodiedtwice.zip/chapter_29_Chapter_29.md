## 29

Elizabeth is grasping the handle of the knife firmly with an overhand grip, the way she was taught more than fifty years before. An underhand grip, favoured by the Soviets, was briefly fashionable in the seventies, but overhand was back now. It allowed for much greater force, particularly if your assailant was bigger than you.

Elizabeth has still not heard a sound. This was very bad news. Should she alert the driver outside? Would she have a gun? She continues to climb the stairs. No sign of a disturbance anywhere. It all looked so staged, the silence, the open back door. Was Douglas playing a little trick? Ask Elizabeth to come and meet him and give her the fright of her life?

Elizabeth reaches the landing. She looks down and sees Joyce at the bottom of the stairs. Knife in an overhand grip. What a natural that woman is.

There are three doors leading off the landing. A bathroom door is half open. Elizabeth gives it a nudge and it swings further open. Nothing there. Underwear hanging on an airer. Toilet seat up, so she knows who used it last.

The two bedroom doors are shut. She slowly turns the handle of the first door, knife poised and ready. Won’t she look a fool if Douglas and Poppy are hiding behind the door giggling away? Why is she thinking this is all a trick? All so neat? It doesn’t look like a crime scene, it looks like an exercise. Was that it? Was this a test? See if the old girl has still got it?

She flings the door open and jumps into the room, flattening her back against the nearest wall. Nothing but a perfectly made bed, a Philip Larkin poetry book and a Jo Malone candle. Poppy’s room. But no Poppy. There is a bookmark in the middle of the Philip Larkin, ready for Poppy to return.

Elizabeth turns back onto the landing. Only one more room to go. The bedroom at the front of the house. Douglas’s room. The last remaining option.

She tightens her grip on the knife, and then has a thought. Poppy had been upset at shooting Andrew Hastings; it was traumatic, and she had even asked Joyce to contact her mother. What if Poppy had decided she’d had enough? Waited for Douglas to fall asleep. You could always tell when Douglas had fallen asleep. My God, the snoring. Perhaps she decided to make a run for it, and left the back door open as she went? All too much for her? She would know there was still an officer stationed outside the house to keep Douglas safe.

Her hand is on the door knob. She starts to turn it.

Elizabeth opens the door. She freezes. Just for a second. It wasn’t an exercise, and it wasn’t a trick. Of course Poppy would never have left the back door open. And, of course, Douglas could never be silently asleep.

Poppy’s body is slumped in the armchair, a bullet having made a mess of her face and turned that beautiful blonde hair red. One arm lies across her body, no doubt her attempt to shield herself from the bullet. The other arm lies limply by her side. Blood has run down the arm and dried. The white daisy, which had so secretly thrilled her grandmother, is now a crimson red.

Douglas is propped up on the bed. His bullet wound has caused even more damage than Poppy’s. He would be unrecognizable if you hadn’t once been married to him. The wall behind his head is black with blood.

Whatever Douglas had wanted her to see, surely it wasn’t this?

Elizabeth breathes deeply. She has to remain calm. This will not be her crime scene for long, so she takes out her phone and photographs it from every possible angle.

Elizabeth hears a noise behind her. She turns, knife raised, to see Joyce in the doorway. Joyce looks from Poppy’s body to Douglas’s body and back again.

‘Oh, Poppy,’ says Joyce. ‘Oh, Elizabeth.’

Elizabeth nods. ‘Don’t touch a thing. Downstairs, let’s go.’

Elizabeth ushers Joyce in front of her. She is glad that Joyce is not weak-minded; the last thing they need now is tears. Elizabeth opens the front door, telling Joyce to stay where she is. She rushes down the path and across to the Virgin Media van. Realizing she is still carrying her knife, she slips it into her handbag and knocks on the window. The bored driver winds it down once again.

‘You done, are you? That was quick.’

Elizabeth takes out her phone and shows her a photograph. ‘Both dead. While you’re sitting here reading.’

The driver is out of the van in a shot and races to the house. No doubt thinking about her once-promising career every step of the way.

Holding her phone, Elizabeth realizes she will be straight off for questioning as soon as the troops arrive, and that won’t be long. Her phone will be taken off her, the photographs deleted. She scans the front garden walls of St Albans Avenue until she sees what she needs two houses up. The driver has run into the house, so Elizabeth takes a brisk walk, dislodges a loose brick from the low wall, slides her mobile phone into the gap and then replaces the brick. The perfect dead-letter drop.

So now there are diamonds _and_ killers to be found.

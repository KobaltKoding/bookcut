## 31

So let’s see what Elizabeth Best has got, shall we? The great hero of the Service. Is she all she’s cracked up to be?

Sue Reardon can’t help but compare herself to the woman sitting directly across from her. Elizabeth Best. Silver hair and tweed jacket. Face impassive. What does she know? Or what is she willing to tell?

They have both killed people in their time. For good reasons, of course, but they’ve still done it. That creates a kinship and a respect. But also a suspicion. Elizabeth has every trick in the book, and Sue Reardon will need a few of her own to get what she needs. So be it.

The room is small, as they so often are.

Claustrophobia, that’s the idea. The walls are metal-plated up to waist height, and concrete above that. It has no windows, but cameras in each corner. The thick walls muffle the conversation. It looks like it would survive a nuclear explosion, and, indeed, that’s exactly what it has been designed to do. Lance James is pacing at the far wall.

‘Keep still, for goodness’ sake, it’s not helping anyone,’ says Elizabeth.

‘Sorry,’ says Lance.

Lance James is not the sort of man to sit still when he can stand and pace instead. He was seconded to Sue from the Special Boat Service, but she knows little else about him. He’s quiet and he’s hard-working, and that will do Sue just fine. He is in his early forties, and clinging on gamely to his medium-to-good looks. The already thinning blond hair, however, will soon thin further and grey, and then disappear altogether. A life of small rooms, stakeouts, late nights and stress; Sue has seen many a handsome man go south over the years. She gives Lance five years at most.

She had sat with Elizabeth and her friend Joyce in the back of a windowless van for the whole journey here. They had then been blindfolded as they were walked to this room. This was all to disguise their destination, but Elizabeth would know exactly where they were. Godalming. ‘The House’, they called it, in the isolation cells three floors below ground. She knows Elizabeth will have interviewed people in this very room during her time at MI5\. She would have been sitting in Sue’s seat. It had been given a spruce-up since then, some new grey paint on the ceiling. No cameras in those days either, which was probably best for all concerned.

‘You don’t hear of many Lances these days,’ says Joyce. ‘Is it a family name?’

‘Afraid so,’ says Lance.

Sue can see that Joyce has been thrilled by the whole experience. She had nodded off in the van, while Elizabeth was, no doubt, keeping track of time and direction, but she had particularly enjoyed the blindfolding. ‘Well, I can tell we’re going up in a lift, now,’ she had said on their way down to this subterranean floor.

Lance leans back against the wall and folds his arms across his muscular chest.

‘So you received a message from Douglas Middlemiss?’ says Sue. ‘Let’s start there, shall we? What time would that have been, exactly?’

‘I don’t know,’ says Elizabeth. She won’t want to give everything away. Or anything away, if she can help it. That’s fine. Softly, softly.

‘And can you show us the message?’ asks Sue, politeness itself. Sue is always polite in interrogations. The angry ones run out of patience long before you do.

‘I’m afraid not. It’s on my phone.’

‘And where is your phone?’ asks Sue. ‘It wasn’t in your bag, which we found strange.’

‘Oh, we don’t carry our phones everywhere, Sue,’ says Joyce. ‘Purse, keys, a bit of make-up just in case, and a bag for life, that’s all you really need.’

Sue nods at Joyce. It’s a double-act, is it? I need to keep an eye on this Joyce, too? What a tiny, formidable woman. Exactly the sort of woman you’d want parachuted behind enemy lines with a gun and a cipher machine. She turns back to Elizabeth. ‘I wonder where it is then, Elizabeth?’

‘Well, I wish I could remember,’ says Elizabeth.

‘You don’t remember where your phone is?’ says Lance from behind her. About time he piped up.

‘I’m afraid not. It comes to us all, dear,’ says Elizabeth.

‘I once searched the whole flat for mine,’ says Joyce. ‘Honestly, twenty minutes it must have taken. And it was in my hand all along.’

‘I wouldn’t wish it on you, Lance,’ says Elizabeth. ‘Cherish your youth.’

Lance finally leaves the wall. He walks over and takes a seat next to Sue Reardon. Sue leans forward and addresses Elizabeth directly. ‘I’m guessing it’s at your flat?’

‘One would imagine so,’ agrees Elizabeth.

Sue gives a satisfied nod. ‘That does sound the most likely, doesn’t it? So you’ll be comfortable with me sending a team over to search for it?’

‘Aren’t the rules these days that everything has to be left immaculate after a search?’ asks Elizabeth.

‘Those were always the rules,’ says Lance.

‘Yes, but now you actually have to abide by them? European Court of Justice sticking their oar in?’

‘Everything will be left immaculate,’ says Sue. What’s on that phone? Messages? Photographs?

‘Well, in that case you go right ahead. It needs a tidy,’ says Elizabeth. ‘That will be fun for Stephen, a team of goons in the flat at the dead of night. He’s a fine host.’

‘She might even have left it with me,’ says Joyce. ‘If you want to give my flat a once-over, too? Especially the bathroom.’

‘In the absence of the phone for now, can you remember what the message said?’ asks Sue. ‘The exact words?’

Elizabeth nods, and recites from memory. ‘Poppy and I have been moved to 38 St Albans Avenue, Hove. I would be obliged if you would meet me there. There is something I want to show you.’

‘So you can remember the exact words of the message,’ says Lance. ‘But not where your phone is?’

Elizabeth taps her head. ‘My palace has many rooms. Some are dustier than others.’

Sue notices that Lance can’t hide a little smile. These two are a piece of work, all right.

Sue nods again. ‘You poor thing, ma’am, that must be dreadful. And that was the whole message? Nothing else?’

‘Well, it also said come alone, but I thought Joyce would enjoy it.’

‘Thank you,’ says Joyce. ‘I did. Up to a point.’

‘And do you have any idea of what he wanted to show you?’

Elizabeth pauses. She looks up at the cameras. As she looks back at Sue Reardon, she makes up her mind.

‘Honestly, I assumed he wanted to show me the diamonds.’

‘You think he had the diamonds with him?’

‘What else could it be?’ asks Elizabeth.

‘That’s assuming he stole the diamonds in the first place,’ says Lance. ‘And we have no evidence of that.’

‘Well,’ says Elizabeth, ‘and I realize I probably should have passed this on before now, but I know he stole them. He told me.’

‘When did he tell you this, Elizabeth?’ asks Sue, still calm.

‘Oh, a few days ago, perhaps,’ says Elizabeth.

Sue is unsurprised. Of course Douglas told her. He trusted her. He loved her. ‘But he didn’t have the diamonds with him at the safe house, Elizabeth. He’d been searched. Before he got there. While he was there. And after someone blew his head off. So what else might he have wanted to show you?’

‘Perhaps he wanted to show Elizabeth a key, or a code, or a riddle,’ says Joyce. ‘To let her know where the diamonds were? I can’t do riddles at all. What’s the one about the man who can only lie and the man who can only tell the truth?’

Sue realizes that Joyce is waiting for an answer, so gives her an ‘I’m as baffled as you, Joyce’ shrug.

‘That’s very good, Joyce,’ says Elizabeth. ‘And now, of course, whoever killed Douglas and Poppy, let’s assume Martin Lomax, will have that information instead. Riddle or not. So Martin Lomax can get his diamonds back.’

‘Perhaps Martin Lomax isn’t the only person with a motive for shooting Douglas and Poppy, though?’ says Joyce.

‘Of course,’ says Sue.

‘All that money. Twenty million. We’d all like it, wouldn’t we?’ Joyce adds.

There is a general agreement that they would. It’s out there somewhere. But where?

‘And, as Elizabeth will tell you, there were two people in the house the night that the diamonds were stolen,’ Joyce goes on. ‘Douglas and Lance. And I think we’re taking Lance’s word a bit too easily. I mean no offence by this, Lance, but we don’t know you one bit, do we? Who’s to say you didn’t see Douglas steal the diamonds? And you’ve been looking for a chance to get your hands on them?’

‘Well, I wasn’t going to say that out loud,’ says Elizabeth. ‘But now the cork is out of the bottle. And since we’re being filmed, it’s worth discussing.’

‘Discuss away,’ says Lance, ‘I have nothing to hide.’

‘Almost certainly not,’ agrees Elizabeth. ‘But you were in the house on the evening of the theft. You knew where Douglas and Poppy were being kept. You probably appointed Poppy to this job in the first place, an unusual appointment.’

‘So perhaps you were even in league with her?’ says Joyce.

‘Total conjecture, of course,’ says Elizabeth. ‘But I trust this will all be investigated?’

‘Oh, it will all be investigated,’ says Sue. This is more like it. ‘Lance will quite rightly be a suspect, and I will add another suspect to the list. Probably the only other person who knew that Douglas was at Coopers Chase and at St Albans Avenue. A confidante and an ex-wife of the dead man. A woman trained in breaking and entering, a woman trained in killing, a woman who has conveniently mislaid her mobile phone. She would be a suspect, too, don’t you think?’

‘She certainly would,’ agrees Elizabeth. ‘As would you, of course, Sue. I imagine you have every skill I had, and a few more they’ve thought up in the meantime. Let’s say you suspected that Douglas had stolen the diamonds?’

‘Let’s say that, yes,’ confirms Sue. She’s happy now the conversation is opening up a bit. A chance to observe Elizabeth a little better. Start to read her.

‘Or let’s say you knew already? Let’s say you and Douglas were more than colleagues? You wouldn’t be the first person Douglas has seduced.’

‘Let’s say not everyone would make the same mistake you made?’ says Sue. Interesting line of attack from Elizabeth.

‘Touché,’ says Elizabeth. ‘But twenty million pounds suddenly swimming around. And only one man knows where it is? That might be tempting?’

‘I should think so,’ says Sue. ‘Very tempting.’

‘And you, of course, would have had ample opportunity to kill Douglas and Poppy. You knew where they were, you would have access, you would have their trust. You were in charge of putting them there and, no doubt, you’ll be in charge of cleaning up the mess.’

Sue nods. ‘I’m beginning to wish I had thought of this now. Aren’t you?’

‘I think I might have thought of a way of doing this without killing anyone, though,’ says Elizabeth.

‘I hope you might extend me the professional courtesy of imagining that I might have, too,’ says Sue. ‘I worked with Douglas for nearly twenty years.’

‘My condolences,’ says Elizabeth. ‘Now, while we agree that anyone in this room, other than Joyce, might have murdered Douglas, it does feel that a trip to see Mr Lomax might be in order.’

‘Under no circumstances are you to visit Martin Lomax,’ says Sue. ‘We’ll be dealing with him.’

‘Of course,’ says Elizabeth. ‘Don’t visit Martin Lomax. We must try to remember that, Joyce.’

Joyce nods. ‘Understood.’

‘Now, Elizabeth,’ says Sue. ‘You said Douglas wanted to show you something?’

‘I did say that.’

‘Well, we found this in his jacket pocket.’ Sue reaches into an evidence bag and pulls out a silver locket. It has a mirror inside, nothing else. Will it mean anything to Elizabeth? ‘I wondered if this was what he wanted to show you?’

She sees that Elizabeth recognizes it immediately. Well, of course.

‘It’s inscribed with your name.’

Elizabeth picks up the locket. She weighs it in her hand and flicks it open to see the mirror. Sue sees that she is thinking, and she knows what Elizabeth is thinking too.

Sue smiles at her. ‘Very touching, Elizabeth. He must have loved you very much?’

‘In his way,’ agrees Elizabeth.

‘You lucky thing,’ says Sue. ‘The love of a good man. Or a man, at the very least.’

Elizabeth smiles to herself.

‘Now, it’s midnight,’ says Sue. ‘And you have beds to get to.’

And Sue still has one more job to do this evening. Not a pleasant one, but an important one. Lance leads Joyce and Elizabeth from the room. Sue will be sticking close to them from now on.

## 57

‘I just remember there used to be much more dancing,’ says Donna. ‘You know? Not so long ago. What happened to all that?’

‘I don’t dance,’ says Ibrahim. ‘I don’t have the fast-twitch muscle fibres for it.’

‘And the drugs, and the friends, and the laughs. I miss it all.’

‘They don’t let you take drugs in the police,’ says Ibrahim. ‘You are unlucky there.’

‘Spoilsports,’ says Donna. Her eyes are still closed, but Ibrahim makes her smile.

‘Frowned upon, I bet,’ says Ibrahim, and then looks at his pad. ‘Dancing, drugs, friends, laughs. Which one of those do you imagine I’m thinking is most important?’

‘I’m guessing not drugs,’ says Donna.

‘Friends, Donna, that’s where it all comes from. You dance with friends, you do drugs with friends, you laugh with friends. That is what’s gone. The friends. Where are they?’

Where have they gone? Where to begin? ‘London, America, having babies with men I don’t like, found religion, got proper jobs, one of them joined UKIP. No one’s got time, everyone’s busy. Except Shelley, and she’s in prison.’

‘So no one’s dancing any more?’

‘If they are, they’re not dancing with me,’ says Donna. ‘Who are my closest friends? Chris, who’s sleeping with my mum. My mum, who’s sleeping with Chris. You lot, and, back me up here, my best friends shouldn’t be in their seventies.’

Ibrahim nods. ‘Agreed. Maybe one would be OK, but four of us seems a bit much.’

‘The only person my age I’ve met down here who I actually like is Connie Johnson, and she’s a drug dealer. I bet she dances though.’

‘And she certainly does drugs, I imagine,’ says Ibrahim.

Donna smiles again. Her eyes have remained shut. This is peaceful, this is helping. Just saying things out loud. Was this therapy? It didn’t feel like it. It just felt like finally telling somebody the truth.

‘Open your eyes now, Donna, I want to talk to you in a different way.’ Donna does as she is told and Ibrahim looks deeply into her eyes. ‘You know that time is not coming back, don’t you? The friends, the freedom, the possibilities?’

‘You’re supposed to be cheering me up,’ says Donna.

Ibrahim nods. ‘Let it go. Remember it as a happy time. You were at the top of the mountain, and now you’re in a valley. It will happen to you a number of times.’

‘So what do I do now?’

‘You climb the next mountain, of course.’

‘Oh yeah, of course,’ says Donna. Simple. ‘And what’s up the next mountain?’

‘Well, we don’t know, do we? It’s your mountain. No one’s ever climbed it before.’

‘And what if I don’t want to? What if I just want to go home and cry every night, and pretend to everyone that everything’s OK?’

‘Then do that. Keep being scared, keep being lonely. And spend the next twenty years coming to see me, and I will keep telling you the same thing. Put your boots on and climb the next mountain. See what’s up there. Friends, promotions, babies. It’s your mountain.’

‘Will there be other mountains after that one?’

‘There will.’

‘So I can leave babies until another mountain?’

Ibrahim smiles. ‘You do whatever you want. But looking forward, not back. And I’ll be here as you climb. That armchair is yours whenever you need it.’

Donna looks up, breathes out and blinks tears from the corners of her eyes.

‘Thank you, I’ve felt a bit stupid recently.’

‘Loneliness is hard, Donna. It’s one of the big ones.’

‘You should do this for a living, you know?’

‘You are simply a little lost, Donna. And if one is never lost in life, then clearly one has never travelled anywhere interesting.’

‘And you?’ asks Donna. ‘You seem sad.’

‘I’m a little sad, yes,’ agrees Ibrahim. ‘I’m frightened, and I can’t see a way through it.’

‘Up the next mountain would be my advice,’ says Donna.

‘I’m not sure I have the energy,’ says Ibrahim. His eyes start to fill with tears in turn. ‘My ribs hurt, and that makes me feel like my heart hurts.’

‘I’ll be here as you climb,’ says Donna, and takes Ibrahim’s hand. She has never seen Ibrahim cry before, and she never wants to again.

‘Don’t tell the others,’ says Ibrahim.

‘They already know,’ says Donna, and Ibrahim nods.

‘Even Ron,’ he agrees.

Donna squeezes his hand. ‘And if you ever breathe a word of this conversation, I will taser you.’

‘Quite right,’ says Ibrahim. ‘Now, shall we solve a murder?’

‘Yes, let’s,’ says Donna.

Ibrahim indicates the underneath of his eyes to Donna, and she goes into the bathroom to fix her make-up. When she returns, Ibrahim has loaded the footage she brought with her onto his computer. Who is the mystery person in the motorcycle leathers?

Donna sits on the edge of his chair, and Ibrahim presses play.

## 76

Chris Hudson munches on a carrot baton. When you got used to them they actually weren’t so bad. Well, they were, but it seemed to matter less. Connie Johnson is in her cell. Her interview had been terminated fairly quickly. It consisted almost entirely of threats to kill him, Donna, Bogdan and whoever she imagined Ron to be. Bogdan came in for some particularly graphic abuse. No mention of Patrice though, that particular threat forgotten. He will never mention it to Patrice or Donna. And he knows Ron or Bogdan won’t either.

Ryan Baird’s interview had been a quieter affair. Eight minutes of silent, shoulder-shaking sobbing, before his solicitor suggested they might reconvene in the morning. Perfect. An evening off for Chris.

Ryan Baird’s solicitor, Chris couldn’t help but notice, was still dressing better, now had a nicer haircut and was even starting to lose some weight. He was doused in Lynx Africa, but, as Chris well knows, you can’t change everything all at once. After the interview the solicitor had taken Donna aside and asked her out for a drink. His wedding ring in his pocket, no doubt. Donna had told him she would love to, but that they should probably wait, so as not to jeopardize the ongoing investigation. Even at the end of a long day, Donna was a quick thinker.

Chris’s mind goes back to the table outside Maidstone Crown Court. The promises Ron and Bogdan had made him. They had come good, thank you, gents. Patrice will come down to Fairhaven again next Sunday and this time Chris will tell her that he loves her. Sometimes the universe turns your way. He hopes that Elizabeth and Joyce got what they wanted from today too.

A man voluntarily eating carrot batons. That really was someone to be.

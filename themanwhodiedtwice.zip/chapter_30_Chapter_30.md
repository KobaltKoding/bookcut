![Penguin walking logo](./images/00005.jpeg) 


## 30

Patrice is on half-term and is staying with Chris. Chris still can’t quite get used to it. He is pretending to eat healthily, which, after a couple of days, he realizes is the same as actually eating healthily. An apple is an apple whether you are eating it because you like to take care of yourself or you are eating it to impress a new girlfriend. The nutrients are the same. Chris hasn’t had a Snickers since Monday.

Tonight they had been due to go to Le Pont Noir for dinner. Formerly a dive called the Black Bridge, it is now Fairhaven’s leading, if only, gastropub. On Tuesdays they have a jazz trio playing in the dining room. Chris has never enjoyed jazz, never even quite worked out which bit he was supposed to be enjoying, but he does know that people who like jazz seem to enjoy life, and that he needs to pretend to enjoy life a bit more than he does. And what if it’s the same as apples? What if pretending to enjoy life is the same as actually enjoying it? He has been smiling from the moment Patrice arrived, so perhaps there was something in it.

Patrice got things from him too, he knew that. He could objectively see that he was kind and funny. He had a proper job, catching criminals. Anything else? He had been told he had nice eyes. He was a good kisser.

Everything else could be covered up for now. Don’t run before you can walk, Chris. And do all women tell all men they are good kissers? Chris supposes so. What does it cost them?

The call from Donna came at around six thirty. Ryan Baird had been arrested and was on his way to Fairhaven Police Station. No jazz for Chris, which was a relief; that new leaf could wait.

Patrice had been very understanding. Suspiciously understanding, in fact. What if Patrice didn’t like jazz either? What if they were both pretending? That was something to explore. It would certainly be an enormous relief.

Chris had driven to the station, interviewed Ryan Baird, who had screamed blue murder about being framed by a plumber, and had eventually been charged with possession with intent to supply as well as robbery and led to a cell. His solicitor looked a little perkier than last time, too, so either he enjoyed seeing Ryan being sent down, or he too had escaped an evening of jazz.

Chris had texted Patrice, and they are now sitting in the snug of Le Pont Noir, the only evidence of the evening’s jazz a solitary drumstick on a walnut barstool.

Chris and Patrice are together on a leather sofa, and opposite them, legs tucked underneath her in a deep armchair, is Donna. Chris’s partner, Patrice’s daughter.

‘The Thursday Murder Club?’ asks Patrice.

‘There’s four of them,’ says Donna. ‘Ibrahim was the one who had his phone stolen. Ron was the plumber.’

‘And who got hold of ten grand’s worth of coke?’

Donna looks at Chris. ‘I’m guessing Elizabeth?’

Chris nods. ‘I’d have thought so. I mean, never rule out Joyce.’

‘But isn’t it all illegal?’

‘Very.’

‘And wouldn’t you get in trouble if it came out?’

‘Mum,’ says Donna, ‘I got a call from a plumber saying he’d found cocaine and a stolen bank card at a flat. There were screams. I went to the flat and found the cocaine and the bank card. I arrested the youth present at the scene. Chris and I questioned him. He denied all charges …’

‘Which they often do,’ says Chris.

‘Which they often do. We felt there was sufficient evidence to charge him, and so we charged him.’

‘And what about when it comes to court? When they call this plumber as a witness and he isn’t a plumber?’

Donna shrugs. ‘I’m guessing Elizabeth will have thought of that.’

Patrice raises her whisky glass and the ice cubes tinkle in salute. ‘They sound like a hell of a gang. I’d love to meet them.’

‘We’re keeping you a secret for now,’ says Chris.

‘Are we?’ says Patrice, stretching a leg across Chris’s lap.

‘I’m involved about as much as I want to be with the Thursday Murder Club. If they can plant cocaine in someone’s cistern, I don’t want to think about what they’d do with my love life.’

‘Cute you said “love life” and not “sex life”,’ says Patrice.

‘Don’t say “sex”, Mum,’ says Donna. ‘Stop showing off.’

‘I meant my personal life,’ says Chris.

‘Too late, you said it now,’ says Patrice.

‘That lot would have us married in weeks,’ says Chris.

‘How awful,’ says Patrice with an eyebrow raised.

‘Mum, stop pretending you want to marry Chris just because you’ve had two whiskies. Don’t make me regret introducing you two.’

‘Have you heard from Elizabeth, by the way?’ Chris asks Donna.

‘Not a peep,’ says Donna, checking her phone. ‘You’d think she’d be loving this. Ryan Baird in custody.’

Chris looks at his watch. ‘Well, it’s half ten, you know that lot. She’ll be tucked up in bed by now.’

‘Talking of which,’ says Patrice, looking straight at Chris and playing with her necklace.

‘Oh God, Mum, puke,’ says Donna, and finishes her whisky with a shake of the head.

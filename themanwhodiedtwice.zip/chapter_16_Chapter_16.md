## 16

Ibrahim can’t sleep.

The air around him is still. How many people have died in this hospital room? In this bed? In these sheets?

How many final breaths still hung in this air?

When his eyes close he is back in the gutter. He feels the water, he hears the footsteps, he tastes the blood.

The kick to the head now has a name. Ryan Baird. Where was Ryan Baird, he wonders. Where was Ibrahim’s phone? Who bought stolen phones? Ibrahim had a _Tetris_ app on his phone. There were 200 levels, and he was on level 127 after playing for a considerable amount of time. All of that progress was lost.

He looks at the red plastic tag on his wrist. The admin of death. There will be a drawer full of them somewhere.

He has finally persuaded Ron to go home. Not that he isn’t grateful for the company. Each night so far Ron has stayed up with him and talked about West Ham and the problem with the Labour Party. And then, even later in the night, about his ex-wife and daughter, his son, Jason, and about leaving school at fourteen and never knowing his dad. Anything, really, other than talk about what had happened. They watched _Die Hard_, but only the first one. No point watching the others, apparently. Ibrahim has never had a friend like Ron before, and Ron has never had a friend like Ibrahim before. Ron will fill his water jug when it needs filling, will get him Frazzles from the machine, but will never make physical contact, no hand on his arm. Which is just fine by Ibrahim. It must be harder being a man these days, he thinks, being expected to hug.

Ibrahim wants to go home, which he knows is a positive thing. It was positive to have a home in which he felt safe. To be surrounded by people who made him feel safer still.

But he knows he will then never want to leave home again.

Things would get back to normal. The brain is tremendously clever, one of the reasons Ibrahim likes it so much. Your foot was your foot and would remain your foot through thick and thin. But the brain changes, in form and in function. Ibrahim has respect for podiatrists, but really, looking at feet all day?

The brain. That magnificent, dumb beast. He knows that alien chemicals are currently racing around his brain, protecting him in this moment of crisis. In time these chemicals would fade, leaving nothing but a faint stain. When they say that time heals, that’s what they mean. Like most things, when you really drill down into them, it is neuroscience, not poetry.

Yes, time heals, time heals. But what if time is the one thing Ibrahim doesn’t have?

_I don’t really believe in revenge_. That’s what he had said to the others when they talked about Ryan Baird. And in theory he didn’t. Revenge is not a straight line, it’s a circle. It’s a grenade that goes off while you’re still in the room, and you can’t help but be caught in the blast.

Ibrahim had once had a client, Eric Mason, who had bought a used BMW from a dealer, an old school friend, in Gillingham. He soon discovered that the car had a faulty clutch. His friend at the dealership refused to accept liability and Eric Mason, who, it should be said, had issues around emotional control and anger management, had replaced the clutch at his own expense and then driven the BMW straight through the window of the dealership in the dead of night.

The car had then stalled – understandably, as it had just been driven through a large window – so Eric Mason was forced to abandon it and flee as alarms blared all around him. Unfortunately, he fell and impaled himself on a large shard of glass, and was saved from bleeding to death only by the arrival of the police.

Recovering in hospital, Eric Mason received a huge bouquet of flowers from the dealership, but, upon opening the card, discovered they had attached a court summons and a bill for £14,000\. A spell of community service and bankruptcy followed. His fury grew.

Eric’s daughter and the son of the car dealer had also been friends at school. Eric forbade his daughter from ever talking to the boy again and so, as winter follows summer, they had got married two years later, with Eric refusing to attend the wedding. Another year later and Eric’s grandson was born. Neither side would give ground, so Eric was unable to see his first grandchild. All because of a faulty clutch.

It was at this point that Eric felt perhaps he should take responsibility for his own actions, and decided to see a psychotherapist.

Twelve months later, on his final visit to Ibrahim, Eric Mason had brought in his daughter and his son-in-law to say thank you in person. He had also brought in his infant grandson, and they had posed together for a photograph, smiles all round.

Ibrahim could feel himself drifting off and decided to stop fighting it. Whatever was waiting for him in his dreams, it was best to just face it unafraid. Accept the damage Ryan Baird had inflicted on him without thinking. Not the ribs, not the face – they would heal soon enough – but his freedom and his peace of mind, snatched away for a phone.

They say a man who desires revenge should dig two graves, and this is surely right. Then again, Ibrahim feels like his own grave has already been dug, so would there really be much harm in digging another for Ryan Baird? He wonders what his friends have in store for Ryan. Nothing physical, Ibrahim is sure of that. But freedom and peace of mind? Ryan might have a little surprise coming.

The photograph of Ibrahim, Eric Mason and Eric’s grandson was in a special file Ibrahim kept at home. A file filled with a few mementos, not too many, all reminding Ibrahim why he loved his job. The file is the only one on Ibrahim’s shelves that isn’t kept in strict alphabetical order. Because sometimes you had to remember that life wasn’t always arranged in alphabetical order, however much you would like it to be.

Eric Mason, years later, discovered that nothing had been wrong with the clutch at all. He simply hadn’t understood the electronic controls, and pressing a reset button for five seconds would have cleared it up. So you do have to be careful with revenge, but, in all honesty, Ibrahim has spent most of his life being careful, and sometimes you had to do things differently if you wanted to grow as a human being.

Ibrahim is certain that he could just press his own reset button for five seconds, and he could go on with forgiveness in his heart, go on doing the right thing, the correct thing, the boring thing. The cruise control.

But he still remembers Eric Mason, for all of his regrets, talking about the sheer ecstatic thrill of driving his car through that dealership window.

And it is that image, not the kick to the head, not Ryan Baird’s footsteps and not the taste of blood, that Ibrahim is thinking about as he falls into his first peaceful sleep since the attack.

## 65

The game of chess has finished, and the real work of the evening has begun.

Elizabeth still feels a little woozy from the Belgian beers on the train. And the glass of wine at the station as they waited for their taxi. And the gin and tonic Bogdan had waiting for her when she walked through the door. And the second gin and tonic she is currently drinking.

Bogdan and Stephen had ground out an attritional draw. Bogdan had called Stephen all the names under the sun and Stephen had smiled and said, ‘Let it out, old boy, let it out.’

The three of them now sit in the living room. Elizabeth and Stephen on the sofa, hand in hand, and Bogdan on the armchair, legs spread wide. It is 1 a.m. But no one much minds. Bogdan is drinking Red Bull and Elizabeth wonders, once again, what time he normally goes to bed.

Bogdan has filled her in on the trial. Ryan Baird has done a disappearing act. Don’t tell Ibrahim. They will soon find him, though; they still have the file that Poppy put together.

Poppy? Now, what was happening there? What signs had Elizabeth missed?

Everyone was capable of stealing. She once knew a vicar who had stolen, and melted down, a crucifix from his own church because he had lost money on the horses. But not everyone was capable of killing. Was Poppy? It seemed so unlikely, but Elizabeth has been fooled before, not often, but she has. She watches Bogdan, pouring himself an energy drink, looking as innocent as the day is long.

And Poppy had shot Andrew Hastings. She had been shaking afterwards for sure, but anyone could fake that. Involuntarily, Elizabeth starts to shake.

‘You cold, dear?’ asks Stephen.

You see, it was easy. Stephen puts his arm around her and she settles her head on his shoulder. What a man. Also, Poppy’s generation were used to generating fake emotion, weren’t they? A whole generation, outraged at the slightest thing, sensitive to the slightest criticism, honestly, whatever happened to … wait a minute, she realizes she doesn’t really believe that, she had just read a _Daily Express_ someone had left on the train. Most young people were like Donna, fighting new fights. Good luck to them.

She nestles further onto Stephen’s shoulder. The thought crosses her mind briefly, what if _neither_ of them is dead? What if they’re in it together?

What if Poppy and Douglas were lovers?

Elizabeth wouldn’t put it past Douglas. He liked nothing more than a woman he couldn’t have. Or shouldn’t have. Would move heaven and earth to get her, promise the world.

But Poppy? Honestly, she found it more likely that Poppy would kill Douglas than would fall in love with him. Though it was often a fine line, wasn’t it? Especially with Douglas.

Bogdan has just polished off another Red Bull. ‘So Poppy says, “I kill you, Douglas, unless you tells me where the diamonds really are.”’

‘The nerve,’ says Stephen.

‘Mmmm,’ says Elizabeth. She is sleepy and comfortable. There is no way Poppy and Douglas were lovers.

Bogdan continues the theory. ‘Then Douglas tells her, “I buried them under a tree, by a fence, don’t kill me,” but she shoots him anyway.’

‘Joyce any nearer buying that dog?’ asks Stephen.

‘What, darling?’ says Elizabeth.

‘Your pal, Joyce. She was after buying a dog?’

The things Stephen remembered.

‘No, dear, on hold while everyone’s being shot, I think.’

‘Time and a place,’ agrees Stephen.

‘Douglas would lie, of course,’ says Elizabeth. ‘He wouldn’t tell Poppy where the diamonds were in a month of Sundays.’

‘I should think not,’ says Stephen. ‘Pointing a gun in his face, asking him about diamonds? The cheek of the girl.’

‘So Poppy is out there still,’ says Bogdan. ‘Looking for the diamonds.’

‘Furious, no doubt,’ says Stephen. ‘Would anyone like dinner, by the way? There’s a lasagne?’

‘Maybe later, not now,’ says Bogdan.

‘So what would you do, if you were Poppy?’ asks Stephen. ‘What are the options?’

‘Is obvious,’ says Bogdan.

‘Oh, good,’ says Elizabeth, deciding she should probably rouse herself from Stephen’s shoulder. There was work to do.

‘I would just keep an eye on Elizabeth,’ says Bogdan. ‘Sooner or later she knows you find the diamonds.’

‘Oh, Elizabeth will find them all right,’ says Stephen. ‘She’ll waltz back in, pockets jingling with them.’

‘And when Elizabeth finds them, Poppy will be watching and waiting,’ says Bogdan.

‘So to find Poppy I need to find the diamonds?’ says Elizabeth. ‘Which is proving impossible.’

‘No such thing as impossible, dear,’ says Stephen. ‘There’ll be a clue you’ve missed somewhere. Read the letter again.’

‘It’s not in the letter,’ says Elizabeth. ‘We’ve been through the lot.’

‘You’ll figure it out,’ says Stephen. ‘It’ll be that ex-husband playing silly buggers.’

‘We just need a trap,’ says Bogdan.

‘With the diamonds as bait,’ says Stephen. ‘Get the brain in gear, old girl.’

‘I’m afraid my brain has had a long day,’ says Elizabeth. A long day of thinking, a long life full of thinking. So much thinking. Just to find that all she was looking for was this. A Polish man too big for the chair he is sitting in, and a lovely white-haired man who thought he could explore Venice without a map.

Elizabeth rests her head on Stephen’s shoulder once more and shuts her eyes. The last thing she sees before they close is the mirror on her far wall. Who is that old woman looking back at her? Lucky thing, whoever she is. She sees the reflection of her husband, still in his tie and his smart shoes, and the reflection of Bogdan, his shaved head, his muscles, and the NIKE logo on his T-shirt, reading EKIN in the mirror.

She opens her eyes again.

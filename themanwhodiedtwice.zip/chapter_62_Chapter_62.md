## 62

Ryan Baird is a genius, plain and simple. The court case was a stitch-up, that was obvious. Someone had it in for him. Who knew who? Who cared? All it proved was that Ryan was a face, that Ryan had enemies. And what was a villain without enemies? Nothing.

He is sitting in his cousin Steven’s flat. They are in Scotland. He forgets where exactly, some town near Glasgow. Begins with a C. He’d got the train up the day before the hearing. No ticket or nothing. If you were Ryan Baird, if you were a face, if you had enemies, you didn’t have to pay for train tickets. In the event he had actually been caught by a ticket inspector, hiding in the train toilet, and been thrown off at somewhere called Doncaster. He’d then got back on the next train, only to be thrown off at Newcastle, where he had had to sleep, because the last train had already gone. But he had made it up to Scotland eventually and his cousin had come and picked him up. Ryan Baird 1, LNER 0.

His mum had told him years ago that if you learn a trade you will never be out of work, and she was absolutely right. Within two hours he was dealing wraps of cocaine.

And now he’s sitting playing _FIFA_ with Steven, nice big spliff on the go, KFC done and dusted. Genius.

Who would ever think of looking for him in Scotland? No one. It was miles away. They might look for him in London. Maybe they’d go as far as Luton, but he doubts it. Ryan has never been to Scotland before, and he sees no reason why the police would either.

To be safe, he’s calling himself Kirk, a name he has always fancied. Even if the police do make it all the way up here, and ask around, no one will have heard of Ryan Baird. It’s foolproof.

Admittedly he has called himself Ryan three or four times today, but only after a few drinks with Steven’s mates, and they all seem sound enough.

A bit earlier he had put on the local news to see if he was on it. Kent drug dealer on the run. ‘Police say Ryan Baird is dangerous and shouldn’t be approached.’ But the local news up here was all Scottish. Who gave a toss about all this Scottish stuff? Someone had burned down a leisure centre, but that was the only good bit.

He’d got a job, a roof over his head, and a new name, all in one day. He had watched a programme about Pablo Escobar on YouTube, and this was just what Pablo would have done. In fact, Pablo! That was a much better name. Forget Kirk, from tomorrow he’d be Steven’s cousin, Pablo.

Pablo Escobar got shot in the end, of course. But that’s because he’d got careless. That won’t happen to Ryan.

Scotland! You had to hand it to him.

## 55

Coopers Chase looks beautiful in the late-autumn sun. As Donna walks up towards the village a llama tilts a quizzical head towards her over a white fence. Donna nods a good morning to it. On the lake to her right, a goose misjudges a landing, inelegantly belly flopping into the water. She swears the goose looks round to make sure none of the other geese were watching.

Up ahead a woman with a cane sits on a bench, her face raised to the sun. Donna wonders if the woman might be lonely, until a man in a panama hat sits down next to her, with sandwiches and two newspapers. The _Daily Mail_ for him, the _Guardian_ for her. How had they made that work over the years, she wonders. The heart wants what it wants, of course.

She passes another couple, hand in hand, and they both smile and wish her a good morning. They are walking down the path to sit by the lake.

When will Donna get to walk down a path, hand in hand, and sit by a lake?

The path broadens out as it reaches the village, the first building being Willows, the nursing home. Last time she had visited had been when Elizabeth took her to meet Penny, former cop and Elizabeth’s best friend. No longer there, of course. Some other poor soul in her bed.

Would Elizabeth be in there one day? Would Joyce? Would Ron? Surely not Ibrahim? The thought of any of them so diminished upsets her, and Donna keeps walking past Willows with her head down.

Ibrahim’s block lies ahead to her left, through a pretty garden still bursting with colour. A lady using a walking frame moves to one side to let her through and says, ‘Cheer up, my darling, it might never happen.’ Donna gives her a small smile in return.

_It might never happen_. Well, yes, wasn’t that just the problem?

Walking up the stairs, Donna wonders again what she is doing here. Everybody goes through tough times, don’t they? Everyone feels low? They don’t go bleating all their troubles to a psychiatrist, do they? Not where she’s from. You don’t have psychiatrists in Streatham. You have mates with shoulders to cry on. To tell you to pull yourself together.

But Donna doesn’t have mates in Fairhaven, and so here she is.

Ibrahim’s door is open as Donna reaches the top of the stairs. The man himself moves gingerly, and is able to give her only the gentlest of hugs.

‘Sit down, sit down,’ says Donna.

Ibrahim braces himself against the arms of his chair and manoeuvres himself with awkward grace into it. Donna settles herself opposite him, in a beaten-up armchair beneath a painting of a boat. Just a regular police officer, paying a regular visit to a friend who just happens to be a psychiatrist. She won’t say anything though, it feels silly now she’s actually here. They can just look at the CCTV. She’s OK, just a bit down.

‘Nice to see you out of bed,’ says Donna. ‘How’s the pain?’

‘It’s getting better,’ says Ibrahim. ‘It only really hurts if I breathe.’

Donna smiles. ‘Shall we take a look at this CCTV? I thought you might enjoy it?’

Ibrahim nods. ‘In good time, in good time. But first, how is _your_ pain, Donna?’

‘How’s my pain?’ asks Donna, with a laugh. Oh, OK, is this how it’s going to work? Is this how therapy starts?

‘Yes,’ says Ibrahim, tilting his head to one side, reminding Donna of the llama. ‘How is your pain?’

‘I hurt my wrist in the gym, but that’s the best I’ve got,’ says Donna. She shouldn’t be here, wasting Ibrahim’s time.

‘Is that so?’ asks Ibrahim. Well, it’s more of an observation than a question.

Donna sees that Ibrahim has a large writing pad on the table beside his chair. He reaches over for it and takes a pen from his shirt pocket. OK.

‘I have no interest in putting words in your mouth, Donna,’ says Ibrahim. ‘But you really could have just looked at this new CCTV by yourself. Or sent it to me. Or arranged to meet all of us. But you asked to see me alone?’

‘I wanted to see how you are,’ says Donna.

‘That’s very kind of you,’ says Ibrahim. ‘Which is not unexpected, because you are a very kind woman. As luck would have it, I wanted to see how you are, too. So how about we have a little chat, and we see how we both are?’

She can’t fool Ibrahim, so here we go. She is now Gwyneth Paltrow or something. Donna sits back in the beaten-up old armchair, nods, and closes her eyes. ‘OK.’ It’s not really therapy, is it? If you’re just talking to a friend?

Ibrahim looks down at his watch. ‘Where do you want to start? Leaving London? Your mum and Chris?’

Donna tips her head back and breathes in deeply through her nose.

‘Perhaps we should start with loneliness?’ suggests Ibrahim.

Through Donna’s closed eyes, tears begin to escape.

‘Does it hurt?’ asks Ibrahim.

‘Only when I breathe,’ says Donna.

She wonders how Chris is getting on this morning.

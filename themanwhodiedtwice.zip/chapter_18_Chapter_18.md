## 18

Ryan Baird is awake. He is currently playing _Call of Duty_ online. He is spraying machine-gun fire at full volume while his neighbours bang on the walls. Ryan made £150 today, selling a couple of laptops, a debit card and a watch to Connie Johnson, who runs the whole of Fairhaven from the lock-up garages by the seafront. She trusts him, even gives him a package now and then to deliver to one of the estates. Drugs? That’s the thing to get into. Stealing phones is for kids.

Ryan has been called stupid his whole life. But who’s stupid now? He’s got cash in his pocket; Connie Johnson clearly likes him. He’s making more money than any eighteen-year-old he knows, probably making more money than his old teachers. The police had him in yesterday for nicking a phone and giving someone a shove, but they can’t touch him, because Ryan is smart. Too smart for the teachers, too smart for the cops, too smart for his neighbours now pressing on his door buzzer. Ryan Baird has got all the answers.

Ryan lights one last spliff before bedtime, then curses as his lapse in concentration sees him shot by a sniper. Lucky video games aren’t real life. Ryan reloads and starts again. He’s invincible.

Martin Lomax is awake, too. A Saudi lawyer has a bee in his bonnet about a powerboat. Martin Lomax is on the phone, trying to placate him. The long and short of it was, he had received the powerboat as agreed compensation from the Cartagena Cartel when the FDA had raided one of their Bolivian drugs labs, costing them all a great deal of money. The issue at hand was that the powerboat had arrived full of bullet holes, and the Saudi lawyer was of the opinion that this was aesthetically unpleasing, and also a hazard to seaworthiness.

Martin Lomax’s other line rings, and he promises he will talk to the Cartagena Cartel as soon as possible.

MI5 are on the other line. Does he know an Andrew Hastings? He does. Does Andrew Hastings work for him? He does, no use lying, this is MI5 and they know already. Was Mr Hastings working for him this evening? No, he was not. We regret to inform you that Mr Hastings has been shot dead while trying to murder a member of the British Security Services, condolences for your loss, but I wonder if you would have any comment on that. No, no comment, no comment at all. Would you know Mr Hastings’s next of kin? No. Was he married? I think he was. Who to? No idea, never asked. Sorry to disturb you so late at night. No, no, not at all, just doing your job.

Martin Lomax puts down the phone. Hastings dead. Well, that was inconvenient. But he would deal with the powerboat first. And he still needed to order some trestle tables for the Open Garden.

Poppy and Douglas are also awake. They are being interviewed in separate rooms inside a large country house near Godalming, just to get the facts straight. Poppy has coffee in front of her and a union rep beside her. Lance James is asking her to talk through what happened.

Douglas has no coffee and no union rep. It’s just him and Sue Reardon. The way things should be done. Did he recognize the man who tried to kill him? Never seen him before. Would it surprise him to know the gunman worked for Martin Lomax? Well, yes and no. Yes and no how? Well, he must be working for someone, surely? And Martin Lomax has threatened him, so it’s not outside the realms of possibility. But why would Martin Lomax want Douglas dead if he hadn’t stolen the diamonds, answer us that? No idea, Martin Lomax is playing some sort of game, that’s for certain, and I’m stuck in the middle of it, nearly getting my head blown off. Take us through the break-in at Martin Lomax’s house again, step-by-step.

It is three in the morning by the time Poppy’s union rep suggests it might be time to allow Poppy some sleep. As she walks down a long corridor, she can hear Sue Reardon still questioning Douglas Middlemiss.

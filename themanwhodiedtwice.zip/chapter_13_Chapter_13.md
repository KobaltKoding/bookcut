## 13

PC Donna De Freitas is sitting with DCI Chris Hudson in Interview Suite B. Opposite them is Ryan Baird, wearing a look of poorly attempted nonchalance, and his solicitor, wearing a suit that should be in a dry cleaner’s rather than Fairhaven Police Station. What was he thinking when he put it on? He even has a wedding ring. How did that happen? Being a man was such an easy gig. The work Donna puts into herself and she’s still single. And here’s this guy. Anyway.

‘Where were you on Friday, Ryan?’ asks Chris. ‘Between about five and five fifteen?’

‘I’ve forgotten,’ says Ryan.

His solicitor makes a note. Or pretends to. It’s hard to know what the note might be.

‘How’s your cup of tea?’ asks Donna.

‘How’s _your_ cup of tea?’ replies Ryan.

‘It’s actually not bad,’ says Donna.

‘Well done,’ says Ryan.

Look at him, acne and bravado. A child, really. A lost boy.

‘You own a bicycle, Ryan,’ says Chris. ‘A Norco Storm 4?’

Ryan Baird shrugs.

‘Are you shrugging because I said it wrong, or shrugging because you don’t know if you own one?’

‘I don’t own one. No comment,’ says Ryan.

‘You have to pick one or the other, Ryan,’ says Donna. ‘You can’t answer the question _and_ say no comment.’

‘No comment,’ says Ryan Baird.

‘That’s better,’ says Donna. ‘Not so hard, is it?’

‘A man was mugged, Ryan, on Appleby Street,’ says Chris. ‘Phone stolen, then kicked in the head while he was lying on the ground.’

‘No comment,’ says Ryan.

‘I didn’t ask you a question,’ says Chris.

‘No comment.’

‘Again, no question.’

‘He was eighty years old,’ says Donna. ‘He could have died. He’ll live, if you’re interested?’

Ryan Baird says nothing.

‘Now that was a question,’ says Chris. ‘Are you interested?’

‘No,’ says Ryan.

‘Well, that’s some honesty, finally. Now, cameras pick you and a couple of your buddies up on Theodore Street, that’s a couple of minutes away from the mugging. That’s at five seventeen, and we can see you here on a Norco Storm bike that may or may not be yours.’

Chris passes a photograph over to Ryan. ‘I am showing Ryan Baird photograph P19.’

‘Is that you, Ryan?’ asks Donna.

‘No comment.’

‘In either case,’ says Ryan’s solicitor, ‘it’s not illegal to be near a crime.’

This hangs in the air for a moment. Chris taps his pen on his pad a few times, thinking.

‘OK, that’s us done,’ says Chris, standing suddenly. Donna sees the surprise in the solicitor’s eyes. ‘Interview terminated at four fifty-seven p.m.’

Chris walks over to the door, opens it and motions for Ryan and his solicitor to leave. Ryan is first through the door, but the solicitor holds back.

‘Just wait in the corridor, Ryan,’ says the solicitor. ‘I won’t be a moment.’

Ryan shuffles off and, as soon as he’s out of earshot, the solicitor speaks to Chris in a low voice.

‘That’s all you have? You must have more than just CCTV?’

‘We’ve got more,’ says Chris.

The solicitor cocks his head to the side. ‘So what’s this? A trap? You know if you’re going to call him back in and show him more footage, or introduce a witness, then I need to see it now.’

‘I know,’ says Chris. ‘I’m not going to show him any more footage.’

‘You’re not going to search his flat?’

‘Nope,’ says Chris.

‘You’re not looking for the other two boys?’

Now that Donna is standing at the solicitor’s shoulder she notices a tidemark of dirt on his shirt collar. Donna is delighted that Chris has started taking a bit more care of his appearance since he’s started dating her mum. There were certain men you could allow to dress themselves and certain men you couldn’t. Chris was on the cusp. Soon he would be able to run free.

‘What’s the point?’ asks Chris.

‘The point?’ asks the solicitor.

‘Yep, what’s the point? You know we won’t get enough to convict him, we know we won’t get enough, and God knows what Ryan thinks about anything, but I’m guessing he knows too, the little scumbag.’

‘The what, sorry?’ says the solicitor.

‘We won’t be bringing Ryan back in,’ says Donna. ‘That’s all you need to worry about.’

‘We’re not going to sit through another interview like that,’ says Chris. ‘Not this time. You can go and break the good news to him.’

‘Am I missing something here?’ asks the solicitor, looking from Chris to Donna and back again. ‘I really feel like I’m missing something. You’re going to let him walk free? Can I ask why?’

Donna looks him straight in the eye. ‘No comment.’

She walks out through the open doorway. Chris looks at the solicitor and gives him a shrug.

Donna pops her head back round the door. ‘Look, this isn’t a judgement at all, but with suits you need to dry clean them once a month or so. Honestly, it’ll make a big difference.’

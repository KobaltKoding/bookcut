## 42

Ron sits on the back seat of the taxi, next to his grandson, Kendrick. He always asks for the same cabbie, Mark, because Mark supports West Ham and has a ‘Vote Labour’ sticker in his back window.

Ron has just picked Kendrick up from the station. Suzi, his daughter, didn’t stop, because she was going on to Gatwick. Ron managed to ask her how she was, but all she managed was ‘Don’t worry about me’ before the train started moving again, and he and Kendrick waved it into the distance.

Kendrick is currently hugging his backpack and looking out of each window in turn, excited at every new house, every new road sign and every new tree.

‘Grandad, a shop!’ says Kendrick.

Ron looks. ‘You’re right there, Kenny.’

‘Call me Kendrick, Grandad,’ says Kendrick.

‘I’ve always called you Kenny,’ says Ron. ‘It’s quicker.’

‘Uh, it’s the same, Grandad.’

‘Nah, it’s quicker,’ says Ron.

‘It’s not really, is it?’ asks Kendrick, straining forward against his seatbelt to get the taxi driver’s attention.

‘Not my business,’ says Mark, ‘but yeah, it’s got the same number of syllables, I’m afraid, Ron.’

Can’t even get back-up from a West Ham fan. People were so soft around kids. ‘I’ll call you Ken, then. That’s quicker.’

‘Just call me Kendrick, maybe? Daddy calls me Ken.’

‘Kendrick it is then,’ says Ron. Ron’s son-in-law was not his favourite person in the world. Safe to say Danny didn’t have a ‘Vote Labour’ sticker on the back of his BMW.

‘Can I ask you a question, Grandad?’

‘Fire away,’ says Ron.

‘Do you have a smart TV?’

‘Um, I don’t think so,’ says Ron. ‘I doubt it. I only just got a microwave.’

‘You do, Ron,’ says Mark over his shoulder. ‘Your boy Jason brought it round for you. A friend of his had found a hundred of them in a field. You were trying to sell me one.’

‘I do have a smart TV then,’ says Ron to Kendrick. ‘Is that good?’

‘It’s really good, I think,’ confirms Kendrick. ‘I’ve got my iPad, and I know I’m lucky because not everyone has one, but with a smart TV we can all play _Minecraft_ together. Do you know _Minecraft_, Grandad? Also, does anyone have cats where you live?’

‘There’s a few cats who pop in.’

‘Oh, I’m really happy about that.’

‘One of them killed a squirrel the other day and tried to bring it through my patio doors.’

‘Oh, no!’

‘Yep. I wasn’t having any of it, he was out on his ear.’

Kendrick thinks about this for a while. ‘But that’s just cats, they’re not trying to be mean. It’s sad for the squirrel, though. I hope I can see squirrels. So do you know _Minecraft_?’

‘Afraid not, son.’

‘That’s OK, because you can learn. You get to build new worlds and create all sorts of things, and sometimes you can talk to people, but it’s important to be careful. I built a castle and it had a moat but it didn’t have a drawbridge, so no one could get in, but also no one could get out, so it was good and bad. Uncle Ibrahim can play too.’

‘Uncle Ibrahim’s not feeling too clever at the moment,’ says Ron. ‘Go easy on him.’

‘Oh, that’s fine; he can still play though,’ says Kendrick. ‘What would you like to build, Grandad?’

‘What is it, use your imagination? Or are there instructions?’ asks Ron.

‘Imagination,’ says Kendrick, throwing his hands into the air.

‘Well, I don’t know about imagination. Is there fighting?’

‘You can fight, but I don’t like to.’

‘I’d build a unicorn farm, Kendrick,’ says Mark, from the front seat. ‘But with outbuildings that could bring in commercial revenue. Like a farm shop?’

‘Yeah, that’s so good,’ says Kendrick. ‘I’ll do that. And maybe slides?’

‘Slides and ice cream, perhaps?’ says Mark, and Kendrick nods vigorously.

‘Why don’t you and Uncle Ibrahim build it, and I’ll just watch,’ says Ron.

Kendrick nods again. ‘It’s really fun to watch too. And then you can say if you see a cat, and we can stop.’

Mark flicks on the indicator and turns left into the drive for Coopers Chase.

‘Here we are, Kenny, home sweet home.’

Kendrick looks up at Ron, one eyebrow raised, legs jiggling. He tries to look out of all the windows at once.

‘Do you remember Joyce?’ asks Ron.

‘Uh huh,’ says Kendrick. ‘She’s nice.’

‘She says she’s made you a cake if you want to come and see her?’

‘Just for me?’ asks Kendrick.

‘So she says.’

Kendrick nods his approval. ‘You can all have some though, I only need one bit. Mark, you can have some too.’

‘Love to, but I’ve got a pick-up in Tonbridge,’ says Mark.

Kendrick thinks, then looks at his grandad. ‘I haven’t got a present for Joyce though, so I’ll do a drawing. Have you got paper?’

‘They’ve got paper at the shop,’ says Ron.

‘We’ll go to the shop,’ says Kendrick.

‘Speed bump,’ says Mark, and the car bunny-hops in the air.

Kendrick reaches up and puts his arms around Ron’s neck. ‘Grandad, we’re going to have a fun time.’ He starts counting things off on his fingers. ‘We can go swimming, we can go for a walk, we can see Joyce, we can say hello to everyone.’ He points outside the window, ‘Grandad, the llamas!’

Ron looks at the llamas. Ian Ventham’s idea when he ran the place. Not his cup of tea, but, seen through a child’s eyes, not without charm. If you ended up living somewhere with llamas then perhaps not all is bad.

Kendrick settles back into his seat and shakes his head in wonder. ‘Oh, Grandad. You’re lucky to live here.’

Ron puts an arm around his grandson and looks out of the window. You’re not wrong there, kid, he thinks.

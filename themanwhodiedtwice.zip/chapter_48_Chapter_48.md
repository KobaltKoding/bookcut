## 48

Patrice left this morning. There was a cab to the station, there were tears. Even the odd one or two from her. The flat feels very empty, and Chris feels empty too.

Elizabeth and the gang had liked Patrice. On their way out, Joyce had whispered, ‘Oh, Chris, she’s a dream,’ and Ron had given him a thumbs-up and said, ‘Give her one from me, son.’

Chris is hungry.

Earlier this week he had been chopping up peppers, just like he had seen people doing on _MasterChef_. He had a red pepper, a green pepper and a yellow pepper. He has always known that you can buy them in packets of three from the supermarket. He has walked past them thousands of times in his life. Mocking him with their healthiness, as he made his way to the pies and pasta aisle.

He’s back in work tomorrow. Trying to catch Connie Johnson. There’s a team down from London to ‘help out’.

Chris has always fantasized about being the sort of man who might buy the red, yellow and green peppers. The sort of man who would buy broccoli or ginger or beetroot out of choice. To Chris, the fruit and veg aisle at the supermarket was where he bought bananas and occasionally a bag of spinach to put at the top of his basket in case he bumped into anyone he knew. People always look into your basket, don’t they? Chris wanted to pretend he shopped and ate like a grown man. Slip the KitKats under the spinach and no one’s any the wiser.

Chris thinks back to the day a cashier in Tesco’s was scanning his shopping. As she swiped through the chocolate, the crisps, the Diet Coke, the sausage rolls, she had looked up with a kind smile and said, ‘What is it, dear, a child’s birthday party?’ Chris has used self-service checkouts ever since.

He and Patrice had gone food shopping. Patrice asked him if he ever cooked stir fries, and Chris had lied and said that he did, and Patrice said she hadn’t seen a wok anywhere, so Chris had admitted that, no, he didn’t actually cook stir fries, but that he had always wanted to.

They went to the market, not the supermarket, but the actual _market_, and they bought a bit of this and a bit of that. As Patrice asked a man in an apron where his raspberries were from, Chris felt like a proper human being. It was like they were a couple from an advert. Chris kept hoping people would see him. ‘What, this? Oh, it’s just me and my girlfriend buying beansprouts.’

This place was empty without Patrice. Without her falling asleep on the floor in the living room while doing an online yoga class on her laptop. It was all very good in theory to have a girlfriend who did online yoga classes, but even better to have a girlfriend who was happy to have a nap in the afternoon.

Chris hadn’t wanted this week to end. On Monday Patrice will be back to school in south London. They’ll be back to Skype calls, and watching the same TV shows in different rooms.

His heart sinks, though, at the thought of the lock-up, and the thought of surveillance food. Would he go back to his old ways the moment Patrice was gone? He thinks back to last night.

Chris had circled coconut oil into a wok. They had had to buy coconut oil. And they’d had to buy the wok. And, once he had completely come clean to Patrice, they had had to buy the chopping board, the sharp knives and the sea salt and black pepper too. What a heady ride that shopping trip had been.

A fifty-one-year-old man, tossing peppers and beansprouts and spring onions and tofu (which was a whole other story) into a wok and hearing the sizzle so familiar from television. He had started to cry. Where had that come from? From the years of late-night takeaways by himself? The snacks, the numbing release of empty fat and carbs, the long nights, the long years, on his sofa with no one to put his arms around? And now this, the colours, the smells, the sheer, everyday normality of it.

Chris hadn’t looked after anyone in a long time, and that included himself. He let the tears run down through the steam and into the pan.

As the first tear sizzled, arms had encircled his waist. Patrice had woken up. He had turned and she tilted her head up to kiss him.

‘You have to stand back from the wok if you don’t want your eyes to water.’

‘Good tip,’ said Chris. ‘How was yoga? You get it all done?’

‘Mmm,’ says Patrice. ‘Intense though.’

She had pushed herself up and sat on the worktop. Chris was aware that he had seen women blithely sitting on worktops in films, but he didn’t think it was ever something that would happen in his own kitchen. This lovely, sleepy woman, perched on his worktop, happy to be there.

‘So, have you fallen in love with me yet?’ Patrice had said with a laugh.

‘Of course,’ said Chris, smiling, and gave her a kiss.

‘I should hope so, too,’ said Patrice, and hopped down from the worktop. ‘I’ll get bowls.’

Chris had turned back to the wok. He angled his head away from Patrice, now busily rooting through a cupboard. The tears came again then, heavier this time. What was wrong with him? It was just a stir fry, Chris. It was just a stir fry, and a woman sitting on a worktop.

It was then he realized. Realized? Understood? It doesn’t matter which, it only mattered that, in the instant he knew that, yes, he _had_ fallen in love with her.

Oh, God, yes, and oh, God, no.

At some point, would he really have to tell Patrice? Perhaps she could just work it out.

Chris had wiped a tear from the corner of his eye. The pain from a stray chilli flake on his finger was immediate, and all thoughts of love and happiness and shame and vulnerability and fear and excitement had to take second place for the moment.

At least he didn’t have to explain why he was crying any more.

Being healthy was easy when Patrice was here; it seemed so simple. Eat fruit, drink slimline tonic, don’t have a KFC.

But the evenings were longer when she wasn’t here. And Chris Hudson wasn’t about to steam broccoli for himself, that seemed weird. Was it OK to have a biscuit, if it was just one biscuit? Perhaps he could have some chocolate if it was just that dark chocolate you could buy in health-food shops? It tasted awful, so surely that made it OK?

Ibrahim had once told him that walnuts were very good for you, so now Chris is eating a lot of walnuts.

Where to draw the line?

Everywhere delivered now. Not just the restaurants, that was bad enough, but the local shops. Chris could have Pringles and an Aero brought to his door within ten minutes.

He eats another handful of walnuts, chewing begrudgingly. Perhaps he would have a herbal tea? Or just order a Twix. What harm would that do? Or two Twixes, because they were so small?

Maybe a curry? But with a vegetable side dish instead of poppadums?

Stop thinking about food, Chris. Think about work. Ryan’s Baird’s hearing is coming up. That should be an easy win. Think about Connie Johnson. Has she made any mistakes? He doesn’t like the thought of her being driven around Fairhaven in that Range Rover like she owns the place.

Chris’s entryphone starts to ring. 9.45\. Late for a visitor.

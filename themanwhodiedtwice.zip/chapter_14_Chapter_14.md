## 14

‘It was an accident, really,’ says Poppy, wiping the crumbs of a coconut macaroon from the corner of her mouth.

‘Oh, it often is,’ says Elizabeth.

‘I was at Warwick, studying English and Media. A woman from the Foreign Office came along and gave a talk, and there were drinks afterwards so we all went. Anyway, she said the starting salary at the Foreign Office was £24,000 and so I applied.’

‘Not very cloak and dagger,’ says Joyce, walking in with more tea.

‘No,’ agrees Poppy. ‘I had an interview with the Foreign Office; that was in London so I went down with my student railcard, and I’d prepared all sorts of things, reading up about Russia and China and whatever they might talk about, but it was just a chat, really.’

‘It always was,’ says Elizabeth.

‘They asked me who my favourite author is and I said Boris Pasternak, even though it’s really Marian Keyes. But they liked that, and I was invited back for a second interview. I told them I couldn’t really afford to come down to London twice, and they said, “Don’t worry, we’ll pay the fare, we’ll put you up somewhere,” and I said, “Honestly, I’m happier just going home, I don’t need to stay over,” and they said, “We insist,” and on the next interview they told me who they were, and they took me out and got me hammered and put me up in rooms in a club in Mayfair, and the next morning that was that. They sent me home with my own laptop and told me they’d be seeing me when I graduated.’

Joyce is pouring tea. ‘I remember Joanna, that’s my daughter, leaving university. She was at the LSE in London, if you know it, and I was terribly worried when she left because I didn’t know what she was going to do. She said she was going to be a DJ, and I said, well, I knew one of the people who did the hospital radio where I worked, Derek Whiting, and I could put in a word and get her some work experience, but she said it wasn’t that sort of DJ – apparently there was another sort – and she’d be travelling round the world, that was the plan. Then two days later she rang me and said she had an interview at Goldman Sachs, and could I lend her some money for smart clothes for the interview? And that was that.’

‘She sounds a character,’ says Poppy.

‘She has her moments,’ agrees Joyce. ‘Derek Whiting eventually died falling off a cruise ship. You never know what’s round the corner, do you?’

‘And you enjoy it, Poppy?’ asks Elizabeth.

Poppy takes a sip of tea, considering her answer. ‘Not really. Do you mind if I say that?’

‘Not at all,’ says Elizabeth. ‘It’s not for everyone.’

‘I just fell into it. I needed a job and it seemed exciting, and I’d never had any money before. But I don’t have the temperament for it. Do you like keeping secrets, Elizabeth?’

‘Very much so,’ says Elizabeth.

‘Well, I don’t,’ says Poppy. ‘I don’t like telling one thing to person A and one thing to person B.’

‘I’m the same,’ says Joyce. ‘Even if someone has a haircut that doesn’t suit them, I can’t keep quiet.’

‘But that’s the job,’ says Elizabeth.

‘Oh, I know,’ says Poppy. ‘It’s absolutely what I signed up for. The problem is me, it’s just the wrong job for me. I hate the drama of it. Meetings you’re invited to, meetings you’re not invited to.’

‘What would you rather do?’ asks Joyce.

‘Well,’ starts Poppy, then pauses.

‘Go on,’ says Joyce. ‘We won’t tell anyone.’

‘I write poetry.’

‘I don’t have time for poetry,’ says Elizabeth. ‘Never have, never will. Do you mind if we get on to Ryan Baird?’

‘Oh, yes,’ says Poppy, and reaches over the side of her chair for her bag. She pulls out a file and hands it to Elizabeth. ‘Name, address, email, mobile number and recent call log, national insurance, NHS records, browser history, mobile numbers of close associates. I’m afraid that’s all I could get at short notice.’

‘That will do for starters, thank you, Poppy,’ says Elizabeth.

‘Don’t thank me,’ says Poppy, ‘thank Douglas. If it was up to me you wouldn’t have them. I’m sorry to say it doesn’t feel entirely legal.’

‘Oh, nothing’s legal any more, you can barely walk down the street these days. You have to bend the rules sometimes,’ says Elizabeth.

‘But that’s just it, isn’t it?’ says Poppy. ‘I don’t want to bend the rules. It doesn’t give me a thrill. It gives you a thrill, doesn’t it?’

‘Yes,’ agrees Elizabeth.

‘Well, not me. It makes me anxious. And my whole job is bending rules.’

‘I’d be the same,’ says Joyce.

‘Oh, Joyce, get over yourself,’ says Elizabeth. ‘You would have made the perfect spy.’

‘I still think Poppy should do her poetry.’

‘Thank you,’ says Poppy. ‘That’s what my mum says too. And she’s usually right.’

‘Don’t get me wrong, I think you should too,’ says Elizabeth. ‘I don’t want to _hear_ it, but you should certainly do it. First, though, we have this job to do. To protect Douglas.’

‘I can’t wait to meet him,’ says Joyce. ‘Are you worried I’ll fall in love with him?’

‘Joyce, you will find him very handsome, but you will see through him in a moment.’

‘We’ll see,’ says Joyce. ‘Poppy, can I ask why you have a tattoo of a daisy on your wrist? I would have thought you’d have a tattoo of a poppy?’

Poppy smiles and strokes the small tattoo. ‘Daisy is my grandmother. I told her once I wanted a tattoo and she said over her dead body, anchors and mermaids and so on. So I went away, had this done and showed it to her the next time I visited. I said, “Daisy, meet daisy,” and there wasn’t a lot she could say about it then, was there?’

‘Clever girl,’ says Joyce.

‘Then two weeks later I went round again, and she rolled up her sleeve and said, “Poppy, meet poppy.” A great big poppy tattoo all the way up her forearm. She said if I was going to be an idiot, then she was, too.’

Elizabeth laughs, and Joyce claps her hands.

‘Well, she sounds just our type,’ says Elizabeth. ‘Poppy, if this is your last job with the Service, so be it, but I promise we’ll do everything we can to make it a fun one for you.’

‘We will,’ says Joyce. ‘Another macaroon, Poppy? You enjoyed the last one.’

Poppy raises a hand to decline the offer.

‘We won’t let anyone in here who shouldn’t be here. Douglas will be quite safe, which, of course, means you will be quite safe, too,’ says Elizabeth.

‘Unless they show up this evening while we’re eating macaroons,’ says Poppy.

‘And, while we all sit around with nothing to do, I’m sure we can crack the mystery of what Douglas has done with the diamonds.’

‘Well, he denies stealing them, as you know. And, besides, that’s not our job,’ says Poppy. ‘Our job is to protect Douglas.’

‘Poppy, I honestly don’t mind you being anxious, I don’t mind you being conflicted, I don’t even mind you being arty, but I absolutely won’t tolerate you being boring, because I can tell you are not a boring human being. Do we have a deal?’

‘Don’t be boring?’

‘If it’s not too much to ask?’

‘You both really think I should write poetry?’

‘Oh, yes,’ says Joyce. ‘What’s that poem I like?’

Poppy and Elizabeth look at each other. They don’t know.

While she is looking at Elizabeth, Poppy says, ‘In the interest of not being boring, can I ask you a question?’

‘Up to a point, yes,’ says Elizabeth.

‘How did you end up in the Service? Did you follow your dream? And I need the non-boring answer, please. I’m not a tourist.’

Elizabeth nods.

‘I had a professor; I was studying French and Italian at Edinburgh. Anyway, he had friends who had friends who were always on the lookout, and he floated the idea and it wasn’t for me, but then he’d float it again and again.’

‘And why did you finally sign up?’

‘Well, he was desperate to sleep with me, this professor – people were in those days. So I knew he wanted to sleep with me, and I knew he wanted me to interview for the Service. And I honestly felt I should probably do one or the other – you know how men can be with rejection. So I had to either sleep with him or interview with the Service, and I chose the lesser of two evils. And once the Service has its hooks in you, they don’t like to let go, as you will find out.’

‘So your career was just to avoid sleeping with someone?’ asks Poppy.

Elizabeth nods.

‘What do you think you would have done otherwise?’

‘I know you don’t like to keep secrets, Poppy, but you have been very helpful with Ryan Baird. So here’s something I don’t think I’ve ever told anyone before. Not my family, none of my husbands, not even Joyce. I always fancied being a marine biologist.’

Poppy nods.

‘Marine biologist?’ says Joyce. ‘What is that? Dolphins and so on?’

Elizabeth nods.

Joyce reaches over and places her hand on her friend’s arm. ‘I think you would have made a wonderful marine biologist.’

Elizabeth nods again. ‘Thank you, Joyce, I might have, mightn’t I?’

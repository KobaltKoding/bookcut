## 80

‘I just thought I would come in and have a freshen up,’ says Joyce. ‘I’ll put the hoover round, and a bit of Mr Sheen. I won’t go anywhere near your bits and bobs.’

‘Thank you, Joyce,’ says Ibrahim, sipping his tea. ‘I’m sorry to miss all the fun yesterday.’

‘I’ll fill you in, don’t worry.’

‘Ron is fuming that he missed it,’ says Ibrahim. ‘Especially as Siobhan was there.’

‘It won’t do Ron any harm to keep it in his pants for now,’ says Joyce, dusting the sideboard. ‘How are you feeling? In yourself?’

Ibrahim slides back into his armchair. He gives a small smile and a shrug.

Joyce nods and gets to work. ‘I need your help today.’

‘I’m sorry, Joyce, I can’t. Not today.’

‘You don’t even know what I want yet.’

Ibrahim laughs. ‘Of course I do. It’s the first day of peace we’ve had for weeks, Joyce. You want me to drive you to the animal rescue centre? To pick up your dog?’

‘Well, yes, please, that is what I’d like. Why don’t you finish your tea, and we can head off? Lovely drive?’

‘I’m afraid not.’

‘You seem to think I might take no for an answer?’ says Joyce. ‘How long have you known me?’

Ibrahim leans forward and puts his tea back down on the low table. ‘Joyce, look at me.’

Joyce puts down her duster and does just that.

‘I know what you are trying to do, and I am moved that you are trying. You know I am frightened, you know I don’t want to leave this flat, and I certainly don’t want to leave this village. You know that is unhealthy, and you want to look after me. You are too clever to come over and tell me to pull myself together. You know I am in too many pieces for that. And so your tactic is different, your tactic is cleverer. “Ibrahim, please help me,” is your tactic. “Ibrahim, I need you.” But, Joyce, you don’t need to go to the rescue centre today, Alan isn’t going anywhere, I’ve seen his picture, you are the only person in the world who would choose him. And when you do go to the rescue centre you won’t need me to drive you. Get a taxi, or get someone else to drive you. Gordon Playfair has a Land Rover, which would be perfect for dog transportation. Your kindness is welcome but it is transparent. I am not leaving this village again. I have made my peace with that.’

Joyce nods.

‘You read people very well, Joyce, don’t think I don’t spot that. I see how you do it too, coercion through kindness. But understand this. Behind me, in these files, there are people I couldn’t help, people beyond reach, problems I couldn’t fix, whichever way I twisted and turned. You like to fix things, too, Joyce. You can’t bear it when something is out of place. And so you come in, and you smile, and I know your affection for me is genuine, and you ask me to drive you to the animal rescue centre. How could I resist? And before you know it I’m back behind the wheel of that car, I’m outside the village, and I’m soon surrounded by lost, stray dogs and, while I don’t like dogs – quite the opposite – I am sure to feel a kinship with these animals lost and alone. Lost and alone and waiting for Joyce to make things better. It is a terrific plan, you are a very good and clever friend. But, and I need you to really listen to this, it’s not going to happen. I am too scared. There are times when a wise man admits defeat, and I hope you agree I am a wise man. I have many certificates. So, thank you, from the bottom of my heart, but, just for once, Joyce, this is a problem you cannot fix.’

Ibrahim leans back in his chair.

‘I understand,’ nods Joyce, and places the duster over her shoulder. ‘I wonder, though, if I might just say this …’

Around forty-five minutes later Joyce spies the first sign for the animal rescue centre and Ibrahim takes the exit.

‘I just love to see a horse in a field,’ says Joyce. ‘When you can tell they’re happy. Happiness is what life is all about, don’t you think?’

Ibrahim shakes his head. ‘I can’t agree. The secret of life is death. Everything is about death, you see.’

‘Well, recently, yes,’ agrees Joyce. ‘But surely not everything? That seems a bit much?’

‘In essence,’ says Ibrahim. ‘Our existence only makes sense because of it; it provides meaning to our narrative. Our direction of travel is always towards it. Our behaviour is either because we fear it, or because we choose to deny it. We could drive past this spot once a year, every year, and neither the horse nor ourselves would get younger. Everything is death.’

‘That’s one way of looking at things, I suppose,’ says Joyce.

‘It’s the only way,’ says Ibrahim. ‘Will there be a toilet at the rescue centre?’

‘You would think so,’ says Joyce. ‘And if not, there will be a staff toilet.’

‘Oh, I can’t use a staff toilet,’ says Ibrahim. ‘I always feel I haven’t earned it.’

‘Surely, if everything is about death, then also _nothing_ is about death?’ says Joyce, applying lipstick in the passenger mirror.

‘How so?’ asks Ibrahim.

‘Well, just say that everything was blue. You, me, Alan, everything?’

‘OK.’

‘Well, if _everything_ was blue then we wouldn’t need the word “blue”, would we?’

‘I accept that,’ accepts Ibrahim.

‘And if we had no word for blue then nothing would be blue, would it?’

‘Well, death is an event, and so …’ begins Ibrahim, then sees the entrance to the rescue centre up on his left. ‘We’re here!’

Which is a relief, because Joyce does sort of have a point.

Perhaps everything isn’t about death after all? What a time to find out.

## 73

Donna and Chris are parked in a side street outside a shop selling candy floss, models of Tower Bridge and international phone cards. They are facing the sea, grey and unhappy like the sky, and have a clear view of the entrance to Fairhaven pier away to their left.

Donna has an ice cream. She offers some to Chris, but he declines, and looks down at his bag of sunflower seeds.

Connie Johnson is the first to arrive. Her Range Rover pulls over onto the broad pavement in front of the pier, and she steps out and looks around her. She is carrying a large holdall, and Donna hopes it has five kilos of coke in it. The five kilos of coke that will hopefully see Connie arrested before the afternoon is through.

Donna can’t see the driver behind the tinted windows, but she is looking forward to rearresting Ryan Baird too. She had to hand it to Joyce there.

Suddenly Bogdan appears, though Donna can’t figure out from where. They had been watching the pier for half an hour already and hadn’t caught a glimpse of the big man. The big, taciturn man with the deep blue eyes. Donna swears that her ice cream starts to melt faster. She watches him walking up the pier with Connie Johnson, carrying her bag of cocaine for her like a gentleman.

‘He’s a good guy,’ says Chris.

‘Mmm hmm,’ agrees Donna.

A black Lotus sports car pulls up next, and two men, one older and one younger, step out. Donna sees Chris look down at a picture on his phone.

‘That’s Martin Lomax,’ says Chris. ‘The other one must be the spy?’

‘Lance,’ says Donna. Joyce had told Donna she might like Lance, but he’s too old. And the hair? Not a bad try though, Joyce. Ten years ago maybe.

Lance James and Martin Lomax begin the walk along the pier, leaving the car where it is. Donna thinks it must be nice to work for MI5 and be able to park anywhere you want. Donna had once wrestled a man wielding a sword in the Streatham Lidl, only to find her car had been clamped outside for parking across two bays.

It is five minutes to three. People seem to be punctual where diamonds and cocaine are involved. A Toyota Avensis with ‘Robertsbridge Taxis’ stencilled onto the driver’s door arrives next, pulling up behind the Lotus.

The driver, whom Donna doesn’t recognize, steps out and makes his way to the boot. From the passenger seat steps a man who can only be Frank Andrade Jr.

Martin Lomax and Frank Andrade Jr are none of Donna and Chris’s business today, but it’s interesting to see them nonetheless. MI5 will be dealing with the two of them, while Kent Police deal with Connie Johnson and Ryan Baird. And no questions asked by either side. Elizabeth had brokered that deal.

And speak of the devil, here she is now. Elizabeth and Joyce exit the back seats. Joyce looks like she has just woken up.

The driver hands Frank Andrade a briefcase and the two men shake hands.

Bogdan has returned, and he motions to Frank Andrade to come with him. Andrade looks at Elizabeth, who nods. Elizabeth doesn’t shake Andrade’s hand and neither does Joyce. Which is very unlike both of them.

Bogdan gives Frank Andrade a small smile. Has Donna seen Bogdan smile before? She doesn’t think so, but she would like to see it again. ‘Climb your next mountain,’ Ibrahim had told her. As she watches him walking up the pier with Frank Andrade Jr, Donna wonders what it might be like to climb Bogdan? She eats her chocolate flake whole, then starts on the cornet.

‘So the gang’s all here,’ says Chris. ‘You ready?’

‘Ready,’ says Donna.

She sees Elizabeth walking along the promenade now, Joyce behind her, trying to brush creases out of her skirt after the journey. They pass the Lotus and they pass the Range Rover. Joyce looks over, spots them and gives them a big wave. It will be a while before Joyce makes an effective undercover officer. Donna waves back and Joyce looks thrilled.

Joyce and Elizabeth reach a nondescript white van, parked by the promenade railings, cordoned off by safety tape. On the side of the van it says ‘T. H. Hargreaves – Railings. All Jobs Considered’.

Elizabeth steps over the tape, followed by Joyce. Someone inside the van opens the back doors and they both climb in.

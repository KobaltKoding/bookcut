## 41

Elizabeth is not the sentimental type, but even so.

She is about to find out if her ex-husband is dead. She knows – or knew? – Douglas well enough to know he wouldn’t have revealed the true location of the diamonds to anybody else. Whatever false trail he laid would have been a good one. No one else knows about locker 531\. That was a secret hidden in a hole in a tree high above Coopers Chase.

If the diamonds are not in this locker, then Douglas has them.

If the diamonds are there, that means Douglas hasn’t been to collect them. And that means Douglas is dead. Quite the day she is having.

If Douglas is alive then he is on the run and very rich. And, of course, if Douglas is alive, then he killed Poppy. He killed Poppy, and he faked his own death with a corpse taken from goodness knows where. A fresh corpse, though, there was no hiding that. It wasn’t like the corpse of Marcus Carmichael they had pulled from the Thames so many years ago. No one was checking Marcus Carmichael too closely, everybody had their job to do. But Elizabeth had seen Douglas’s body. Seen it up close. It was very fresh indeed. So perhaps Douglas had killed two people? That’s the only way he could have got away with it.

So, in the grand scheme of things, Elizabeth is hoping that Douglas is dead. No offence meant, but she would rather her ex-husband was a dead thief than a living murderer.

The minibus is full. Carlito, the driver, has a cigarette hanging out of his window. This is not a group who minds if you smoke. And, in return, Carlito doesn’t mind if you don’t wear a seatbelt. The whole scene might have been from the 1970s, when, if you wanted to die of lung cancer, or in a road accident, then that was your choice.

Joyce is quiet, which is unlike her. It’s almost unnerving.

At first Elizabeth thought it was because of Poppy. Joyce and Poppy had bonded, that was for certain. Or perhaps because of Siobhan? Being so close to a mother’s grief?

But then Elizabeth realizes that the last time the two of them had been on this minibus together, Bernard had been on the back seat. Just before Joyce and Bernard had become close. Joyce misses him, although they never talk about him. Just like they never talk about Stephen, or Penny. In fact what do she and Joyce talk about? The English countryside passes by outside the minibus window.

‘What do you and I talk about, Joyce?’ asks Elizabeth.

Joyce thinks. ‘It’s been mainly murder, hasn’t it? Since we met?’

Elizabeth nods. ‘I suppose it has. What do you think we’ll talk about when there are no murders?’

‘Well, we’ll find out at some point, won’t we?’

Joyce looks out of the window again. Elizabeth doesn’t like seeing her friend unhappy. What do normal people say in these situations? Here goes nothing.

‘Would you like to talk about Bernard?’

Joyce turns to look at her and gives her a tiny smile. ‘No, thank you.’

Joyce returns to her view and, without turning, puts her hand on Elizabeth’s.

‘Would you like to talk about Stephen?’ asks Joyce.

‘No, thank you,’ says Elizabeth. Joyce gives her hand a squeeze, and leaves it there. Elizabeth looks down at her friendship bracelet. A very ugly thing that means the world to her. Elizabeth’s life has been one of classmates and cousins, of professors, of colleagues and of husbands. She has always found friends harder. What did friends want from you? What did they expect you to do? Her great brain hadn’t worked it out.

Last night, awake with Stephen at around 4 a.m., he had been showing off about some mountain or other he had climbed when he was a young man. She had then invented an even bigger mountain she had climbed – ‘without a single Sherpa, darling’ – and he then upped the ante and was climbing Everest without Sherpas or oxygen, and then she was climbing Everest carrying a grand piano, and the two of them were in fits of giggles. It was love, of course, but it was also friendship. Stephen was the first person she had ever met who refused to take her seriously.

Joyce doesn’t take her seriously, Ibrahim doesn’t take her seriously, Ron certainly doesn’t take her seriously. They respect her, she thinks, they know they can rely on her, they _take care_ of her – shudder – but they refuse to take her seriously. Who knew that was the secret all along?

Now she really thinks about it, Chris and Donna don’t take her seriously either. First Stephen, then the Thursday Murder Club, now Chris and Donna? Why this sudden wave of people who refused to be taken in by her casual brilliance and brusque efficiency?

She knows the answer, of course. After meeting Stephen she took _herself_ less seriously. The moment she had done that, a door was opened, which true friends could walk through. And in they walked. She squeezes Joyce’s hand back.

‘You know, I _would_ like to talk about Stephen. I just don’t know how yet.’

Joyce turns away from the window and smiles at her friend.

‘Well, the kettle is always on at mine.’

The minibus pulls to a stop outside Ryman’s, and everyone starts gathering their belongings. Carlito swivels himself in his chair.

‘I see you back here in three hours. No shoplifting, no graffiti.’

Elizabeth stands, then ushers Joyce to the exit in front of her. As she passes, Joyce says, ‘Before we talk about your current husband, let’s find out if your ex-husband is dead.’

‘Yes, let’s,’ says Elizabeth. That’s what friends were for.

The station was a ten-minute walk from Ryman’s, down towards the seafront. As the shops peter out, Fairhaven gets a bit grittier. They pass by the end of a road full of lock-up garages, teenagers on bicycles skidding up and down. Fairhaven in autumn is beginning to hunker down, to prepare for winter, no day trippers, no tourists, everyone having to find different ways to make their money. Elizabeth knows that if you opened up all of those garages you would find a thing or two.

Should Elizabeth have told Sue Reardon about the letter? Well, yes, of course she should, that was a silly question, but Elizabeth wanted to be the one to open the locker. Sue would understand that. And if she didn’t understand, then they would cross that bridge in time. Elizabeth suspected there would be few complaints if she handed Sue a bag of diamonds.

As they approach the station they pass Le Pont Noir, which used to be the Black Bridge. Ron’s son, Jason, had told them many tales of the Black Bridge. They haven’t seen Jason for a while. He is dating Gordon Playfair’s daughter, Karen, and is very happy by all accounts. The more love the better as far as Elizabeth is concerned these days.

They reach Fairhaven station. It is much as Joyce had described it. Morning rush hour has passed, but it is still lively. Everyone living their own story. Students with backpacks trying to find platforms, men in suits running for connections, pre-schoolers in pushchairs wailing for raisins.

And, standing, looking up at the station signs, a silly old spy and her friend, looking for twenty million pounds’ worth of diamonds stolen from the New York mafia.

Elizabeth sees the arrow pointing to ‘Left-Luggage Lockers’.
